"""Poland registry endpoints: CEIDG search/changes (discovery) and KRS enrich. Each operation
runs through poland/discovery.py, which handles the full EXTRACT->LOAD->TRANSFORM pipeline and
reuses the existing qualification/offer/CRM engines once a company exists."""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import Session

from database.database import get_db
from database.models import BusinessEvent, Company, SourceRun
from poland import discovery
from poland.ceidg_client import VALID_STATUSES
from poland.source_registry import list_sources

router = APIRouter(prefix="/api/poland")


class In(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class CeidgSearchIn(In):
    nazwa: Optional[list[str]] = None
    nip: Optional[list[str]] = None
    pkd: Optional[list[str]] = None
    miasto: Optional[list[str]] = None
    wojewodztwo: Optional[list[str]] = None
    status: Optional[list[str]] = None
    dataod: Optional[str] = None
    datado: Optional[str] = None
    campaign_id: Optional[int] = None
    max_results: int = Field(50, ge=1, le=500)


class CeidgChangesIn(In):
    dataod: str
    datado: Optional[str] = None
    campaign_id: Optional[int] = None
    max_results: int = Field(100, ge=1, le=500)


class KrsEnrichIn(In):
    krs_numbers: list[str] = Field(min_length=1, max_length=50)
    campaign_id: Optional[int] = None
    full: bool = False


@router.get("/sources")
def sources():
    return {"sources": list_sources(), "ceidg_statuses": sorted(VALID_STATUSES)}


@router.post("/ceidg/search")
def ceidg_search(body: CeidgSearchIn, db: Session = Depends(get_db)):
    params = body.model_dump(exclude_none=True, exclude={"campaign_id", "max_results"})
    return discovery.ceidg_search(db, campaign_id=body.campaign_id, max_results=body.max_results, **params)


@router.post("/ceidg/changes")
def ceidg_changes(body: CeidgChangesIn, db: Session = Depends(get_db)):
    return discovery.ceidg_changes(db, dataod=body.dataod, datado=body.datado, campaign_id=body.campaign_id,
                                   max_results=body.max_results)


@router.post("/krs/enrich")
def krs_enrich(body: KrsEnrichIn, db: Session = Depends(get_db)):
    return discovery.krs_enrich(db, body.krs_numbers, campaign_id=body.campaign_id, full=body.full)


@router.get("/events")
def events(company_id: Optional[int] = None, limit: int = 50, db: Session = Depends(get_db)):
    q = db.query(BusinessEvent).join(Company).filter(Company.archived.is_(False))
    if company_id:
        q = q.filter(BusinessEvent.company_id == company_id)
    rows = q.order_by(BusinessEvent.event_date.desc(), BusinessEvent.id.desc()).limit(min(limit, 200)).all()
    return [{**e.as_dict(), "company_name": e.company.name} for e in rows]


@router.get("/runs")
def runs(source_id: Optional[str] = None, limit: int = 30, db: Session = Depends(get_db)):
    q = db.query(SourceRun)
    if source_id:
        q = q.filter(SourceRun.source_id == source_id)
    rows = q.order_by(SourceRun.id.desc()).limit(min(limit, 100)).all()
    return [r.as_dict() for r in rows]
