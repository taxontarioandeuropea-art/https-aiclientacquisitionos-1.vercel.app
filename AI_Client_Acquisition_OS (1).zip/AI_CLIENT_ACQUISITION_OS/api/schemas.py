"""Request validation (Pydantic). Strings are length-limited and stripped; unknown fields are rejected.
Deeper normalisation/sanitising happens in the services."""
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field


class In(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


S = lambda n: Optional[str]          # noqa: E731  (documentation helper only)


class CompanyBase(In):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    legal_name: Optional[str] = Field(None, max_length=255)
    website: Optional[str] = Field(None, max_length=500)
    country: Optional[str] = Field(None, max_length=80)
    state: Optional[str] = Field(None, max_length=80)
    city: Optional[str] = Field(None, max_length=120)
    address: Optional[str] = Field(None, max_length=300)
    industry: Optional[str] = Field(None, max_length=120)
    subindustry: Optional[str] = Field(None, max_length=120)
    employees: Optional[Any] = None
    estimated_revenue: Optional[Any] = None
    estimated_scale: Optional[str] = Field(None, max_length=120)
    ownership_type: Optional[str] = Field(None, max_length=120)
    technology_stack: Optional[Any] = None
    accounting_software: Optional[str] = Field(None, max_length=120)
    growth_status: Optional[str] = Field(None, max_length=120)
    description: Optional[str] = Field(None, max_length=4000)
    email: Optional[str] = Field(None, max_length=255)
    phone: Optional[str] = Field(None, max_length=60)
    notes: Optional[str] = Field(None, max_length=4000)
    source: Optional[str] = Field(None, max_length=255)
    source_url: Optional[str] = Field(None, max_length=500)


class CompanyIn(CompanyBase):
    name: str = Field(min_length=1, max_length=255)


class PersonIn(In):
    first_name: Optional[str] = Field(None, max_length=120)
    last_name: Optional[str] = Field(None, max_length=120)
    full_name: Optional[str] = Field(None, max_length=240)
    title: Optional[str] = Field(None, max_length=200)
    department: Optional[str] = Field(None, max_length=120)
    email: Optional[str] = Field(None, max_length=255)
    phone: Optional[str] = Field(None, max_length=60)
    linkedin_url: Optional[str] = Field(None, max_length=500)
    decision_maker_level: Optional[str] = Field(None, pattern="^(decision_maker|influencer|user|unknown)$")
    source: Optional[str] = Field(None, max_length=255)
    source_url: Optional[str] = Field(None, max_length=500)
    confidence: Optional[float] = Field(None, ge=0, le=1)
    notes: Optional[str] = Field(None, max_length=4000)


class LeadIn(In):
    company_id: Optional[int] = None
    company: Optional[CompanyIn] = None
    person_id: Optional[int] = None
    person: Optional[PersonIn] = None
    campaign_id: Optional[int] = None


class LeadPatch(In):
    person_id: Optional[int] = None
    campaign_id: Optional[int] = None
    next_action: Optional[str] = Field(None, max_length=255)
    next_action_date: Optional[str] = Field(None, max_length=20)
    notes: Optional[str] = Field(None, max_length=4000)
    detected_problem: Optional[str] = Field(None, max_length=4000)
    potential_mrr: Optional[Any] = None
    recommended_service_id: Optional[int] = None


class StageIn(In):
    stage: str = Field(max_length=20)
    note: Optional[str] = Field(None, max_length=255)
    actual_mrr: Optional[float] = Field(None, ge=0)
    lost_reason: Optional[str] = Field(None, max_length=255)
    disqualify_reason: Optional[str] = Field(None, max_length=20)


class SignalIn(In):
    company_id: int
    signal_type: str = Field(min_length=1, max_length=80)
    evidence_text: str = Field(min_length=8, max_length=2000)
    source: str = Field(min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=500)
    source_url: Optional[str] = Field(None, max_length=500)
    confidence: float = Field(0.7, ge=0, le=1)
    date_detected: Optional[str] = None
    kind: Optional[str] = Field(None, pattern="^(FACT|INFERENCE)$")


class InteractionIn(In):
    type: str = "note"
    direction: str = "internal"
    subject: Optional[str] = Field(None, max_length=300)
    body: Optional[str] = Field(None, max_length=5000)
    outcome: Optional[str] = Field(None, max_length=200)
    occurred_at: Optional[str] = None
    company_id: Optional[int] = None


class TaskIn(In):
    title: str = Field(min_length=1, max_length=300)
    description: Optional[str] = Field(None, max_length=2000)
    task_type: str = "other"
    priority: str = "MEDIUM"
    due_date: Optional[str] = None
    lead_id: Optional[int] = None
    company_id: Optional[int] = None


class TaskPatch(In):
    title: Optional[str] = Field(None, max_length=300)
    description: Optional[str] = Field(None, max_length=2000)
    task_type: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = Field(None, pattern="^(open|done|cancelled)$")
    due_date: Optional[str] = None


class MessagePatch(In):
    subject: Optional[str] = Field(None, max_length=300)
    body: Optional[str] = Field(None, min_length=1, max_length=8000)
    channel: Optional[str] = None
    recipient: Optional[str] = Field(None, max_length=255)


class GenerateMessageIn(In):
    channel: Optional[str] = None
    use_ai: bool = False
    followup_step: int = Field(0, ge=0, le=20)


class SendIn(In):
    sent_at: Optional[str] = None


class CampaignBase(In):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    country: Optional[str] = Field(None, max_length=80)
    industry: Optional[str] = Field(None, max_length=120)
    subindustry: Optional[str] = Field(None, max_length=120)
    icp_description: Optional[str] = Field(None, max_length=4000)
    target_employees_min: Optional[Any] = None
    target_employees_max: Optional[Any] = None
    target_revenue_min: Optional[Any] = None
    target_revenue_max: Optional[Any] = None
    target_technology: Optional[Any] = None
    target_ownership: Optional[str] = Field(None, max_length=120)
    target_geography: Optional[str] = Field(None, max_length=255)
    minimum_mrr: Optional[Any] = None
    target_mrr: Optional[Any] = None
    preferred_decision_maker: Optional[Any] = None
    campaign_status: Optional[str] = None
    research_rules: Optional[str] = Field(None, max_length=4000)
    qualification_rules: Optional[dict] = None
    outreach_strategy: Optional[str] = Field(None, max_length=4000)
    followup_sequence: Optional[list] = None
    language: Optional[str] = Field(None, max_length=10)
    service_ids: Optional[list[int]] = None


class CampaignIn(CampaignBase):
    name: str = Field(min_length=1, max_length=200)


class ServiceBase(In):
    name: Optional[str] = Field(None, min_length=1, max_length=160)
    description: Optional[str] = Field(None, max_length=4000)
    target_industries: Optional[Any] = None
    target_employees_min: Optional[Any] = None
    target_employees_max: Optional[Any] = None
    target_technology: Optional[Any] = None
    typical_problems: Optional[Any] = None
    pricing_model: Optional[str] = None
    minimum_price: Optional[Any] = None
    target_mrr: Optional[Any] = None
    deliverables: Optional[Any] = None
    required_signals: Optional[Any] = None
    preferred_decision_makers: Optional[Any] = None
    message_template: Optional[str] = Field(None, max_length=4000)
    follow_on_service_id: Optional[int] = None
    is_active: Optional[bool] = None


class ServiceIn(ServiceBase):
    name: str = Field(min_length=1, max_length=160)


class ResearchIn(In):
    company_id: int
    use_web: bool = True
    use_ai: bool = False


class DiscoverIn(In):
    urls: list[str] = Field(min_length=1, max_length=25)
    campaign_id: Optional[int] = None


class MergeIn(In):
    primary_id: int
    secondary_id: int
    field_choices: Optional[dict[str, str]] = None


class DismissIn(In):
    id_a: int
    id_b: int


class ComplianceIn(In):
    status: Optional[str] = None
    lawful_basis: Optional[str] = None
    contact_type: Optional[str] = None
    jurisdiction: Optional[str] = Field(None, max_length=10)
    source_id: Optional[str] = Field(None, max_length=40)
    notes: Optional[str] = Field(None, max_length=2000)


class SuppressionIn(In):
    match_type: str = Field(pattern="^(company|email|domain)$")
    value: str = Field(min_length=1, max_length=255)
    reason: str = "manual"
    note: Optional[str] = Field(None, max_length=1000)
