"""Campaigns, service catalog and research/discovery endpoints."""
from __future__ import annotations

import json
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, UploadFile
from sqlalchemy.orm import Session

from adapters.web_research_adapter import WebResearchSource
from api import schemas as S
from api.deps import dump, read_upload
from core.errors import NotFound, ValidationProblem
from database.database import get_db
from database.models import Company, Lead, Service
from engines import analytics_engine, company_research, lead_hunter
from services import campaign_service, import_export_service, lead_service

router = APIRouter(prefix="/api")


@router.get("/campaigns")
def list_campaigns(db: Session = Depends(get_db)):
    return campaign_service.list_campaigns(db)


@router.post("/campaigns", status_code=201)
def create_campaign(body: S.CampaignIn, db: Session = Depends(get_db)):
    data = dump(body)
    ids = data.pop("service_ids", None)
    c = campaign_service.create_campaign(db, data, service_ids=ids)
    return campaign_service.campaign_dict(c, campaign_service.campaign_stats(db, c.id))


@router.get("/campaigns/{cid}")
def get_campaign(cid: int, db: Session = Depends(get_db)):
    c = campaign_service.get_campaign(db, cid)
    d = campaign_service.campaign_dict(c, campaign_service.campaign_stats(db, cid))
    d["funnel"] = analytics_engine.funnel(db, campaign_id=cid)
    d["effective_followup"] = __import__("engines.followup_engine", fromlist=["x"]).sequence_for(c, __import__("core.settings_store", fromlist=["x"]).get_settings(db))
    return d


@router.patch("/campaigns/{cid}")
def update_campaign(cid: int, body: S.CampaignBase, db: Session = Depends(get_db)):
    data = dump(body)
    ids = data.pop("service_ids", None)
    c = campaign_service.update_campaign(db, cid, data, service_ids=ids)
    return campaign_service.campaign_dict(c, campaign_service.campaign_stats(db, cid))


@router.delete("/campaigns/{cid}")
def delete_campaign(cid: int, db: Session = Depends(get_db)):
    campaign_service.delete_campaign(db, cid)
    return {"deleted": True}


@router.post("/campaigns/{cid}/qualify-all")
def qualify_all(cid: int, db: Session = Depends(get_db)):
    campaign_service.get_campaign(db, cid)
    return campaign_service.qualify_all(db, cid)


@router.post("/campaigns/{cid}/discover")
def discover(cid: int, body: S.DiscoverIn, db: Session = Depends(get_db)):
    campaign_service.get_campaign(db, cid)
    return lead_hunter.discover_from_urls(db, body.urls, cid)


@router.post("/campaigns/{cid}/import")
def import_into_campaign(cid: int, file: UploadFile = File(...), mapping: str = Form(""), db: Session = Depends(get_db)):
    campaign_service.get_campaign(db, cid)
    name, content = read_upload(file)
    m = json.loads(mapping) if mapping else None
    return import_export_service.commit(db, "leads", name, content, mapping=m, campaign_id=cid)


# --------------------------------------------------------------------- services
@router.get("/services")
def list_services(db: Session = Depends(get_db)):
    out = []
    for s in db.query(Service).order_by(Service.name).all():
        d = campaign_service.service_dict(s)
        d["lead_count"] = db.query(Lead).filter(Lead.recommended_service_id == s.id).count()
        out.append(d)
    return out


@router.post("/services", status_code=201)
def create_service(body: S.ServiceIn, db: Session = Depends(get_db)):
    return campaign_service.service_dict(campaign_service.create_service(db, dump(body)))


@router.patch("/services/{sid}")
def update_service(sid: int, body: S.ServiceBase, db: Session = Depends(get_db)):
    return campaign_service.service_dict(campaign_service.update_service(db, sid, dump(body)))


@router.delete("/services/{sid}")
def delete_service(sid: int, db: Session = Depends(get_db)):
    campaign_service.delete_service(db, sid)
    return {"deleted": True}


# --------------------------------------------------------------------- research
@router.get("/research/recent")
def recent_research(db: Session = Depends(get_db)):
    rows = db.query(Company).filter(Company.last_researched_at.isnot(None), Company.archived.is_(False)) \
        .order_by(Company.last_researched_at.desc()).limit(25).all()
    return [{"company_id": c.id, "name": c.name, "country": c.country, "last_researched_at": c.last_researched_at.isoformat(),
             "confidence": ((c.research_report or {}).get("sections", {}).get("confidence") or {}).get("level"),
             "signals": len((c.research_report or {}).get("sections", {}).get("evidence", []))} for c in rows]


@router.post("/research/run")
def run_research(body: S.ResearchIn, db: Session = Depends(get_db)):
    return company_research.run_research(db, body.company_id, use_web=body.use_web, use_ai=body.use_ai, actor="ai")


@router.post("/research/discover")
def research_discover(body: S.DiscoverIn, db: Session = Depends(get_db)):
    if body.campaign_id:
        campaign_service.get_campaign(db, body.campaign_id)
    return lead_hunter.discover_from_urls(db, body.urls, body.campaign_id)


@router.get("/research/sources")
def sources():
    return lead_hunter.list_sources()
