"""Dashboard, analytics, import/export, duplicates, audit, settings, demo data."""
from __future__ import annotations

import json
import os
from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, UploadFile
from fastapi.responses import Response
from sqlalchemy import or_
from sqlalchemy.orm import Session

from ai.providers import PROVIDERS
from api import schemas as S
from api.deps import read_upload
from config import config
from core import audit
from core.constants import ALL_STAGES, CHANNELS
from core.errors import ValidationProblem
from core.settings_store import DEFAULT_SETTINGS, get_settings, save_section
from core.utils import sanitize_text, sanitize_url, today
from database.database import get_db
from database.models import AuditLog, Company, ComplianceRecord, Lead, SuppressionEntry, Task
from engines import analytics_engine, experiment_engine
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from engines.signal_engine import catalog_entry
from engines import compliance_engine, feedback_engine
from services import (campaign_service, company_service, crm_service, demo_data, import_export_service, task_service)

router = APIRouter(prefix="/api")


@router.get("/health")
def health(db: Session = Depends(get_db)):
    db.query(Company).first()
    return {"status": "ok", "app": config.app_name}


# ------------------------------------------------------------------- dashboard
@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):
    f = analytics_engine.funnel(db)
    c = f["counts"]
    tasks = task_service.list_tasks(db)
    audit_rows = db.query(AuditLog).order_by(AuditLog.timestamp.desc()).limit(8).all()
    return {
        "kpis": {"qualified": c["qualified"], "contacted": c["contacted"], "replies": c["replies"], "meetings": c["calls"],
                 "proposals": c["proposals"], "won": c["won"], "mrr": f["mrr"], "pipeline_value": f["pipeline_value"],
                 "weighted_pipeline": f["weighted_pipeline"], "leads": c["leads"]},
        "markets": analytics_engine.markets(db),
        "priorities": crm_service.todays_priorities(db, limit=8),
        "top_opportunities": feedback_engine.top_opportunities(db, limit=5),
        "tasks": {"counts": tasks["counts"], "overdue": tasks["overdue"][:6], "today": tasks["today"][:6]},
        "funnel": f["stages"],
        "estimate_note": f["estimate_note"],
        "recent": [{"id": a.id, "timestamp": a.timestamp.isoformat(timespec="minutes"), "action": a.action, "summary": a.summary, "actor": a.actor}
                   for a in audit_rows],
        "demo": demo_data.demo_counts(db),
    }


# ------------------------------------------------------------------- analytics
@router.get("/analytics/funnel")
def funnel(campaign_id: Optional[int] = None, country: Optional[str] = None, db: Session = Depends(get_db)):
    return analytics_engine.funnel(db, campaign_id, country)


@router.get("/analytics/mrr")
def mrr(by: str = "campaign", campaign_id: Optional[int] = None, db: Session = Depends(get_db)):
    if by not in ("campaign", "industry", "country", "service", "signal", "template"):
        raise ValidationProblem("Unknown breakdown", operation="analytics", suggestion="Use campaign, industry, country, service, signal or template.")
    rows = analytics_engine.mrr_breakdown(db, by, campaign_id)
    if by == "signal":
        pass
    return rows


@router.get("/analytics/experiments")
def experiments(group_by: str = "campaign,signal,offer", campaign_id: Optional[int] = None, db: Session = Depends(get_db)):
    return experiment_engine.experiments(db, [g.strip() for g in group_by.split(",") if g.strip()], campaign_id)


# ---------------------------------------------------------------- import/export
@router.post("/import/preview")
def import_preview(kind: str = Form(...), file: UploadFile = File(...)):
    name, content = read_upload(file)
    return import_export_service.preview(kind, name, content)


@router.post("/import/commit")
def import_commit(kind: str = Form(...), file: UploadFile = File(...), mapping: str = Form(""),
                  campaign_id: Optional[int] = Form(None), db: Session = Depends(get_db)):
    name, content = read_upload(file)
    try:
        m = json.loads(mapping) if mapping else None
    except json.JSONDecodeError:
        raise ValidationProblem("Column mapping is not valid JSON", operation="import")
    return import_export_service.commit(db, kind, name, content, mapping=m, campaign_id=campaign_id)


@router.get("/export/{kind}")
def export(kind: str, format: str = "xlsx", campaign_id: Optional[int] = None, db: Session = Depends(get_db)):
    name, data, mime = import_export_service.build_export(db, kind, format, campaign_id)
    return Response(data, media_type=mime, headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ------------------------------------------------------------------- duplicates
@router.get("/duplicates")
def duplicates(db: Session = Depends(get_db)):
    return {"companies": company_service.find_duplicates(db), "people": company_service.find_person_duplicates(db)}


@router.post("/duplicates/merge")
def merge(body: S.MergeIn, db: Session = Depends(get_db)):
    res = company_service.merge_companies(db, body.primary_id, body.secondary_id, body.field_choices)
    for lid in res["lead_ids"]:
        lead = db.get(Lead, lid)
        if lead:
            qualify_lead(db, lead, actor="ai", reason="Companies were merged")
            generate_offer(db, lead, actor="ai")
    return res


@router.post("/duplicates/merge-people")
def merge_people(body: S.MergeIn, db: Session = Depends(get_db)):
    return company_service.merge_people(db, body.primary_id, body.secondary_id).as_dict()


@router.post("/duplicates/dismiss")
def dismiss(body: S.DismissIn, db: Session = Depends(get_db)):
    company_service.dismiss_duplicate(db, body.id_a, body.id_b)
    return {"dismissed": True}


# ------------------------------------------------------------------------ audit
@router.get("/audit")
def audit_log(entity_type: Optional[str] = None, action: Optional[str] = None, actor: Optional[str] = None,
              q: Optional[str] = None, limit: int = 100, offset: int = 0, db: Session = Depends(get_db)):
    qry = db.query(AuditLog)
    if entity_type:
        qry = qry.filter(AuditLog.entity_type == entity_type)
    if action:
        qry = qry.filter(AuditLog.action == action)
    if actor:
        qry = qry.filter(AuditLog.actor == actor)
    if q:
        qry = qry.filter(AuditLog.summary.ilike(f"%{q}%"))
    total = qry.count()
    rows = qry.order_by(AuditLog.timestamp.desc(), AuditLog.id.desc()).offset(offset).limit(min(limit, 500)).all()
    actions = [a for a, in db.query(AuditLog.action).distinct().order_by(AuditLog.action).all()]
    return {"total": total, "actions": actions,
            "items": [{"id": a.id, "timestamp": a.timestamp.isoformat(timespec="seconds"), "action": a.action, "entity_type": a.entity_type,
                       "entity_id": a.entity_id, "summary": a.summary, "details": a.details, "actor": a.actor} for a in rows]}


# --------------------------------------------------------------------- settings
def _num(v, name, lo=None, hi=None, integer=False):
    try:
        n = float(v)
    except (TypeError, ValueError):
        raise ValidationProblem(f"{name} must be a number", operation="save settings")
    if (lo is not None and n < lo) or (hi is not None and n > hi):
        raise ValidationProblem(f"{name} must be between {lo} and {hi}", operation="save settings")
    return int(n) if integer else n


def validate_settings(section: str, values: dict) -> dict:
    if section not in DEFAULT_SETTINGS:
        raise ValidationProblem(f"Unknown settings section '{section}'", operation="save settings", suggestion=f"Use: {', '.join(DEFAULT_SETTINGS)}")
    unknown = set(values) - set(DEFAULT_SETTINGS[section])
    if unknown:
        raise ValidationProblem(f"Unknown setting(s): {', '.join(sorted(unknown))}", operation="save settings")
    v = dict(values)
    if section == "user":
        for k in v:
            v[k] = sanitize_text(v[k], 1000 if k == "signature" else 200) or ""
    elif section == "markets":
        for k in ("countries", "regions", "industries", "technology", "ownership"):
            if k in v:
                v[k] = [sanitize_text(x, 80) for x in (v[k] if isinstance(v[k], list) else str(v[k]).split(",")) if sanitize_text(x, 80)]
        for k in ("company_size", "revenue"):
            if k in v:
                v[k] = {a: (None if b in (None, "") else _num(b, f"{k}.{a}", 0)) for a, b in dict(v[k]).items() if a in ("min", "max")}
    elif section == "pricing":
        for k in ("minimum_mrr", "target_mrr", "project_minimum"):
            if k in v:
                v[k] = _num(v[k], k, 0, 10_000_000)
        if "project_pricing_note" in v:
            v["project_pricing_note"] = sanitize_text(v["project_pricing_note"], 500) or ""
    elif section == "ai":
        if "provider" in v and v["provider"] not in PROVIDERS:
            raise ValidationProblem("Unknown AI provider", operation="save settings", suggestion=f"Use: {', '.join(PROVIDERS)}")
        if "temperature" in v:
            v["temperature"] = _num(v["temperature"], "temperature", 0, 1)
        if "research_depth" in v and v["research_depth"] not in ("quick", "standard", "deep"):
            raise ValidationProblem("Research depth must be quick, standard or deep", operation="save settings")
        if "max_tokens" in v:
            v["max_tokens"] = _num(v["max_tokens"], "max_tokens", 50, 4000, integer=True)
        for k in ("model",):
            if k in v:
                v[k] = sanitize_text(v[k], 120) or ""
        if "base_url" in v:
            v["base_url"] = (sanitize_url(v["base_url"]) or "") if v["base_url"] else ""
    elif section == "outreach":
        if "followup_intervals" in v:
            raw = v["followup_intervals"] if isinstance(v["followup_intervals"], list) else str(v["followup_intervals"]).split(",")
            v["followup_intervals"] = sorted({_num(x, "follow-up interval", 1, 365, integer=True) for x in raw if str(x).strip()})
        if "max_followups" in v:
            v["max_followups"] = _num(v["max_followups"], "max_followups", 0, 10, integer=True)
        if "nurture_wait_days" in v:
            v["nurture_wait_days"] = _num(v["nurture_wait_days"], "nurture_wait_days", 1, 90, integer=True)
        if "default_channels" in v:
            ch = v["default_channels"] if isinstance(v["default_channels"], list) else str(v["default_channels"]).split(",")
            v["default_channels"] = [c.strip() for c in ch if c.strip() in CHANNELS] or ["email"]
    elif section == "pipeline":
        est = v.get("stage_estimates", {})
        v["stage_estimates"] = {s: _num(est[s], f"estimate {s}", 0, 1) for s in ALL_STAGES if s in est}
    elif section == "analytics":
        if "min_sample_size" in v:
            v["min_sample_size"] = _num(v["min_sample_size"], "min_sample_size", 5, 1000, integer=True)
    elif section == "heuristics":
        if "revenue_per_employee" in v:
            v["revenue_per_employee"] = _num(v["revenue_per_employee"], "revenue_per_employee", 1000, 5_000_000)
        if "finance_spend_pct" in v:
            v["finance_spend_pct"] = _num(v["finance_spend_pct"], "finance_spend_pct", 0.001, 0.05)
    return v


@router.get("/settings")
def get_all_settings(db: Session = Depends(get_db)):
    return {"settings": get_settings(db),
            "env": {"openai_key_present": bool(os.getenv("OPENAI_API_KEY")), "anthropic_key_present": bool(os.getenv("ANTHROPIC_API_KEY")),
                    "local_llm_url_present": bool(os.getenv("LOCAL_LLM_BASE_URL")), "allow_private_urls": config.allow_private_urls,
                    "ceidg_token_present": bool(os.getenv("CEIDG_API_TOKEN")), "database": config.database_url.split("://")[0]},
            "providers": list(PROVIDERS), "channels": CHANNELS, "stages": ALL_STAGES,
            "app": {"name": config.app_name, "internal_name": config.internal_name}}


@router.put("/settings/{section}")
def put_settings(section: str, values: dict, db: Session = Depends(get_db)):
    clean = validate_settings(section, values)
    new = save_section(db, section, clean)
    audit.log(db, "settings_changed", f"Settings updated: {section}", details={"fields": list(clean)})
    return new


# ------------------------------------------------------------------------- demo
@router.get("/demo")
def demo_status(db: Session = Depends(get_db)):
    return demo_data.demo_counts(db)


@router.post("/demo/load")
def demo_load(db: Session = Depends(get_db)):
    return demo_data.load_demo(db)


@router.post("/demo/remove")
def demo_remove(db: Session = Depends(get_db)):
    return demo_data.remove_demo(db)


# --------------------------------------------------------------------- compliance
@router.get("/compliance/summary")
def compliance_summary(db: Session = Depends(get_db)):
    return compliance_engine.summary(db)


@router.get("/compliance/companies")
def compliance_companies(status: Optional[str] = None, q: Optional[str] = None, db: Session = Depends(get_db)):
    qry = db.query(Company).filter(Company.archived.is_(False))
    if q:
        qry = qry.filter(Company.name.ilike(f"%{q}%"))
    rows = qry.order_by(Company.name).limit(500).all()
    out = []
    for c in rows:
        st = compliance_engine.status_for(db, c.id)
        if status and st["status"] != status.upper():
            continue
        out.append({"company_id": c.id, "name": c.name, "country": c.country, **st})
    return out


@router.get("/compliance/companies/{cid}")
def compliance_for_company(cid: int, db: Session = Depends(get_db)):
    return compliance_engine.status_for(db, cid)


@router.put("/compliance/companies/{cid}")
def set_compliance(cid: int, body: S.ComplianceIn, db: Session = Depends(get_db)):
    rec = compliance_engine.set_record(db, cid, {k: v for k, v in body.model_dump().items() if v is not None or k == "notes"})
    return rec.as_dict()


@router.get("/compliance/suppression")
def list_suppression(db: Session = Depends(get_db)):
    return compliance_engine.list_suppressions(db)


@router.post("/compliance/suppression", status_code=201)
def add_suppression(body: S.SuppressionIn, db: Session = Depends(get_db)):
    entry, created = compliance_engine.add_suppression(db, body.match_type, body.value, reason=body.reason, note=body.note)
    return {"entry": entry.as_dict(), "created": created}


@router.delete("/compliance/suppression/{eid}")
def delete_suppression(eid: int, db: Session = Depends(get_db)):
    compliance_engine.remove_suppression(db, eid)
    return {"deleted": True}


# --------------------------------------------------------------------- feedback / self-learning
@router.get("/feedback/sources")
def feedback_sources(campaign_id: Optional[int] = None, db: Session = Depends(get_db)):
    return feedback_engine.source_quality(db, campaign_id)


@router.get("/feedback/industries")
def feedback_industries(campaign_id: Optional[int] = None, db: Session = Depends(get_db)):
    return feedback_engine.industry_quality(db, campaign_id)


@router.get("/feedback/signals")
def feedback_signals(campaign_id: Optional[int] = None, db: Session = Depends(get_db)):
    return feedback_engine.signal_quality(db, campaign_id)


@router.get("/feedback/disqualifications")
def feedback_disqualifications(campaign_id: Optional[int] = None, db: Session = Depends(get_db)):
    return feedback_engine.disqualification_breakdown(db, campaign_id)


@router.get("/feedback/top-opportunities")
def feedback_top_opportunities(limit: int = 5, campaign_id: Optional[int] = None, db: Session = Depends(get_db)):
    return feedback_engine.top_opportunities(db, limit=min(limit, 20), campaign_id=campaign_id)
