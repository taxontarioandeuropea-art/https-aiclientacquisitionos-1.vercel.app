from __future__ import annotations

from datetime import date, datetime
from typing import Optional

from fastapi import UploadFile

from config import config
from core.errors import AppError
from core.utils import parse_date


def dump(model) -> dict:
    return model.model_dump(exclude_unset=True)


def read_upload(file: UploadFile) -> tuple[str, bytes]:
    limit = config.max_upload_mb * 1024 * 1024
    content = file.file.read(limit + 1)
    if len(content) > limit:
        raise AppError(f"The file is larger than {config.max_upload_mb} MB", operation="upload file",
                       cause="Upload size limit exceeded.", suggestion="Split the file or raise MAX_UPLOAD_MB in .env.", status_code=413)
    return file.filename or "upload", content


def to_dt(value: Optional[str]) -> Optional[datetime]:
    d = parse_date(value)
    return datetime.combine(d, datetime.min.time()) if d else None
