"""HTML pages. They are thin shells: data is loaded from the JSON API so business logic stays out of the UI."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from config import config
from core.errors import NotFound
from database.database import get_db
from database.models import Company
from services import demo_data

router = APIRouter()

NAV = [("dashboard", "Dashboard", "/"), ("leads", "Leads", "/leads"), ("companies", "Companies", "/companies"),
       ("pipeline", "Pipeline", "/pipeline"), ("campaigns", "Campaigns", "/campaigns"), ("tasks", "Tasks", "/tasks"),
       ("services", "Services", "/services"), ("analytics", "Analytics", "/analytics"), ("research", "Research", "/research"),
       ("poland", "Poland Registries", "/poland"), ("settings", "Settings", "/settings")]
NAV_SECONDARY = [("compliance", "Compliance", "/compliance"), ("data", "Import / Export", "/data"), ("audit", "Audit log", "/audit")]


def page(name: str, title: str):
    def handler(request: Request, db: Session = Depends(get_db)):
        return request.app.state.templates.TemplateResponse(request, f"{name}.html", {
            "active": name, "title": title, "app_name": config.app_name, "nav": NAV, "nav2": NAV_SECONDARY,
            "demo_count": demo_data.demo_counts(db)["companies"]})
    return handler


for n, label, path in NAV + NAV_SECONDARY:
    router.add_api_route(path, page(n, label), methods=["GET"], include_in_schema=False, name=f"page_{n}")


@router.get("/companies/{cid}", include_in_schema=False)
def company_page(cid: int, request: Request, db: Session = Depends(get_db)):
    c = db.get(Company, cid)
    if not c:
        raise NotFound("Company", cid)
    return request.app.state.templates.TemplateResponse(request, "company.html", {
        "active": "companies", "title": c.name, "company_id": cid, "app_name": config.app_name, "nav": NAV, "nav2": NAV_SECONDARY,
        "demo_count": demo_data.demo_counts(db)["companies"]})
