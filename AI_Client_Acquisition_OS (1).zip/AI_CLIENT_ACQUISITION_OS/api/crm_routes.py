"""Companies, contacts, leads, pipeline, signals, messages, tasks."""
from __future__ import annotations

import json
from typing import Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session

from api import schemas as S
from api.deps import dump, to_dt
from core import audit
from core.errors import AppError, NotFound, ValidationProblem
from core.utils import parse_date, utcnow
from database.database import get_db
from database.models import Company, Interaction, Lead, OutreachMessage, Person, Signal, Task
from engines import company_research, compliance_engine, followup_engine, message_engine
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from engines.signal_engine import add_signal, catalog_public, serialize_signal
from services import (company_service, crm_service, import_export_service, lead_service, serializers, task_service)

router = APIRouter(prefix="/api")


# ------------------------------------------------------------------ companies
@router.get("/companies")
def list_companies(q: Optional[str] = None, country: Optional[str] = None, industry: Optional[str] = None,
                   campaign_id: Optional[int] = None, min_employees: Optional[int] = None, max_employees: Optional[int] = None,
                   signal: Optional[str] = None, sort: str = "name", dir: str = "asc", limit: int = Query(300, le=1000),
                   offset: int = 0, db: Session = Depends(get_db)):
    return company_service.list_companies(db, q=q, country=country, industry=industry, campaign_id=campaign_id,
                                          min_employees=min_employees, max_employees=max_employees, signal=signal,
                                          sort=sort, direction=dir, limit=limit, offset=offset)


@router.post("/companies", status_code=201)
def create_company(body: S.CompanyIn, db: Session = Depends(get_db)):
    data = dump(body)
    dups = company_service.find_matches_for(db, data)
    c = company_service.create_company(db, data)
    return {"company": c.as_dict(), "possible_duplicates": dups}


def _company_profile(db: Session, c: Company) -> dict:
    sigs = lead_service.signals_by_company(db, [c.id]).get(c.id, [])
    leads = db.query(Lead).filter(Lead.company_id == c.id).all()
    lead_ids = [l.id for l in leads]
    d = c.as_dict()
    d.pop("research_report", None)
    return {
        "company": d,
        "people": [p.as_dict() for p in c.people],
        "signals": [serialize_signal(s) for s in sorted(sigs, key=lambda s: s.date_detected, reverse=True)],
        "leads": [serializers.lead_dict(l, {c.id: sigs}) for l in leads],
        "interactions": [i.as_dict() for i in db.query(Interaction).filter(Interaction.company_id == c.id).order_by(Interaction.occurred_at.desc()).limit(50)],
        "tasks": [task_service.serialize_task(t) for t in db.query(Task).filter(
            (Task.company_id == c.id) | (Task.lead_id.in_(lead_ids or [-1]))).order_by(Task.status, Task.due_date).all()],
        "messages": [serializers.message_dict(m) for m in db.query(OutreachMessage).filter(OutreachMessage.lead_id.in_(lead_ids or [-1])).order_by(OutreachMessage.created_at.desc()).all()],
        "report": c.research_report,
        "duplicates": company_service.find_matches_for(db, c.as_dict(), exclude_id=c.id),
    }


@router.get("/companies/{cid}")
def get_company(cid: int, db: Session = Depends(get_db)):
    return _company_profile(db, company_service.get_company(db, cid))


@router.patch("/companies/{cid}")
def update_company(cid: int, body: S.CompanyBase, db: Session = Depends(get_db)):
    return company_service.update_company(db, cid, dump(body)).as_dict()


@router.delete("/companies/{cid}")
def delete_company(cid: int, db: Session = Depends(get_db)):
    company_service.delete_company(db, cid)
    return {"deleted": True}


@router.post("/companies/{cid}/people", status_code=201)
def add_person(cid: int, body: S.PersonIn, db: Session = Depends(get_db)):
    return company_service.create_person(db, cid, dump(body)).as_dict()


@router.patch("/people/{pid}")
def update_person(pid: int, body: S.PersonIn, db: Session = Depends(get_db)):
    return company_service.update_person(db, pid, dump(body)).as_dict()


@router.delete("/people/{pid}")
def delete_person(pid: int, db: Session = Depends(get_db)):
    company_service.delete_person(db, pid)
    return {"deleted": True}


@router.post("/companies/{cid}/research")
def research_company(cid: int, use_web: bool = True, use_ai: bool = False, db: Session = Depends(get_db)):
    return company_research.run_research(db, cid, use_web=use_web, use_ai=use_ai, actor="ai")


@router.post("/companies/{cid}/qualify")
def qualify_company(cid: int, db: Session = Depends(get_db)):
    c = company_service.get_company(db, cid)
    out = []
    for lead in c.leads:
        r = qualify_lead(db, lead, actor="ai")
        generate_offer(db, lead, actor="ai")
        task_service.generate_tasks_for_lead(db, lead)
        out.append({"lead_id": lead.id, "priority": r["overall"]["priority"], "levels": r["levels"]})
    return {"leads": out}


@router.get("/companies/{cid}/export")
def export_company(cid: int, format: str = "md", db: Session = Depends(get_db)):
    c = company_service.get_company(db, cid)
    report = c.research_report or company_research.build_report(db, c)
    audit.log(db, "export", f"Exported company {c.name} as {format}", entity_type="company", entity_id=c.id)
    fname = "".join(ch if ch.isalnum() else "_" for ch in c.name)[:40]
    if format == "json":
        return Response(json.dumps(report, indent=2, default=str), media_type="application/json",
                        headers={"Content-Disposition": f'attachment; filename="{fname}.json"'})
    if format in ("xlsx", "csv"):
        rows = [{"Signal": e["signal"], "Evidence": e["evidence_text"], "Source": e["source"], "URL": e["source_url"],
                 "Date": e["date_detected"], "Verified": e["verified"], "Kind": e["kind"]} for e in report["sections"]["evidence"]] or [{"Signal": "(none)"}]
        cols = list(rows[0].keys())
        if format == "csv":
            return Response(import_export_service._csv_bytes(cols, rows), media_type="text/csv",
                            headers={"Content-Disposition": f'attachment; filename="{fname}.csv"'})
        return Response(import_export_service._xlsx_bytes({"Evidence": (cols, rows)}),
                        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        headers={"Content-Disposition": f'attachment; filename="{fname}.xlsx"'})
    return Response(company_research.report_to_markdown(report, c.name), media_type="text/markdown; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{fname}.md"'})


# ---------------------------------------------------------------------- leads
@router.get("/leads")
def list_leads(q: Optional[str] = None, country: Optional[str] = None, industry: Optional[str] = None,
               campaign_id: Optional[int] = None, priority: Optional[str] = None, stage: Optional[str] = None,
               min_mrr: Optional[float] = None, max_mrr: Optional[float] = None, signal: Optional[str] = None,
               service: Optional[str] = None, date_from: Optional[str] = None, date_to: Optional[str] = None,
               sort: str = "priority", dir: str = "desc", limit: int = Query(300, le=2000), offset: int = 0,
               db: Session = Depends(get_db)):
    return lead_service.list_leads(db, q=q, country=country, industry=industry, campaign_id=campaign_id, priority=priority,
                                   stage=stage, min_mrr=min_mrr, max_mrr=max_mrr, signal=signal, service=service,
                                   date_from=date_from, date_to=date_to, sort=sort, direction=dir, limit=limit, offset=offset)


@router.post("/leads", status_code=201)
def create_lead(body: S.LeadIn, db: Session = Depends(get_db)):
    if bool(body.company_id) == bool(body.company):
        raise ValidationProblem("Provide either an existing company_id or a new company", operation="create lead")
    dups = []
    if body.company:
        data = dump(body.company)
        dups = company_service.find_matches_for(db, data)
        company = company_service.create_company(db, data)
        cid = company.id
    else:
        cid = body.company_id
    pid = body.person_id
    if body.person:
        pid = company_service.create_person(db, cid, dump(body.person)).id
    lead, created = lead_service.create_lead(db, company_id=cid, campaign_id=body.campaign_id, person_id=pid)
    qualify_lead(db, lead, actor="ai")
    generate_offer(db, lead, actor="ai")
    return {"lead": lead_service.lead_detail(db, lead.id), "created": created, "possible_duplicates": dups}


@router.get("/leads/{lid}")
def get_lead(lid: int, db: Session = Depends(get_db)):
    return lead_service.lead_detail(db, lid)


@router.patch("/leads/{lid}")
def update_lead(lid: int, body: S.LeadPatch, db: Session = Depends(get_db)):
    lead_service.update_lead(db, lid, dump(body))
    return lead_service.lead_detail(db, lid)


@router.delete("/leads/{lid}")
def delete_lead(lid: int, db: Session = Depends(get_db)):
    lead_service.delete_lead(db, lid)
    return {"deleted": True}


@router.post("/leads/{lid}/stage")
def move_stage(lid: int, body: S.StageIn, db: Session = Depends(get_db)):
    crm_service.move_stage(db, lid, body.stage, actor="user", note=body.note, actual_mrr=body.actual_mrr,
                           lost_reason=body.lost_reason, disqualify_reason=body.disqualify_reason)
    return lead_service.lead_detail(db, lid)


@router.post("/leads/{lid}/qualify")
def qualify(lid: int, db: Session = Depends(get_db)):
    lead = lead_service.get_lead(db, lid)
    qualify_lead(db, lead, actor="ai")
    generate_offer(db, lead, actor="ai")
    return lead_service.lead_detail(db, lid)


@router.post("/leads/{lid}/offer")
def offer(lid: int, db: Session = Depends(get_db)):
    lead = lead_service.get_lead(db, lid)
    if not lead.qualification:
        qualify_lead(db, lead, actor="ai")
    res = generate_offer(db, lead, actor="ai")
    return {"offer": res, "lead": lead_service.lead_detail(db, lid)}


@router.post("/leads/{lid}/messages/generate")
def generate_message(lid: int, body: S.GenerateMessageIn, db: Session = Depends(get_db)):
    if body.followup_step:
        m = message_engine.generate_followup(db, lid, body.followup_step, channel=body.channel)
        msgs = [m] if m else []
    else:
        msgs = message_engine.generate_messages(db, lid, channel=body.channel, use_ai=body.use_ai)
    return {"messages": [serializers.message_dict(m) for m in msgs], "lead": lead_service.lead_detail(db, lid)}


@router.post("/leads/{lid}/interactions", status_code=201)
def add_interaction(lid: int, body: S.InteractionIn, db: Session = Depends(get_db)):
    it = crm_service.log_interaction(db, lead_id=lid, type=body.type, direction=body.direction, subject=body.subject,
                                     body=body.body, outcome=body.outcome, occurred_at=to_dt(body.occurred_at))
    suggestion = "CALL" if body.type in ("call", "meeting") else None
    return {"interaction": it.as_dict(), "suggested_stage": suggestion, "lead": lead_service.lead_detail(db, lid)}


@router.post("/leads/{lid}/tasks", status_code=201)
def add_lead_task(lid: int, body: S.TaskIn, db: Session = Depends(get_db)):
    t = task_service.create_task(db, body.title, due_date=parse_date(body.due_date), task_type=body.task_type, priority=body.priority,
                                 description=body.description, lead_id=lid)
    lead_service.get_lead(db, lid)
    task_service.sync_next_action(db, db.get(Lead, lid))
    return task_service.serialize_task(t)


@router.get("/pipeline")
def pipeline(campaign_id: Optional[int] = None, country: Optional[str] = None, q: Optional[str] = None, db: Session = Depends(get_db)):
    return crm_service.pipeline_board(db, campaign_id=campaign_id, country=country, q=q)


# -------------------------------------------------------------------- signals
@router.get("/signals/catalog")
def signal_catalog():
    return catalog_public()


@router.post("/signals", status_code=201)
def create_signal(body: S.SignalIn, db: Session = Depends(get_db)):
    sig, created = add_signal(db, body.company_id, body.signal_type, body.evidence_text, body.source, description=body.description,
                              source_url=body.source_url, confidence=body.confidence, kind=body.kind, origin="manual",
                              date_detected=parse_date(body.date_detected))
    for lead in db.query(Lead).filter(Lead.company_id == body.company_id).all():
        qualify_lead(db, lead, actor="ai", reason=f"Signal added: {sig.signal_type}")
        generate_offer(db, lead, actor="ai")
    return {"signal": serialize_signal(sig), "created": created}


@router.delete("/signals/{sid}")
def delete_signal(sid: int, db: Session = Depends(get_db)):
    s = db.get(Signal, sid)
    if not s:
        raise NotFound("Signal", sid)
    cid = s.company_id
    audit.log(db, "signal_deleted", f"Signal deleted: {s.signal_type}", entity_type="signal", entity_id=s.id, details={"snapshot": s.as_dict()})
    db.delete(s)
    db.flush()
    for lead in db.query(Lead).filter(Lead.company_id == cid).all():
        qualify_lead(db, lead, actor="ai", reason="A signal was removed")
    return {"deleted": True}


# ------------------------------------------------------------------- messages
def _msg(db: Session, mid: int) -> OutreachMessage:
    m = db.get(OutreachMessage, mid)
    if not m:
        raise NotFound("Message", mid)
    return m


@router.get("/messages")
def list_messages(lead_id: Optional[int] = None, status: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(OutreachMessage)
    if lead_id:
        q = q.filter(OutreachMessage.lead_id == lead_id)
    if status:
        q = q.filter(OutreachMessage.status == status)
    return [serializers.message_dict(m) for m in q.order_by(OutreachMessage.created_at.desc()).limit(300)]


@router.patch("/messages/{mid}")
def edit_message(mid: int, body: S.MessagePatch, db: Session = Depends(get_db)):
    m = _msg(db, mid)
    if m.status in ("sent", "replied"):
        raise AppError("A sent message cannot be edited", operation="edit message", suggestion="Generate a new draft instead.", status_code=409)
    for k, v in dump(body).items():
        setattr(m, k, v)
    if m.status == "approved":
        m.status, m.approved_at = "draft", None      # edits require re-approval
    if "[Your name]" not in (m.body or "") and "[Your name]" not in (m.subject or ""):
        m.warnings = [w for w in (m.warnings or []) if "placeholder was used" not in w]
    audit.log(db, "message_edited", f"Message edited (lead {m.lead_id})", entity_type="message", entity_id=m.id)
    return serializers.message_dict(m)


@router.post("/messages/{mid}/approve")
def approve_message(mid: int, db: Session = Depends(get_db)):
    m = _msg(db, mid)
    if m.status != "draft":
        raise AppError(f"Only drafts can be approved (this one is {m.status})", operation="approve message", status_code=409)
    if "[Your name]" in m.body or "{" in m.body and "}" in m.body:
        raise AppError("The message still contains a placeholder", operation="approve message",
                       cause="A placeholder such as [Your name] or {field} is present in the text.",
                       suggestion="Set your name/signature in Settings → User, or edit the message, then approve.")
    compliance_engine.check_before_approve(db, m.lead)
    m.status, m.approved_at = "approved", utcnow()
    audit.log(db, "message_approved", f"Message approved for sending (lead {m.lead_id})", entity_type="message", entity_id=m.id)
    return serializers.message_dict(m)


@router.post("/messages/{mid}/send")
def mark_sent(mid: int, body: S.SendIn, db: Session = Depends(get_db)):
    m = _msg(db, mid)
    if m.status != "approved":
        raise AppError("Approve the message before marking it as sent", operation="mark message sent",
                       cause="The application never sends messages itself: you approve, send it from your own email/LinkedIn, then record it here.",
                       suggestion="Approve the draft first.", status_code=409)
    followup_engine.mark_sent(db, mid, sent_at=to_dt(body.sent_at), actor="user")
    return {"message": serializers.message_dict(m), "lead": lead_service.lead_detail(db, m.lead_id)}


@router.post("/messages/{mid}/reply")
def mark_replied(mid: int, db: Session = Depends(get_db)):
    m = _msg(db, mid)
    if m.status not in ("sent", "replied"):
        raise AppError("Only sent messages can be marked as replied", operation="mark reply", status_code=409)
    followup_engine.mark_replied(db, mid, actor="user")
    crm_service.log_interaction(db, lead_id=m.lead_id, type=m.channel if m.channel in ("email", "linkedin") else "other",
                                direction="inbound", subject="Reply received", body="(marked as replied)", message_id=m.id)
    return {"message": serializers.message_dict(m), "lead": lead_service.lead_detail(db, m.lead_id)}


@router.post("/messages/{mid}/reject")
def reject_message(mid: int, db: Session = Depends(get_db)):
    m = _msg(db, mid)
    if m.status in ("sent", "replied"):
        raise AppError("A sent message cannot be rejected", operation="reject message", status_code=409)
    m.status = "rejected"
    return serializers.message_dict(m)


@router.delete("/messages/{mid}")
def delete_message(mid: int, db: Session = Depends(get_db)):
    m = _msg(db, mid)
    if m.status in ("sent", "replied"):
        raise AppError("Sent messages are part of your history and cannot be deleted", operation="delete message", status_code=409)
    audit.log(db, "message_deleted", f"Draft deleted (lead {m.lead_id})", entity_type="message", entity_id=m.id, details={"snapshot": m.as_dict()})
    db.delete(m)
    return {"deleted": True}


# ---------------------------------------------------------------------- tasks
@router.get("/tasks")
def list_tasks(lead_id: Optional[int] = None, company_id: Optional[int] = None, db: Session = Depends(get_db)):
    return task_service.list_tasks(db, lead_id=lead_id, company_id=company_id)


@router.post("/tasks", status_code=201)
def create_task(body: S.TaskIn, db: Session = Depends(get_db)):
    t = task_service.create_task(db, body.title, due_date=parse_date(body.due_date), task_type=body.task_type, priority=body.priority,
                                 description=body.description, lead_id=body.lead_id, company_id=body.company_id)
    return task_service.serialize_task(t)


@router.patch("/tasks/{tid}")
def update_task(tid: int, body: S.TaskPatch, db: Session = Depends(get_db)):
    return task_service.serialize_task(task_service.update_task(db, tid, dump(body)))


@router.post("/tasks/{tid}/complete")
def complete_task(tid: int, db: Session = Depends(get_db)):
    return task_service.serialize_task(task_service.complete_task(db, tid))


@router.delete("/tasks/{tid}")
def delete_task(tid: int, db: Session = Depends(get_db)):
    task_service.delete_task(db, tid)
    return {"deleted": True}


@router.post("/tasks/generate")
def generate_tasks(campaign_id: Optional[int] = None, db: Session = Depends(get_db)):
    return {"created": task_service.generate_all(db, campaign_id)}
