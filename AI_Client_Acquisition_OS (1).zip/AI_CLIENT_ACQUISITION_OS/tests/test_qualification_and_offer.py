"""Qualification (five separate dimensions, never one opaque score) and service matching."""
import pytest

from core.errors import InsufficientEvidence, ValidationProblem
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from engines.signal_engine import add_signal
from services import campaign_service, company_service, lead_service


@pytest.fixture()
def trucking_campaign(db):
    return campaign_service.create_campaign(db, {
        "name": "USA Trucking", "country": "USA", "industry": "Transportation / Trucking",
        "target_employees_min": 5, "target_employees_max": 100, "minimum_mrr": 1000, "target_mrr": 1500,
    })


@pytest.fixture()
def controller_service(db):
    return campaign_service.create_service(db, {
        "name": "Controller Support", "pricing_model": "monthly", "minimum_price": 1200, "target_mrr": 1800,
        "required_signals": ["hiring_controller"], "deliverables": ["Monthly close"],
    })


def test_qualify_lead_with_no_evidence_is_unknown_and_low(db, trucking_campaign):
    company = company_service.create_company(db, {"name": "Empty Co", "country": "USA",
                                                    "industry": "Transportation / Trucking", "employees": 20})
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=trucking_campaign.id)
    result = qualify_lead(db, lead)
    assert result["dimensions"]["need"]["level"] == "UNKNOWN"
    assert result["dimensions"]["signal"]["level"] == "UNKNOWN"
    assert result["overall"]["priority"] in ("MEDIUM", "LOW")  # never HIGH without evidence


def test_qualify_lead_with_strong_evidence_scores_high_on_matching_dimensions(db, trucking_campaign):
    company = company_service.create_company(db, {"name": "Prairie Line Freight", "country": "USA",
                                                    "industry": "Transportation / Trucking", "employees": 42,
                                                    "estimated_revenue": 7_800_000, "growth_status": "Growing"})
    company_service.create_person(db, company.id, {"full_name": "Dana Whitfield", "title": "Owner"})
    add_signal(db, company.id, "hiring_controller",
               "Controller: responsible for monthly close, financial reporting and QuickBooks oversight.",
               "Company careers page", confidence=0.9)
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=trucking_campaign.id)

    result = qualify_lead(db, lead)

    assert result["dimensions"]["fit"]["level"] == "HIGH"
    assert result["dimensions"]["need"]["level"] == "HIGH"
    assert result["dimensions"]["signal"]["level"] == "HIGH"
    assert result["overall"]["priority"] == "HIGH"
    # the qualification never collapses to a single opaque score: all five dimensions are present
    assert set(result["dimensions"]) == {"fit", "need", "signal", "ability_to_pay", "contactability"}


def test_qualification_never_fabricates_a_signal(db):
    """add_signal refuses evidence that is too short or has no source — this is the anti-fabrication guarantee."""
    company = company_service.create_company(db, {"name": "Test Co"})
    with pytest.raises(ValidationProblem):
        add_signal(db, company.id, "hiring_controller", "short", "")  # no source
    with pytest.raises(ValidationProblem):
        add_signal(db, company.id, "hiring_controller", "abc", "Careers page")  # evidence too short


def test_core_icp_mismatch_caps_fit_score(db):
    """A country/industry/ownership mismatch caps fit at Medium even if everything else matches."""
    campaign = campaign_service.create_campaign(db, {
        "name": "Poland Only", "country": "Poland", "target_ownership": "Foreign-owned",
        "target_employees_min": 10, "target_employees_max": 200,
    })
    company = company_service.create_company(db, {"name": "Polish Co", "country": "Poland",
                                                    "ownership_type": "Polish-owned", "employees": 50})
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=campaign.id)
    result = qualify_lead(db, lead)
    assert result["dimensions"]["fit"]["level"] != "HIGH"


def test_service_matching_requires_matching_signal_evidence(db, trucking_campaign, controller_service):
    trucking_campaign.services.append(controller_service)
    db.flush()
    company = company_service.create_company(db, {"name": "No Evidence Co", "country": "USA", "employees": 30})
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=trucking_campaign.id)
    qualify_lead(db, lead)
    result = generate_offer(db, lead)
    assert result["recommended"] is None  # no fabricated recommendation without evidence
    db.refresh(lead)
    assert lead.recommended_service is None


def test_service_matching_recommends_the_service_whose_signal_matched(db, trucking_campaign, controller_service):
    trucking_campaign.services.append(controller_service)
    db.flush()
    company = company_service.create_company(db, {"name": "Hiring Co", "country": "USA", "employees": 40,
                                                    "estimated_revenue": 6_000_000})
    add_signal(db, company.id, "hiring_controller", "We are hiring a controller to own the monthly close.",
               "Careers page")
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=trucking_campaign.id)
    qualify_lead(db, lead)
    result = generate_offer(db, lead)
    best = result["recommended"]
    assert best["service"] == "Controller Support"
    assert best["potential_mrr"] > 0
    # every reason must cite evidence or a structural fact, never invented text
    assert all(r.get("kind") in ("FACT", "INFERENCE", "RECOMMENDATION") for r in best["reasons"])
    db.refresh(lead)
    assert lead.recommended_service == "Controller Support"
