"""CSV import (column auto-mapping, validation, dedupe-on-import) and export."""
import io

from adapters.mapping import auto_map
from services import import_export_service


def test_auto_map_matches_common_header_variants():
    headers = ["Company Name", "Website", "First Name", "Last Name", "Job Title", "Email", "# Employees", "Country"]
    mapping = auto_map(headers, "leads")
    assert mapping["Company Name"] == "company.name"
    assert mapping["Website"] == "company.website"
    assert mapping["Email"] == "person.email"
    assert mapping["# Employees"] == "company.employees"


def test_auto_map_routes_bare_email_to_company_for_companies_kind():
    mapping = auto_map(["Name", "Email"], "companies")
    assert mapping["Email"] == "company.email"


def test_import_preview_reports_row_count_and_mapping(client):
    csv = b"Company Name,Website,Email\nAcme Freight LLC,https://acme.example,jane@acme.example\n"
    r = client.post("/api/import/preview", data={"kind": "leads"}, files={"file": ("x.csv", csv, "text/csv")})
    assert r.status_code == 200
    body = r.json()
    assert body["row_count"] == 1
    assert body["mapping"]["Company Name"] == "company.name"


def test_import_commit_creates_company_and_lead(client):
    csv = b"Company Name,Website,Email\nAcme Freight LLC,https://acme.example,jane@acme.example\n"
    campaigns = client.post("/api/campaigns", json={"name": "Test Campaign", "country": "USA"}).json()
    r = client.post("/api/import/commit", data={"kind": "leads", "campaign_id": str(campaigns["id"])},
                    files={"file": ("x.csv", csv, "text/csv")})
    assert r.status_code == 200
    body = r.json()
    assert body["created_companies"] == 1
    assert body["created_leads"] == 1


def test_import_commit_flags_similar_company_without_merging(client):
    csv1 = b"Company Name\nAcme Freight LLC\n"
    csv2 = b"Company Name\nAcme Freight\n"
    client.post("/api/import/commit", data={"kind": "companies"}, files={"file": ("a.csv", csv1, "text/csv")})
    r2 = client.post("/api/import/commit", data={"kind": "companies"}, files={"file": ("b.csv", csv2, "text/csv")})
    body = r2.json()
    assert body["created_companies"] == 1
    assert len(body["flagged_duplicates"]) == 1
    companies = client.get("/api/companies").json()["items"]
    assert len(companies) == 2  # both records kept; nothing was silently merged


def test_import_rejects_invalid_email_but_keeps_other_rows(client):
    csv = (b"Company Name,Email\n"
           b"Good Co,good@good.example\n"
           b"Bad Co,not-an-email\n")
    r = client.post("/api/import/commit", data={"kind": "companies"}, files={"file": ("x.csv", csv, "text/csv")})
    body = r.json()
    assert body["created_companies"] == 1
    assert body["skipped"] == 1
    assert len(body["errors"]) == 1


def test_import_rejects_disallowed_file_type(client):
    r = client.post("/api/import/preview", data={"kind": "leads"},
                    files={"file": ("x.exe", b"MZ", "application/octet-stream")})
    assert r.status_code in (400, 422)


def test_export_neutralises_formula_injection(db):
    from services import company_service
    company_service.create_company(db, {"name": "=HYPERLINK(\"http://evil\")", "country": "USA"})
    name, data, mime = import_export_service.build_export(db, "leads", "csv")
    text = data.decode("utf-8-sig")
    assert "=HYPERLINK" not in text or text.count("=HYPERLINK") == 0


def test_export_leads_produces_a_row_per_lead(client):
    campaigns = client.post("/api/campaigns", json={"name": "Test Campaign", "country": "USA"}).json()
    client.post("/api/leads", json={"company": {"name": "Acme Co"}, "campaign_id": campaigns["id"]})
    r = client.get("/api/export/leads?format=csv")
    assert r.status_code == 200
    text = r.content.decode("utf-8-sig")
    assert "Acme Co" in text
