"""CRM pipeline stage transitions and automatic task generation."""
import pytest

from core.errors import AppError, ValidationProblem
from engines.qualification_engine import qualify_lead
from services import campaign_service, company_service, crm_service, lead_service, task_service


@pytest.fixture()
def lead(db):
    campaign = campaign_service.create_campaign(db, {"name": "Test Campaign", "country": "USA"})
    company = company_service.create_company(db, {"name": "Test Co", "country": "USA", "employees": 20})
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=campaign.id)
    return lead


def test_new_lead_gets_a_research_task(db, lead):
    tasks = task_service.list_tasks(db, lead_id=lead.id)
    titles = [t["title"] for t in tasks["today"] + tasks["overdue"] + tasks["upcoming"] + tasks["no_date"]]
    assert any("Research" in t for t in titles)


def test_move_stage_updates_status_and_logs_history(db, lead):
    crm_service.move_stage(db, lead.id, "RESEARCHED", actor="user")
    db.refresh(lead)
    assert lead.status == "RESEARCHED"
    assert any(h.to_stage == "RESEARCHED" for h in lead.history)


def test_move_stage_rejects_unknown_stage(db, lead):
    with pytest.raises((ValidationProblem, AppError)):
        crm_service.move_stage(db, lead.id, "NOT_A_REAL_STAGE", actor="user")


def test_won_requires_actual_mrr(db, lead):
    with pytest.raises((ValidationProblem, AppError)):
        crm_service.move_stage(db, lead.id, "WON", actor="user")
    crm_service.move_stage(db, lead.id, "WON", actor="user", actual_mrr=1500)
    db.refresh(lead)
    assert lead.status == "WON"
    assert lead.actual_mrr == 1500


def test_lost_requires_a_reason(db, lead):
    with pytest.raises((ValidationProblem, AppError)):
        crm_service.move_stage(db, lead.id, "LOST", actor="user")
    crm_service.move_stage(db, lead.id, "LOST", actor="user", lost_reason="No budget")
    db.refresh(lead)
    assert lead.status == "LOST"
    assert lead.lost_reason == "No budget"


def test_automation_cannot_close_a_deal(db, lead):
    """Only a human (actor='user') may move a lead to WON or LOST — this is a hard rule, not a UI nicety."""
    with pytest.raises(AppError):
        crm_service.move_stage(db, lead.id, "WON", actor="ai", actual_mrr=1000)
    with pytest.raises(AppError):
        crm_service.move_stage(db, lead.id, "LOST", actor="system", lost_reason="whatever")


def test_pipeline_board_groups_leads_by_stage(db, lead):
    board = crm_service.pipeline_board(db)
    stage_keys = [s["stage"] for s in board["stages"]]
    assert "NEW" in stage_keys
    new_lane = next(s for s in board["stages"] if s["stage"] == "NEW")
    assert any(l["id"] == lead.id for l in new_lane["leads"])


def test_task_service_marks_task_done(db, lead):
    t = task_service.create_task(db, "Custom follow-up", lead_id=lead.id)
    task_service.complete_task(db, t.id)
    db.refresh(t)
    assert t.status == "done"
    assert t.completed_at is not None


def test_reply_interaction_advances_stage_and_stops_followups(db, lead):
    crm_service.move_stage(db, lead.id, "CONTACTED", actor="user")
    crm_service.log_interaction(db, lead_id=lead.id, type="email", direction="inbound", subject="Re", body="Interested")
    db.refresh(lead)
    assert lead.status == "REPLIED"
