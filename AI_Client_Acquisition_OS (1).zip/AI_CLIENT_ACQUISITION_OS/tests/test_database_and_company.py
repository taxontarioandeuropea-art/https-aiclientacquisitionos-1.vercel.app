"""Database setup and company/contact CRUD, including deduplication and merging."""
import pytest

from core.errors import NotFound, ValidationProblem
from services import company_service


def test_database_initialises_all_core_tables(db):
    from database.models import Company, Lead, Person, Signal, Campaign, Service
    assert db.query(Company).count() == 0
    assert db.query(Lead).count() == 0
    assert db.query(Person).count() == 0
    assert db.query(Signal).count() == 0
    assert db.query(Campaign).count() == 0
    assert db.query(Service).count() == 0


def test_create_company_requires_a_name(db):
    with pytest.raises(ValidationProblem):
        company_service.create_company(db, {"website": "https://example.com"})


def test_create_company_normalises_derived_fields(db):
    c = company_service.create_company(db, {"name": "ABC Logistics LLC", "website": "https://www.abc.example/"})
    assert c.domain == "abc.example"
    assert c.normalized_name == "abc logistics"


def test_get_company_missing_raises_not_found(db):
    with pytest.raises(NotFound):
        company_service.get_company(db, 999)


def test_create_person_requires_name_or_email(db):
    c = company_service.create_company(db, {"name": "Test Co"})
    with pytest.raises(ValidationProblem):
        company_service.create_person(db, c.id, {"title": "Owner"})


def test_create_person_classifies_decision_maker_level(db):
    c = company_service.create_company(db, {"name": "Test Co"})
    p = company_service.create_person(db, c.id, {"full_name": "Dana Whitfield", "title": "Owner"})
    assert p.decision_maker_level == "decision_maker"


def test_create_person_rejects_invalid_email(db):
    c = company_service.create_company(db, {"name": "Test Co"})
    with pytest.raises(ValidationProblem):
        company_service.create_person(db, c.id, {"full_name": "Bob", "email": "not-an-email"})


def test_duplicate_detection_flags_same_domain_as_very_likely(db):
    a = company_service.create_company(db, {"name": "Acme Freight", "website": "https://acme.example"})
    b = company_service.create_company(db, {"name": "Acme Freight Inc", "website": "https://acme.example"})
    dups = company_service.find_duplicates(db)
    pair_ids = {tuple(sorted((d["a"]["id"], d["b"]["id"]))) for d in dups}
    assert (a.id, b.id) in pair_ids or (b.id, a.id) in pair_ids
    match = next(d for d in dups if {d["a"]["id"], d["b"]["id"]} == {a.id, b.id})
    assert match["score"] >= 0.85
    assert match["label"] == "Very likely"


def test_duplicate_detection_ignores_unrelated_companies(db):
    company_service.create_company(db, {"name": "Acme Freight", "website": "https://acme.example"})
    company_service.create_company(db, {"name": "Zephyr Consulting", "website": "https://zephyr.example"})
    dups = company_service.find_duplicates(db)
    assert dups == []


def test_dismissed_duplicate_is_not_shown_again(db):
    a = company_service.create_company(db, {"name": "Acme Freight", "website": "https://acme.example"})
    b = company_service.create_company(db, {"name": "Acme Freight Inc", "website": "https://acme.example"})
    company_service.dismiss_duplicate(db, a.id, b.id)
    dups = company_service.find_duplicates(db)
    assert all({d["a"]["id"], d["b"]["id"]} != {a.id, b.id} for d in dups)


def test_merge_companies_archives_secondary_and_moves_children(db):
    primary = company_service.create_company(db, {"name": "Acme Freight", "website": "https://acme.example"})
    secondary = company_service.create_company(db, {"name": "Acme Freight Inc"})
    person = company_service.create_person(db, secondary.id, {"full_name": "Jane Doe", "email": "jane@acme.example"})

    result = company_service.merge_companies(db, primary.id, secondary.id)

    assert result["moved"]["contacts"] == 1
    db.refresh(secondary)
    assert secondary.archived is True
    assert secondary.merged_into_id == primary.id
    db.refresh(person)
    assert person.company_id == primary.id


def test_merge_companies_rejects_merging_a_company_into_itself(db):
    c = company_service.create_company(db, {"name": "Acme Freight"})
    with pytest.raises(ValidationProblem):
        company_service.merge_companies(db, c.id, c.id)


def test_archived_company_excluded_from_default_listing(db):
    primary = company_service.create_company(db, {"name": "Acme Freight"})
    secondary = company_service.create_company(db, {"name": "Acme Freight Inc"})
    company_service.merge_companies(db, primary.id, secondary.id)
    listing = company_service.list_companies(db, q="Acme")
    names = [c["name"] for c in listing["items"]]
    assert "Acme Freight" in names
    assert "Acme Freight Inc" not in names
