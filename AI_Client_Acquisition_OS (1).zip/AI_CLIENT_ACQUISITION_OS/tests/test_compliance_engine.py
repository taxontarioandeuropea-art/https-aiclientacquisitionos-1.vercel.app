"""Compliance engine (master prompt §23): status defaults to REVIEW_REQUIRED, suppression always
wins, and a message cannot be approved unless status is exactly CLEAR."""
import pytest

from core.errors import AppError, ValidationProblem
from engines import compliance_engine
from engines.message_engine import generate_messages
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from engines.signal_engine import add_signal
from services import campaign_service, company_service, lead_service


def test_company_with_no_record_defaults_to_review_required(db):
    c = company_service.create_company(db, {"name": "Unreviewed Co"})
    status = compliance_engine.status_for(db, c.id)
    assert status["status"] == "REVIEW_REQUIRED"


def test_marking_clear_requires_a_lawful_basis(db):
    c = company_service.create_company(db, {"name": "Test Co"})
    with pytest.raises(ValidationProblem):
        compliance_engine.set_record(db, c.id, {"status": "CLEAR"})


def test_marking_clear_with_lawful_basis_succeeds(db):
    c = company_service.create_company(db, {"name": "Test Co"})
    compliance_engine.set_record(db, c.id, {"status": "CLEAR", "lawful_basis": "legitimate_interest_b2b",
                                            "contact_type": "professional"})
    status = compliance_engine.status_for(db, c.id)
    assert status["status"] == "CLEAR"
    assert status["lawful_basis"] == "legitimate_interest_b2b"


def test_unknown_status_rejected(db):
    c = company_service.create_company(db, {"name": "Test Co"})
    with pytest.raises(ValidationProblem):
        compliance_engine.set_record(db, c.id, {"status": "NOT_A_REAL_STATUS"})


def test_suppression_by_domain_blocks_even_a_clear_company(db):
    c = company_service.create_company(db, {"name": "Test Co", "website": "https://blocked.example"})
    compliance_engine.set_record(db, c.id, {"status": "CLEAR", "lawful_basis": "legitimate_interest_b2b"})
    compliance_engine.add_suppression(db, "domain", "blocked.example", reason="opt_out")
    status = compliance_engine.status_for(db, c.id)
    assert status["status"] == "SUPPRESSED"


def test_suppression_by_company_id(db):
    c = company_service.create_company(db, {"name": "Test Co"})
    compliance_engine.add_suppression(db, "company", str(c.id), reason="complaint")
    status = compliance_engine.status_for(db, c.id)
    assert status["status"] == "SUPPRESSED"
    assert "complaint" in status["reason"]


def test_suppression_entries_are_deduplicated(db):
    _, created1 = compliance_engine.add_suppression(db, "email", "bad@example.com", reason="bounced")
    _, created2 = compliance_engine.add_suppression(db, "email", "BAD@Example.com ", reason="bounced")  # same, different case/space
    assert created1 is True
    assert created2 is False


def test_removing_suppression_unblocks(db):
    c = company_service.create_company(db, {"name": "Test Co"})
    entry, _ = compliance_engine.add_suppression(db, "company", str(c.id), reason="manual")
    assert compliance_engine.status_for(db, c.id)["status"] == "SUPPRESSED"
    compliance_engine.remove_suppression(db, entry.id)
    status = compliance_engine.status_for(db, c.id)
    assert status["status"] == "REVIEW_REQUIRED"  # no record, suppression removed -> back to default


def test_remove_suppression_missing_raises_not_found(db):
    from core.errors import NotFound
    with pytest.raises(NotFound):
        compliance_engine.remove_suppression(db, 99999)


# ------------------------------------------------------------------ the approval gate (full flow via API)
def _build_qualified_lead_via_api(client):
    campaign = client.post("/api/campaigns", json={"name": "Poland Test", "country": "Poland"}).json()
    service = client.post("/api/services", json={"name": "Controller Support", "pricing_model": "monthly",
                                                  "minimum_price": 1200, "required_signals": ["hiring_controller"]}).json()
    client.patch(f"/api/campaigns/{campaign['id']}", json={"service_ids": [service["id"]]})
    lead = client.post("/api/leads", json={
        "company": {"name": "Vistula Components", "country": "Poland", "website": "https://vistula.example"},
        "person": {"full_name": "Kasia Nowak", "title": "Finance Director", "email": "kasia@vistula.example"},
        "campaign_id": campaign["id"]}).json()["lead"]
    company_id = lead["company"]["id"]
    client.post("/api/signals", json={"company_id": company_id, "signal_type": "hiring_controller",
                                      "evidence_text": "Controller needed to own monthly close.", "source": "Careers page"})
    client.post(f"/api/leads/{lead['id']}/qualify")
    client.put("/api/settings/user", json={"name": "Alex Advisor", "signature": "Alex Advisor\nAdvisory Co"})
    return lead["id"], company_id


def test_message_cannot_be_approved_without_a_clear_compliance_status(client):
    lead_id, company_id = _build_qualified_lead_via_api(client)
    drafts = client.post(f"/api/leads/{lead_id}/messages/generate", json={}).json()["messages"]
    mid = drafts[0]["id"]
    client.patch(f"/api/messages/{mid}", json={"body": drafts[0]["body"].replace("[Your name]", "Alex Advisor")})
    r = client.post(f"/api/messages/{mid}/approve")
    assert r.status_code == 423
    assert "compliance" in r.json()["error"]["suggestion"].lower() or "review" in r.json()["error"]["message"].lower()


def test_message_approves_once_compliance_is_marked_clear(client):
    lead_id, company_id = _build_qualified_lead_via_api(client)
    drafts = client.post(f"/api/leads/{lead_id}/messages/generate", json={}).json()["messages"]
    mid = drafts[0]["id"]
    client.patch(f"/api/messages/{mid}", json={"body": drafts[0]["body"].replace("[Your name]", "Alex Advisor")})
    r1 = client.put(f"/api/compliance/companies/{company_id}",
                    json={"status": "CLEAR", "lawful_basis": "legitimate_interest_b2b", "contact_type": "professional"})
    assert r1.status_code == 200
    r2 = client.post(f"/api/messages/{mid}/approve")
    assert r2.status_code == 200


def test_suppressed_company_blocks_even_after_being_marked_clear(client):
    lead_id, company_id = _build_qualified_lead_via_api(client)
    drafts = client.post(f"/api/leads/{lead_id}/messages/generate", json={}).json()["messages"]
    mid = drafts[0]["id"]
    client.patch(f"/api/messages/{mid}", json={"body": drafts[0]["body"].replace("[Your name]", "Alex Advisor")})
    client.put(f"/api/compliance/companies/{company_id}",
              json={"status": "CLEAR", "lawful_basis": "legitimate_interest_b2b"})
    client.post("/api/compliance/suppression", json={"match_type": "domain", "value": "vistula.example", "reason": "opt_out"})
    r = client.post(f"/api/messages/{mid}/approve")
    assert r.status_code == 423


def test_compliance_summary_counts_review_required_companies_with_no_record(client):
    client.post("/api/companies", json={"name": "No Record Co"})
    summary = client.get("/api/compliance/summary").json()
    assert summary["counts"]["REVIEW_REQUIRED"] >= 1
