"""Opportunity Score (master prompt §12-14), the structured disqualify-reason gate (§27), and the
explainable feedback engine (§27-28, §47) — never a black-box model, every number a plain grouped
count or rate over real recorded outcomes."""
import pytest

from core.errors import ValidationProblem
from engines import feedback_engine
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from engines.signal_engine import add_signal
from services import campaign_service, company_service, crm_service, lead_service


@pytest.fixture()
def strong_lead(db):
    campaign = campaign_service.create_campaign(db, {"name": "USA Trucking", "country": "USA",
                                                       "target_employees_min": 5, "target_employees_max": 100})
    service = campaign_service.create_service(db, {"name": "Controller Support", "pricing_model": "monthly",
                                                     "minimum_price": 1200, "required_signals": ["hiring_controller"]})
    campaign.services.append(service)
    db.flush()
    company = company_service.create_company(db, {"name": "Strong Co", "country": "USA", "employees": 40,
                                                    "growth_status": "Growing", "source": "CSV import: q3.csv"})
    person = company_service.create_person(db, company.id, {"full_name": "Dana Whitfield", "title": "Owner"})
    add_signal(db, company.id, "hiring_controller", "Controller needed to own monthly close.", "Careers page", confidence=0.9)
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=campaign.id, person_id=person.id)
    qualify_lead(db, lead)
    generate_offer(db, lead)
    return lead


# ------------------------------------------------------------------ opportunity score
def test_opportunity_score_matches_the_priority_composite(db, strong_lead):
    q = strong_lead.qualification
    assert strong_lead.opportunity_score == q["overall"]["composite"]
    assert q["opportunity"]["score"] == q["overall"]["composite"]


def test_opportunity_breakdown_sums_dimension_contributions(db, strong_lead):
    breakdown = strong_lead.qualification["opportunity"]["breakdown"]
    assert len(breakdown) == 5
    assert sum(p["points"] for p in breakdown) == strong_lead.opportunity_score
    assert breakdown == sorted(breakdown, key=lambda p: -p["points"])  # highest contributor first


def test_opportunity_score_persisted_as_a_sortable_column(db, strong_lead):
    from database.models import Lead
    row = db.get(Lead, strong_lead.id)
    assert isinstance(row.opportunity_score, int)
    assert 0 <= row.opportunity_score <= 100


def test_unqualified_lead_has_a_low_opportunity_score(db):
    campaign = campaign_service.create_campaign(db, {"name": "Empty Campaign", "country": "USA"})
    company = company_service.create_company(db, {"name": "No Evidence Co", "country": "USA"})
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=campaign.id)
    qualify_lead(db, lead)
    assert lead.opportunity_score < 50


# ------------------------------------------------------------------ disqualify-reason gate
def test_not_a_fit_requires_a_structured_reason(db, strong_lead):
    with pytest.raises(ValidationProblem):
        crm_service.move_stage(db, strong_lead.id, "NOT_A_FIT", actor="user")


def test_not_a_fit_rejects_an_unknown_reason(db, strong_lead):
    with pytest.raises(ValidationProblem):
        crm_service.move_stage(db, strong_lead.id, "NOT_A_FIT", actor="user", disqualify_reason="just because")


def test_not_a_fit_with_valid_reason_succeeds(db, strong_lead):
    crm_service.move_stage(db, strong_lead.id, "NOT_A_FIT", actor="user", disqualify_reason="too_small")
    db.refresh(strong_lead)
    assert strong_lead.status == "NOT_A_FIT"
    assert strong_lead.disqualify_reason == "too_small"


def test_disqualify_reason_cleared_when_moved_off_not_a_fit(db, strong_lead):
    crm_service.move_stage(db, strong_lead.id, "NOT_A_FIT", actor="user", disqualify_reason="wrong_industry")
    crm_service.move_stage(db, strong_lead.id, "QUALIFIED", actor="user")
    db.refresh(strong_lead)
    assert strong_lead.disqualify_reason is None


# ------------------------------------------------------------------ feedback engine
def test_source_quality_groups_by_bucketed_source(db, strong_lead):
    rows = feedback_engine.source_quality(db)
    row = next(r for r in rows if r["key"] == "CSV import")
    assert row["leads"] == 1
    assert row["qualified"] == 1          # strong_lead is HIGH priority


def test_source_quality_never_fabricates_a_rate_for_zero_leads(db):
    rows = feedback_engine.source_quality(db)
    assert rows == []  # no companies yet -> no groups, not a divide-by-zero crash


def test_industry_quality_buckets_unknown_industry(db, strong_lead):
    rows = feedback_engine.industry_quality(db)
    # Strong Co has no industry set
    assert any(r["key"] == "Unknown" for r in rows)


def test_signal_quality_groups_by_top_ranked_signal(db, strong_lead):
    rows = feedback_engine.signal_quality(db)
    row = next(r for r in rows if r["key"] == "Hiring a controller")
    assert row["leads"] == 1


def test_disqualification_breakdown_counts_reasons(db, strong_lead):
    crm_service.move_stage(db, strong_lead.id, "NOT_A_FIT", actor="user", disqualify_reason="too_small")
    rows = feedback_engine.disqualification_breakdown(db)
    assert rows == [{"reason": "too_small", "label": "Too small", "count": 1, "pct": 100.0}]


def test_disqualification_breakdown_empty_when_nothing_disqualified(db, strong_lead):
    assert feedback_engine.disqualification_breakdown(db) == []


# ------------------------------------------------------------------ top opportunities (§47)
def test_top_opportunities_ranks_by_score_descending(db, strong_lead):
    weak_company = company_service.create_company(db, {"name": "Weak Co", "country": "USA"})
    weak_lead, _ = lead_service.create_lead(db, company_id=weak_company.id, campaign_id=strong_lead.campaign_id)
    qualify_lead(db, weak_lead)

    top = feedback_engine.top_opportunities(db, limit=5)
    ids = [t["lead_id"] for t in top]
    assert ids[0] == strong_lead.id
    assert top[0]["score"] >= top[-1]["score"]


def test_top_opportunities_excludes_closed_leads(db, strong_lead):
    crm_service.move_stage(db, strong_lead.id, "CONTACTED", actor="user")
    crm_service.move_stage(db, strong_lead.id, "WON", actor="user", actual_mrr=1000)
    top = feedback_engine.top_opportunities(db, limit=5)
    assert strong_lead.id not in [t["lead_id"] for t in top]


def test_top_opportunities_includes_evidence_and_offer(db, strong_lead):
    top = feedback_engine.top_opportunities(db, limit=5)
    row = next(t for t in top if t["lead_id"] == strong_lead.id)
    assert row["evidence"]
    assert row["evidence"][0]["text"] == "Controller needed to own monthly close."
    assert row["recommended_offer"]["service"] == "Controller Support"
    assert row["person"]["name"] == "Dana Whitfield"


def test_top_opportunities_respects_limit(db, strong_lead):
    for i in range(3):
        c = company_service.create_company(db, {"name": f"Co {i}", "country": "USA"})
        l, _ = lead_service.create_lead(db, company_id=c.id, campaign_id=strong_lead.campaign_id)
        qualify_lead(db, l)
    assert len(feedback_engine.top_opportunities(db, limit=2)) == 2


# ------------------------------------------------------------------ via the API
def test_dashboard_includes_top_opportunities(client):
    client.post("/api/demo/load")
    d = client.get("/api/dashboard").json()
    assert "top_opportunities" in d
    assert len(d["top_opportunities"]) <= 5


def test_feedback_endpoints_respond(client):
    client.post("/api/demo/load")
    for path in ("/api/feedback/sources", "/api/feedback/industries", "/api/feedback/signals",
                "/api/feedback/disqualifications", "/api/feedback/top-opportunities"):
        r = client.get(path)
        assert r.status_code == 200, path
