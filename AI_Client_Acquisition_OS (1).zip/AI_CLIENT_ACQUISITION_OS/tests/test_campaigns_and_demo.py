"""Campaign statistics and demo data (loads and cleanly removes without touching real data)."""
from services import campaign_service, company_service, demo_data, lead_service


def test_campaign_stats_reflect_lead_counts(db):
    campaign = campaign_service.create_campaign(db, {"name": "Test Campaign", "country": "USA"})
    company = company_service.create_company(db, {"name": "Test Co", "country": "USA"})
    lead_service.create_lead(db, company_id=company.id, campaign_id=campaign.id)
    stats = campaign_service.campaign_stats(db, campaign.id)
    assert stats["counts"]["leads"] == 1


def test_duplicate_campaign_name_rejected(db):
    import pytest
    from core.errors import ValidationProblem
    campaign_service.create_campaign(db, {"name": "USA Trucking", "country": "USA"})
    with pytest.raises(ValidationProblem):
        campaign_service.create_campaign(db, {"name": "USA Trucking", "country": "USA"})


def test_demo_data_loads_a_realistic_dataset(db):
    from database.models import Company, Lead, Campaign, Service
    result = demo_data.load_demo(db)
    assert result["loaded"] is True
    assert db.query(Company).filter(Company.is_demo.is_(True)).count() > 0
    assert db.query(Lead).filter(Lead.is_demo.is_(True)).count() > 0
    assert db.query(Campaign).filter(Campaign.is_demo.is_(True)).count() == 3
    assert db.query(Service).filter(Service.is_demo.is_(True)).count() == 10


def test_demo_data_is_idempotent(db):
    demo_data.load_demo(db)
    second = demo_data.load_demo(db)
    assert second["loaded"] is False


def test_demo_data_spans_multiple_pipeline_stages(db):
    from database.models import Lead
    demo_data.load_demo(db)
    stages = {l.status for l in db.query(Lead).filter(Lead.is_demo.is_(True)).all()}
    assert "WON" in stages
    assert "LOST" in stages
    assert len(stages) >= 5


def test_remove_demo_deletes_all_demo_records_but_keeps_real_data(db):
    real_company = company_service.create_company(db, {"name": "My Real Client", "country": "USA"})
    demo_data.load_demo(db)
    demo_data.remove_demo(db)
    from database.models import Company
    assert db.query(Company).filter(Company.is_demo.is_(True)).count() == 0
    remaining = db.query(Company).filter(Company.id == real_company.id).first()
    assert remaining is not None
    assert remaining.name == "My Real Client"


def test_demo_endpoints_via_api(client):
    r1 = client.post("/api/demo/load")
    assert r1.json()["loaded"] is True
    dash = client.get("/api/dashboard").json()
    assert dash["kpis"]["leads"] > 0
    r2 = client.post("/api/demo/remove")
    assert r2.status_code == 200
    dash2 = client.get("/api/dashboard").json()
    assert dash2["kpis"]["leads"] == 0
