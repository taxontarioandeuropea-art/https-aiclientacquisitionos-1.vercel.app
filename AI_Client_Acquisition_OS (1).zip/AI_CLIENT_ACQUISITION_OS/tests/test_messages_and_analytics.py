"""Outreach message generation (approval gate, no fabrication) and analytics/MRR calculations."""
import pytest

from core.errors import InsufficientEvidence
from engines import analytics_engine
from engines.message_engine import generate_messages
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from engines.signal_engine import add_signal
from services import campaign_service, company_service, crm_service, lead_service


@pytest.fixture()
def qualified_lead(db):
    campaign = campaign_service.create_campaign(db, {"name": "USA Trucking", "country": "USA",
                                                       "target_employees_min": 5, "target_employees_max": 100})
    service = campaign_service.create_service(db, {"name": "Controller Support", "pricing_model": "monthly",
                                                     "minimum_price": 1200, "required_signals": ["hiring_controller"]})
    campaign.services.append(service)
    db.flush()
    company = company_service.create_company(db, {"name": "Prairie Line Freight", "country": "USA", "employees": 40})
    company_service.create_person(db, company.id, {"full_name": "Dana Whitfield", "title": "Owner",
                                                     "email": "dana@prairielinefreight.example"})
    add_signal(db, company.id, "hiring_controller", "Controller needed to own monthly close.", "Careers page")
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=campaign.id)
    qualify_lead(db, lead)
    generate_offer(db, lead)
    return lead


def test_generate_messages_without_evidence_refuses(db):
    campaign = campaign_service.create_campaign(db, {"name": "Empty Campaign", "country": "USA"})
    company = company_service.create_company(db, {"name": "No Evidence Co", "country": "USA"})
    lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=campaign.id)
    qualify_lead(db, lead)
    with pytest.raises(InsufficientEvidence):
        generate_messages(db, lead.id)


def test_generate_messages_uses_only_recorded_evidence(db, qualified_lead):
    drafts = generate_messages(db, qualified_lead.id)
    assert len(drafts) >= 1
    for d in drafts:
        assert d.status == "draft"
        # every generated message must cite the evidence it was built from
        assert d.personalization_evidence


# ---- The tests below exercise the full approve/send workflow purely through the HTTP API,
# using a single TestClient (and therefore a single database) for setup and assertions alike.

def _build_qualified_lead_via_api(client):
    campaign = client.post("/api/campaigns", json={
        "name": "USA Trucking", "country": "USA", "target_employees_min": 5, "target_employees_max": 100,
    }).json()
    service = client.post("/api/services", json={
        "name": "Controller Support", "pricing_model": "monthly", "minimum_price": 1200,
        "required_signals": ["hiring_controller"],
    }).json()
    client.patch(f"/api/campaigns/{campaign['id']}", json={"service_ids": [service["id"]]})
    lead = client.post("/api/leads", json={
        "company": {"name": "Prairie Line Freight", "country": "USA", "employees": 40},
        "person": {"full_name": "Dana Whitfield", "title": "Owner", "email": "dana@prairielinefreight.example"},
        "campaign_id": campaign["id"],
    }).json()["lead"]
    company_id = lead["company"]["id"]
    client.post("/api/signals", json={
        "company_id": company_id, "signal_type": "hiring_controller",
        "evidence_text": "Controller needed to own monthly close.", "source": "Careers page",
    })
    client.post(f"/api/leads/{lead['id']}/qualify")
    return lead["id"]


def test_message_cannot_be_sent_without_approval(client):
    lead_id = _build_qualified_lead_via_api(client)
    drafts = client.post(f"/api/leads/{lead_id}/messages/generate", json={}).json()["messages"]
    mid = drafts[0]["id"]
    r = client.post(f"/api/messages/{mid}/send", json={})
    assert r.status_code == 409


def test_message_with_placeholder_signature_cannot_be_approved(client):
    """Without a user signature configured, drafts contain a [Your name] placeholder and cannot be approved."""
    lead_id = _build_qualified_lead_via_api(client)
    drafts = client.post(f"/api/leads/{lead_id}/messages/generate", json={}).json()["messages"]
    mid = drafts[0]["id"]
    r = client.post(f"/api/messages/{mid}/approve")
    assert r.status_code == 400


def test_message_approve_then_send_advances_stage(client):
    lead_id = _build_qualified_lead_via_api(client)
    drafts = client.post(f"/api/leads/{lead_id}/messages/generate", json={}).json()["messages"]
    mid = drafts[0]["id"]
    client.put("/api/settings/user", json={"name": "Alex Advisor", "signature": "Alex Advisor\nAdvisory Co"})
    client.patch(f"/api/messages/{mid}", json={"body": drafts[0]["body"].replace("[Your name]", "Alex Advisor")})
    lead = client.get(f"/api/leads/{lead_id}").json()
    client.put(f"/api/compliance/companies/{lead['company']['id']}",
              json={"status": "CLEAR", "lawful_basis": "legitimate_interest_b2b", "contact_type": "professional"})
    approve = client.post(f"/api/messages/{mid}/approve")
    assert approve.status_code == 200
    send = client.post(f"/api/messages/{mid}/send", json={})
    assert send.status_code == 200
    lead_after = client.get(f"/api/leads/{lead_id}").json()
    assert lead_after["status"] == "CONTACTED"


def test_mrr_only_counts_won_leads(db, qualified_lead):
    crm_service.move_stage(db, qualified_lead.id, "CONTACTED", actor="user")
    crm_service.move_stage(db, qualified_lead.id, "REPLIED", actor="user")
    crm_service.move_stage(db, qualified_lead.id, "CALL", actor="user")
    crm_service.move_stage(db, qualified_lead.id, "PROPOSAL", actor="user")
    crm_service.move_stage(db, qualified_lead.id, "WON", actor="user", actual_mrr=1800)
    funnel = analytics_engine.funnel(db)
    assert funnel["mrr"] == 1800
    assert funnel["counts"]["won"] == 1


def test_funnel_counts_a_lost_lead_at_its_furthest_stage(db, qualified_lead):
    crm_service.move_stage(db, qualified_lead.id, "CONTACTED", actor="user")
    crm_service.move_stage(db, qualified_lead.id, "REPLIED", actor="user")
    crm_service.move_stage(db, qualified_lead.id, "LOST", actor="user", lost_reason="No budget")
    funnel = analytics_engine.funnel(db)
    assert funnel["counts"]["contacted"] == 1
    assert funnel["counts"]["replies"] == 1
    assert funnel["counts"]["won"] == 0
