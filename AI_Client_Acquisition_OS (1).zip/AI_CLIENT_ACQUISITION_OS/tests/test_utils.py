"""Normalisation helpers used throughout deduplication and parsing."""
from core.utils import (classify_title, country_bucket, name_similarity, norm_country,
                        normalize_company_name, normalize_domain, normalize_email, normalize_phone,
                        parse_int, parse_number, wilson_interval)


def test_company_name_normalisation_strips_legal_suffixes():
    a = normalize_company_name("ABC Logistics LLC")
    b = normalize_company_name("ABC Logistics")
    c = normalize_company_name("A.B.C. Logistics, Inc.")
    assert a == b == "abc logistics"
    assert c == "a.b.c. logistics" or c == "abc logistics"  # punctuation variants still converge on the words


def test_company_name_normalisation_handles_polish_suffixes():
    a = normalize_company_name("Vistula Components Sp. z o.o.")
    b = normalize_company_name("Vistula Components")
    assert a == b


def test_domain_normalisation():
    assert normalize_domain("https://www.Example.com/path") == "example.com"
    assert normalize_domain("example.com") == "example.com"
    assert not normalize_domain("")       # falsy: "" (never None, but never truthy either)
    assert not normalize_domain(None)


def test_email_normalisation_lowercases_and_trims():
    assert normalize_email(" Jane.Doe@Example.COM ") == "jane.doe@example.com"
    assert not normalize_email("")


def test_phone_normalisation_keeps_only_digits_and_plus():
    assert normalize_phone("+1 (555) 123-4567") == normalize_phone("15551234567") or \
        normalize_phone("+1 (555) 123-4567").endswith("5551234567")


def test_parse_number_handles_suffixes_and_currency():
    assert parse_number("$1.2M") == 1_200_000
    assert parse_number("500k") == 500_000
    assert parse_number("1,234") == 1234
    assert parse_number("") is None
    assert parse_number(None) is None


def test_parse_int_truncates_and_handles_junk():
    assert parse_int("42") == 42
    assert parse_int("42.7") == 42  # truncates towards zero, like int()
    assert parse_int("not a number") is None


def test_country_bucket_groups_usa_and_poland_else_other():
    assert country_bucket("USA") == "USA"
    assert country_bucket("United States") == "USA"
    assert country_bucket("Poland") == "Poland"
    assert country_bucket("Germany") == "Other"
    assert country_bucket(None) == "Other"


def test_norm_country_canonicalises_aliases():
    assert norm_country("United States") == "USA"
    assert norm_country("usa") == "USA"
    assert norm_country("Polska") == "Poland"


def test_classify_title_recognises_decision_makers():
    assert classify_title("Owner") == "decision_maker"
    assert classify_title("Chief Financial Officer") == "decision_maker"
    assert classify_title("Controller") in ("decision_maker", "influencer")
    assert classify_title("Accounts Payable Clerk") in ("user", "influencer")
    assert classify_title(None) == "unknown"


def test_name_similarity_is_high_for_near_matches_low_for_unrelated():
    assert name_similarity("abc logistics", "abc logistic") > 0.85
    assert name_similarity("abc logistics", "zephyr consulting") < 0.5


def test_wilson_interval_bounds_and_shrinks_with_larger_n():
    lo0, hi0 = wilson_interval(1, 2)
    lo1, hi1 = wilson_interval(50, 100)
    assert 0 <= lo0 <= hi0 <= 1
    assert 0 <= lo1 <= hi1 <= 1
    assert (hi1 - lo1) < (hi0 - lo0)  # more evidence narrows the interval
