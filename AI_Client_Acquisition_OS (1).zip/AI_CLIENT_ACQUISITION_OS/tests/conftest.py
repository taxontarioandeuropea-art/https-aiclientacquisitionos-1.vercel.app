import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.database import init_engine, init_db
from database import database as dbmod


@pytest.fixture()
def db():
    """A fresh in-memory SQLite database for each test."""
    init_engine("sqlite:///:memory:")
    init_db()
    with dbmod.session_scope() as session:
        yield session


@pytest.fixture()
def client(tmp_path, monkeypatch):
    """A FastAPI TestClient backed by a fresh on-disk SQLite database (needed because
    TestClient requests run in a different thread than an in-memory sqlite connection)."""
    from fastapi.testclient import TestClient
    from app import create_app
    db_path = tmp_path / "test.db"
    app = create_app(f"sqlite:///{db_path}", seed_demo=False)
    return TestClient(app, raise_server_exceptions=False)
