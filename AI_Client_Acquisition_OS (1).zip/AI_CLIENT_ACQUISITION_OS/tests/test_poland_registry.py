"""Poland ELT layer: raw immutable store, canonical mapping, entity resolution, change/event
detection, and the CEIDG/KRS connectors against a mocked transport (never hits the real network)."""
from __future__ import annotations

import httpx
import pytest

from core.errors import ValidationProblem
from database.models import BusinessEvent, Company, RawRecord, SourceRun
from poland import discovery, raw_store
from poland.canonical import from_ceidg, from_krs
from poland.ceidg_client import CeidgClient
from poland.entity_resolution import find_existing, resolve_or_create
from poland.errors import SourceNotConfigured, SourceRequestFailed
from poland.krs_client import KrsClient, normalize_krs
from poland.source_registry import list_sources


# ------------------------------------------------------------------ fixtures: realistic payloads
CEIDG_FIRMA = {
    "id": "31F87519-9395-4FCF-8E19-6D5C0522FA7A",
    "nazwa": "Jan Kowalski Ksiegowosc",
    "adresDzialalnosci": {"ulica": "ul. Zwierzyniecka", "budynek": "1", "miasto": "Warszawa",
                          "wojewodztwo": "MAZOWIECKIE", "powiat": "Warszawa", "gmina": "Warszawa", "kod": "00-001"},
    "wlasciciel": {"imie": "Jan", "nazwisko": "Kowalski", "nip": "1112223344", "regon": "123456789"},
    "pkd": [{"kod": "6920Z", "nazwa": "Dzialalnosc rachunkowo-ksiegowa"}],
    "pkdGlowny": {"kod": "6920Z", "nazwa": "Dzialalnosc rachunkowo-ksiegowa"},
    "dataRozpoczecia": "2019-03-01",
    "status": "AKTYWNY",
    "link": "https://dane.biznes.gov.pl/api/ceidg/v3/firma/31F87519-9395-4FCF-8E19-6D5C0522FA7A",
}

KRS_ODPIS = {
    "odpis": {
        "naglowekP": {"numerKRS": "0000123456", "stanRekordu": "AKTYWNY"},
        "dane": {
            "dzial1": {
                "danePodmiotu": {"nazwa": "Vistula Components Sp. z o.o.", "nazwaFormyPrawnej": "SPOLKA Z OGRANICZONA ODPOWIEDZIALNOSCIA",
                                "identyfikatorNip": "5213456789", "identyfikatorRegon": "140123456"},
                "siedzibaIAdres": {"siedziba": {"miejscowosc": "Wroclaw", "wojewodztwo": "DOLNOSLASKIE"},
                                  "adres": {"ulica": "Legnicka", "nrDomu": "10"}},
            },
            "dzial3": {"przedmiotDzialalnosci": {"przedmiotPrzewazajacejDzialalnosci": [
                {"kodPrzedmiotuDzialalnosci": "2932Z", "nazwaPrzedmiotuDzialalnosci": "Produkcja pozostalych czesci i akcesoriow do pojazdow"}]}},
        },
    }
}


def _mock_transport(handler):
    return httpx.Client(transport=httpx.MockTransport(handler))


# ------------------------------------------------------------------ raw store
def test_write_raw_dedupes_identical_payload_same_external_id(db):
    r1, created1 = raw_store.write_raw(db, source_id="ceidg", external_id="abc", raw_payload={"a": 1})
    r2, created2 = raw_store.write_raw(db, source_id="ceidg", external_id="abc", raw_payload={"a": 1})
    assert created1 is True
    assert created2 is False
    assert r1.id == r2.id
    assert db.query(RawRecord).count() == 1


def test_write_raw_keeps_both_versions_when_payload_changes(db):
    raw_store.write_raw(db, source_id="ceidg", external_id="abc", raw_payload={"status": "AKTYWNY"})
    raw_store.write_raw(db, source_id="ceidg", external_id="abc", raw_payload={"status": "ZAWIESZONY"})
    hist = raw_store.history(db, source_id="ceidg", external_id="abc")
    assert len(hist) == 2
    assert hist[0].raw_payload["status"] == "AKTYWNY"
    assert hist[1].raw_payload["status"] == "ZAWIESZONY"
    # raw records are never overwritten or deleted by a later fetch
    assert db.query(RawRecord).count() == 2


# ------------------------------------------------------------------ canonical mapping
def test_from_ceidg_maps_identity_and_address():
    c = from_ceidg(CEIDG_FIRMA)
    assert c["nip"] == "1112223344"
    assert c["regon"] == "123456789"
    assert c["legal_form"] == "JDG"
    assert c["city"] == "Warszawa"
    assert c["registry_status"] == "AKTYWNY"
    assert c["pkd_main"] == "6920Z"
    assert c["country"] == "Poland"


def test_from_ceidg_never_invents_missing_fields():
    minimal = {"id": "x", "nazwa": "Solo Trader", "status": "AKTYWNY"}
    c = from_ceidg(minimal)
    assert "nip" not in c
    assert "city" not in c
    assert c["name"] == "Solo Trader"


def test_from_krs_maps_identity_address_and_pkd():
    c = from_krs(KRS_ODPIS)
    assert c["krs_number"] == "0000123456"
    assert c["nip"] == "5213456789"
    assert c["legal_form"].startswith("SPOLKA")
    assert c["city"] == "Wroclaw"
    assert c["pkd_codes"][0]["code"] == "2932Z"
    assert c["registry_source"] == "krs"


# ------------------------------------------------------------------ entity resolution
def test_find_existing_matches_by_nip_deterministically(db):
    from services import company_service
    c = company_service.create_company(db, {"name": "Existing Co", "nip": "1112223344"})
    hit = find_existing(db, {"nip": "1112223344"})
    assert hit is not None
    assert hit.id == c.id


def test_find_existing_returns_none_without_identifier_overlap(db):
    from services import company_service
    company_service.create_company(db, {"name": "Existing Co", "nip": "1112223344"})
    assert find_existing(db, {"nip": "9999999999"}) is None


def test_resolve_or_create_reuses_matching_company_and_fills_gaps(db):
    from services import company_service
    existing = company_service.create_company(db, {"name": "Jan Kowalski Ksiegowosc", "nip": "1112223344"})
    canonical = from_ceidg(CEIDG_FIRMA)
    company, created, reasons = resolve_or_create(db, canonical)
    assert created is False
    assert company.id == existing.id
    assert company.city == "Warszawa"          # gap filled from the registry fetch
    assert company.regon == "123456789"
    assert "Matched by nip" in reasons


def test_resolve_or_create_creates_new_company_when_no_identifier_matches(db):
    canonical = from_krs(KRS_ODPIS)
    company, created, _ = resolve_or_create(db, canonical)
    assert created is True
    assert company.krs_number == "0000123456"
    assert company.country is None or company.nip == "5213456789"


# ------------------------------------------------------------------ change/event detection
def test_first_sighting_creates_new_business_event_and_no_signal(db):
    canonical = from_ceidg(CEIDG_FIRMA)
    company, _, _ = resolve_or_create(db, canonical)
    raw_store.write_raw(db, source_id="ceidg", external_id=CEIDG_FIRMA["id"], raw_payload={"firma": CEIDG_FIRMA})
    canonical["_external_id"] = CEIDG_FIRMA["id"]
    from poland.events import record_and_diff
    events = record_and_diff(db, company, "ceidg", canonical)
    assert len(events) == 1
    assert events[0].event_type == "new_business"
    assert db.query(BusinessEvent).count() == 1


def test_status_change_on_second_fetch_creates_signal(db):
    from poland.events import record_and_diff
    first = dict(CEIDG_FIRMA)
    canonical = from_ceidg(first)
    company, _, _ = resolve_or_create(db, canonical)
    raw_store.write_raw(db, source_id="ceidg", external_id=first["id"], raw_payload={"firma": first})
    canonical["_external_id"] = first["id"]
    record_and_diff(db, company, "ceidg", canonical)   # first sighting

    second = dict(CEIDG_FIRMA, status="ZAWIESZONY")
    second_canonical = from_ceidg(second)
    raw_store.write_raw(db, source_id="ceidg", external_id=first["id"], raw_payload={"firma": second})
    second_canonical["_external_id"] = first["id"]
    events = record_and_diff(db, company, "ceidg", second_canonical)
    types = [e.event_type for e in events]
    assert "status_changed" in types
    # suspension is recorded as an event but is not promoted to a buying-signal Signal
    assert company.signals == [] or all(s.signal_type != "status_changed" for s in company.signals)

    third = dict(CEIDG_FIRMA, status="AKTYWNY")
    raw_store.write_raw(db, source_id="ceidg", external_id=first["id"], raw_payload={"firma": third})
    third_canonical = from_ceidg(third)
    third_canonical["_external_id"] = first["id"]
    events2 = record_and_diff(db, company, "ceidg", third_canonical)
    assert any(e.event_type == "status_changed_to_active" for e in events2)
    db.refresh(company)
    assert any(s.signal_type == "new_location" for s in company.signals)   # reactivation -> mapped signal


# ------------------------------------------------------------------ CEIDG client (mocked transport)
def test_ceidg_client_requires_token():
    client = CeidgClient(token=None)
    with pytest.raises(SourceNotConfigured):
        client.search_firmy(nazwa=["test"])


def test_ceidg_client_rejects_invalid_status():
    client = CeidgClient(token="t")
    with pytest.raises(ValueError):
        client.search_firmy(status=["NOT_A_REAL_STATUS"])


def test_ceidg_client_search_parses_response():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["authorization"] == "Bearer test-token"
        assert "nazwa=Kowalski" in str(request.url)
        return httpx.Response(200, json={"firmy": [CEIDG_FIRMA], "count": 1})
    client = CeidgClient(token="test-token", client=_mock_transport(handler), min_interval=0)
    res = client.search_firmy(nazwa=["Kowalski"])
    assert res["count"] == 1
    assert res["firmy"][0]["id"] == CEIDG_FIRMA["id"]


def test_ceidg_client_handles_no_results_204():
    client = CeidgClient(token="t", client=_mock_transport(lambda r: httpx.Response(204)), min_interval=0)
    res = client.search_firmy(nazwa=["Nobody"])
    assert res == {"firmy": [], "count": 0}


def test_ceidg_client_raises_on_401():
    client = CeidgClient(token="bad", client=_mock_transport(lambda r: httpx.Response(401)), min_interval=0)
    with pytest.raises(SourceRequestFailed):
        client.search_firmy(nazwa=["x"])


def test_ceidg_client_changes_endpoint():
    def handler(request: httpx.Request) -> httpx.Response:
        assert "/zmiana" in str(request.url)
        return httpx.Response(200, json={"identyfikatoryWpisow": ["id-1", "id-2"], "count": 2})
    client = CeidgClient(token="t", client=_mock_transport(handler), min_interval=0)
    res = client.changes(dataod="2026-01-01")
    assert res["identyfikatoryWpisow"] == ["id-1", "id-2"]


# ------------------------------------------------------------------ KRS client (mocked transport)
def test_normalize_krs_pads_and_strips():
    assert normalize_krs("28860") == "0000028860"
    assert normalize_krs("0000-028-860") == "0000028860"
    with pytest.raises(ValueError):
        normalize_krs("not-a-number-"[:0] or "")


def test_krs_client_odpis_aktualny_parses_response():
    def handler(request: httpx.Request) -> httpx.Response:
        assert "OdpisAktualny/0000123456" in str(request.url)
        return httpx.Response(200, json=KRS_ODPIS)
    client = KrsClient(client=_mock_transport(handler), min_interval=0)
    res = client.odpis_aktualny("123456")
    assert res["odpis"]["naglowekP"]["numerKRS"] == "0000123456"


def test_krs_client_returns_none_on_404():
    client = KrsClient(client=_mock_transport(lambda r: httpx.Response(404)), min_interval=0)
    assert client.odpis_aktualny("9999999999") is None


# ------------------------------------------------------------------ discovery orchestration (end-to-end, mocked)
def test_ceidg_search_ingests_and_logs_a_source_run(db):
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/firmy"):
            return httpx.Response(200, json={"firmy": [CEIDG_FIRMA], "count": 1})
        return httpx.Response(200, json={"firma": [CEIDG_FIRMA]})
    client = CeidgClient(token="t", client=_mock_transport(handler), min_interval=0)
    res = discovery.ceidg_search(db, client=client, pkd=["6920Z"], miasto=["Warszawa"])
    assert res["status"] == "SUCCESS"
    assert res["created_businesses"] == 1
    assert len(res["company_ids"]) == 1
    run = db.get(SourceRun, res["run_id"])
    assert run.status == "SUCCESS"
    assert run.source_id == "ceidg"
    company = db.get(Company, res["company_ids"][0])
    assert company.nip == "1112223344"
    assert company.registry_source == "ceidg"
    # a raw record was preserved for this exact fetch
    assert raw_store.latest_raw(db, source_id="ceidg", external_id=CEIDG_FIRMA["id"]) is not None


def test_ceidg_search_without_token_marks_run_skipped_not_silent_failure(db):
    client = CeidgClient(token=None, min_interval=0)
    with pytest.raises(SourceNotConfigured):
        discovery.ceidg_search(db, client=client, nazwa=["x"])
    run = db.query(SourceRun).order_by(SourceRun.id.desc()).first()
    assert run.status == "SKIPPED"
    assert "CEIDG_API_TOKEN" in run.errors[0]


def test_ceidg_search_creates_leads_when_campaign_given(db):
    from services import campaign_service
    campaign = campaign_service.create_campaign(db, {"name": "Poland Test Campaign", "country": "Poland"})

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/firmy"):
            return httpx.Response(200, json={"firmy": [CEIDG_FIRMA], "count": 1})
        return httpx.Response(200, json={"firma": [CEIDG_FIRMA]})
    client = CeidgClient(token="t", client=_mock_transport(handler), min_interval=0)
    res = discovery.ceidg_search(db, client=client, campaign_id=campaign.id, nazwa=["Kowalski"])
    assert len(res["lead_ids"]) == 1
    from database.models import Lead
    lead = db.get(Lead, res["lead_ids"][0])
    assert lead.campaign_id == campaign.id
    assert lead.qualification is not None    # ran through the real qualification engine


def test_krs_enrich_merges_into_existing_ceidg_company_by_shared_nip(db):
    """A company first discovered via CEIDG and later found to have a KRS number (e.g. it
    incorporated) should be enriched onto the SAME company, not duplicated."""
    canonical = from_ceidg(CEIDG_FIRMA)
    existing, _, _ = resolve_or_create(db, canonical)
    krs_payload = dict(KRS_ODPIS)
    krs_payload["odpis"]["dane"]["dzial1"]["danePodmiotu"]["identyfikatorNip"] = CEIDG_FIRMA["wlasciciel"]["nip"]

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=krs_payload)
    client = KrsClient(client=_mock_transport(handler), min_interval=0)
    res = discovery.krs_enrich(db, ["123456"], client=client)
    assert res["created_businesses"] == 0
    assert res["updated_businesses"] == 1
    db.refresh(existing)
    assert existing.krs_number == "0000123456"   # enriched onto the pre-existing record


def test_source_registry_lists_all_three_sources_with_honest_status():
    sources = list_sources()
    ids = {s["source_id"] for s in sources}
    assert ids == {"ceidg", "krs", "gus_regon"}
    gus = next(s for s in sources if s["source_id"] == "gus_regon")
    assert gus["reliability_score"] == 0.0        # honestly marked as not yet connected
    krs = next(s for s in sources if s["source_id"] == "krs")
    assert krs["discovery_capable"] is False       # lookup-only, documented accurately
    ceidg = next(s for s in sources if s["source_id"] == "ceidg")
    assert ceidg["discovery_capable"] is True
