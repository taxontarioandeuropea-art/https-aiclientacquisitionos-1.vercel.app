# AI Client Acquisition OS

A local-first B2B client-acquisition CRM and sales-automation platform: it finds, qualifies and helps
you convert leads, and it explains every decision it makes with the evidence behind it.

It ships configured for two example markets — USA trucking/logistics companies and Poland-based
foreign-owned companies needing accounting services — but nothing about industry, market or service is
hardcoded into the engine. Every one of those is data you configure in **Campaigns** and **Services**.

## What it does

- **Finds and imports leads** from CSV/Excel files (with automatic column matching) or by reading a
  company's own public website for evidence (careers, about and contact pages — nothing scraped from
  search engines, and it respects `robots.txt`).
- **Qualifies every lead on five separate dimensions** — Fit, Need, Buying Signal, Ability to Pay,
  Contactability — never collapsed into one opaque score. Every reason is tagged **Fact**, **Inference**
  or **Recommendation** and, where it's a Fact, cites the quoted evidence and its source.
- **Matches your services to evidence.** A service is only ever recommended when a lead has a recorded
  signal it's built to address — never a generic pitch.
- **Drafts outreach messages** from that same evidence — and only from that evidence. It never invents a
  fact, a number or a contact detail. **It never sends anything.** You approve a draft, send it yourself
  from your own email or LinkedIn, then record that you sent it.
- **Runs a CRM pipeline** (New → Researched → Qualified → Contacted → Replied → Call → Proposal →
  Negotiation → Won, plus Lost / Nurture / Not a fit) with drag-and-drop, auto-generated tasks, and a
  full audit trail. Only a person can mark a deal Won or Lost — automation can't close deals.
- **Flags possible duplicate companies and contacts** for you to review. It never merges anything on its
  own; a merge always archives the secondary record (never deletes it) and logs exactly what moved.
- **Reports on your funnel and MRR** by campaign, industry, country, service, signal and message
  template, and runs a lightweight experiment engine that compares message/offer combinations — always
  showing its sample size and flagging small samples as "too few to judge" rather than pretending they
  prove something.
- **Works with zero AI configuration.** Every part of the app — qualification, service matching, message
  drafting, research summaries — has a rule-based path that needs no AI provider. If you add one (OpenAI,
  Anthropic or a local OpenAI-compatible model), it can polish message wording and summarise research;
  any AI output that introduces a fact, number or link not already in your data is discarded automatically.

## Architecture

```
start.bat, start.command   Double-click launchers (Windows / macOS+Linux) — see Installation below
config.py            Central configuration (reads .env; never hardcodes secrets)
app.py                FastAPI app factory and startup (python app.py runs it)

core/                 Pure logic shared everywhere: constants, error types, text/number
                      normalisation, audit logging, the settings store
database/             SQLAlchemy models and the engine/session setup (SQLite by default;
                      swapping DATABASE_URL is enough to move to PostgreSQL)
adapters/             Lead sources: CSV, Excel, and the website-research reader. Adding a
                      new source (a job board, a registry, a CRM export) means implementing
                      one class here — see adapters/future/README.md
ai/                   AI provider abstraction (OpenAI, Anthropic, a local OpenAI-compatible
                      server, or "none"). The rest of the app never talks to a provider directly.
engines/              The business logic with no HTTP or template concerns:
                        qualification_engine   the five-dimension scoring
                        signal_engine           the signal catalog, evidence validation, and
                                                 regex-based signal detection in fetched text
                        offer_engine            evidence -> service -> price matching
                        message_engine          evidence -> draft message (never auto-sent)
                        followup_engine         the follow-up sequence and reply handling
                        analytics_engine        funnel, MRR, market breakdowns
                        experiment_engine       comparison of message/offer combinations
                        company_research        orchestrates the whole research pipeline and
                                                 the FACT/INFERENCE/RECOMMENDATION report
                        lead_hunter             runs any adapter and feeds it into ingestion
services/             Everything that touches the database on behalf of the API:
                        company_service, lead_service   CRUD, deduplication and merging
                        campaign_service                campaigns and the service catalog
                        crm_service                      pipeline moves and interactions
                        task_service                     task generation and listing
                        import_export_service            CSV/XLSX import and export
                        demo_data                         the fictional demo dataset
                        serializers                       shared JSON shapes
api/                  FastAPI routers (crm_routes, campaign_routes, data_routes) and the
                      thin HTML page router (pages.py) — pages hold no business logic; they
                      call the same JSON API the browser calls
templates/, static/   Server-rendered page shells plus a small, framework-free JS/CSS layer
                      that talks to the JSON API (no build step, no Node dependency)
tests/                pytest suite (see "Testing" below)
```

## Installation and running it — the easy way

Requires Python 3.10+ ([python.org/downloads](https://python.org/downloads) — on Windows, tick "Add
python.exe to PATH" during setup).

- **Windows:** double-click **`start.bat`**.
- **macOS:** double-click **`start.command`** (first time only, you may need to right-click → Open once,
  since it's not signed by an Apple developer).
- **Linux:** run `./start.command` in a terminal.

That one file does everything: it creates a private, self-contained environment inside a `.venv` folder
(so it can never conflict with any other Python install or project on your computer — this is what
causes most "it says a module is missing" problems), installs the dependencies into it, starts the
server, and opens your browser to it automatically. The first run takes a minute or so to install
everything; every run after that starts in a couple of seconds. The server keeps running in that window
— close the window, or press Ctrl+C inside it, to stop.

### The manual way

If you'd rather manage the environment yourself (or you're deploying this somewhere other than your own
laptop):

```bash
cd AI_CLIENT_ACQUISITION_OS
pip install -r requirements.txt
cp .env.example .env      # edit if you want to change ports, add an AI key, etc. — optional
python app.py
```

On Windows, use `python -m pip install -r requirements.txt` and `python -m pytest` rather than the bare
`pip`/`pytest` commands — this guarantees they run against the exact same Python that runs `app.py`,
which avoids the most common Windows install problem (a bare `pip` resolving to a different Python
installation than a bare `python` does).

Either way, open the URL it prints (`http://127.0.0.1:8000` by default). The database and its tables are
created automatically on first run. If the database is empty, a clearly-labelled set of **fictional demo
data** loads automatically (20 companies, 21 leads across 3 campaigns, 10 services) so the app is
immediately explorable — turn this off with `LOAD_DEMO_ON_FIRST_RUN=false` in `.env`, and remove it at
any time from **Import / Export → Demo data** (or `POST /api/demo/remove`) without touching your own
records.

## Testing

Make sure you've run `start.bat`/`start.command` (or the manual `pip install -r requirements.txt`) at
least once first — pytest is already in requirements.txt, so there's nothing extra to install. Then:

```bash
pytest                              # if you installed manually, on PATH
python -m pytest                    # safer on Windows — see the note below
.venv\Scripts\python -m pytest      # if you used start.bat/start.command and want to run tests directly
```

(On Windows, if a bare `pytest` isn't recognized, use `python -m pytest` instead — it runs the exact
same thing but doesn't depend on pytest's shortcut being on your PATH.)

121 tests cover: database setup, company/contact CRUD, deduplication and merging, the five-dimension
qualification engine and the Opportunity Score breakdown (including the "no evidence → no fabricated
score", "core-ICP-mismatch caps fit", and "the breakdown always sums exactly to the headline number"
rules), evidence-gated service matching, the CRM pipeline (including "only a person can close a deal"
and "Not a fit requires a structured reason"), automatic task generation, message generation and the
full draft → placeholder-check → compliance-check → approve → send workflow (exercised through the real
HTTP API), the compliance engine (suppression always wins, REVIEW_REQUIRED by default), the feedback
engine (source/industry/signal quality, never fabricating a rate for an empty group), MRR/funnel
analytics, CSV/Excel import with column auto-mapping and per-row error handling, export
formula-injection safety, campaign statistics, the Poland CEIDG/KRS registry layer (25 tests against
mocked responses built from the official API docs), and the demo dataset (loads, is idempotent, and
removes cleanly without touching real data).

## The database

SQLite by default, at `database/sales.db` (created automatically). Every model uses portable SQLAlchemy
types, so moving to PostgreSQL later is a matter of setting `DATABASE_URL` in `.env` (e.g.
`postgresql+psycopg://user:pass@host:5432/dbname`) — no code changes. There are no migrations yet
(`Base.metadata.create_all` runs on every start, which only adds missing tables); if you need to alter
existing columns on a live database, add Alembic at that point.

## Demo mode

Every demo record is fictional and flagged `is_demo=True`, using reserved `.example` domains. Demo
signals, qualification scores, service matches and messages are all produced by the *real* engines from
demo evidence — nothing about the scoring is hardcoded for the demo, so what you see is what the app
actually does with real data.

## Configuring an AI provider (optional)

In **Settings → AI provider**, choose OpenAI, Anthropic, or a local OpenAI-compatible server (Ollama, LM
Studio, llama.cpp), and set the model name. API keys are read **only** from environment variables in
`.env` (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `LOCAL_LLM_BASE_URL` / `LOCAL_LLM_API_KEY`) — never stored
in the database, never sent to the browser. With no provider configured, every feature still works from
templates and rules; AI only ever polishes wording or writes a summary, and any output introducing a new
fact, number or link is discarded before it's shown to you.

## Importing leads

**Import / Export → Import from CSV or Excel.** Pick what you're importing (leads, companies, contacts,
campaigns, services or interactions), upload a file, and the app auto-matches your columns (English and
Polish headers both work) — review and adjust the mapping, then commit. Company name is the only required
field for leads/companies/contacts. Rows with bad data (e.g. an invalid email) are skipped individually
with a clear reason; the rest of the file still imports. A company that looks like an existing one (same
domain, or a close name match) is **never merged automatically** — it's created and flagged in the
duplicates queue for you to review from **Companies**.

## Creating a campaign

A campaign is an independent ideal-customer profile: country, industry, company size, revenue range,
technology, ownership, preferred decision-makers, a minimum/target MRR, which services it can recommend,
and its own follow-up rhythm. Create one from **Campaigns → New campaign**. Nothing about qualification
or offers is tied to a specific industry — the two seeded example campaigns (USA trucking, Poland
foreign-owned companies) exist purely as configuration, and a third (USA maritime logistics) is included
to demonstrate that a new market is just a new campaign, not a code change.

## Researching a company

**Research** (or a company's own profile page → **Research website**) reads the company's homepage plus
its careers/about/contact pages, respecting `robots.txt` and refusing private/internal network addresses
unless you explicitly allow it. It records only what's actually on the page — description, published
contact addresses, technology mentions, and signals — each with the exact excerpt and the page it came
from. Nothing is invented; a field the page doesn't answer stays marked unknown. The resulting report
(**Company profile → Research report**) is fully FACT/INFERENCE/RECOMMENDATION-tagged and exportable as
Markdown, JSON, CSV or Excel.

## How qualification works

Every lead's qualification is five independently-scored dimensions, never one number:

| Dimension | What it measures |
|---|---|
| Fit | Does the company match the campaign's ICP (country, industry, size, technology, ownership)? |
| Need | Does recorded evidence suggest they need what you sell? |
| Buying signal | Is there evidence of active intent right now (hiring, growth, funding, a system change)? |
| Ability to pay | Can they plausibly afford your minimum, from revenue or a size-based estimate? |
| Contactability | Do you have a reachable decision-maker? |

A lead with no recorded evidence is scored **Unknown**, not a guessed Low or High. A core mismatch on
country, industry or ownership caps Fit at Medium (one mismatch) or Low (two or more) even if every other
criterion matches. Re-run qualification any time from a lead, a company, or in bulk from a campaign.

## Generating outreach

From a lead's **Messages** tab, **Draft messages** produces three variants (observation-led, question-led,
brief) built only from that lead's recorded evidence — it refuses to draft anything if there's no
evidence at all. Edit if you like, then **Approve** (blocked while a `[Your name]`-style placeholder is
still present — set your signature in **Settings → Your profile** first), send it yourself, then **Mark
as sent** to log it and schedule the next follow-up. An inbound reply (logged under **Activity**) stops
the follow-up sequence automatically and advances the lead to Replied.

## Working the CRM

**Pipeline** is a drag-and-drop board of every open lead by stage. **Tasks** shows what's overdue, due
today and coming up — tasks are created automatically from stage changes and follow-up timing, and you
can add your own. Moving a lead to **Won** requires the actual monthly fee; moving it to **Lost** requires
a reason. Both require a person to do it — an automated process cannot close an opportunity.

## Analytics

**Analytics** has three views: the funnel (a lead counts at every stage it *reached*, even if later lost),
MRR broken down by campaign/industry/country/service/signal/message-template, and an experiment view that
compares reply/meeting/close rates across combinations of those dimensions with a 95% confidence interval
— always showing the sample size and labelling small samples "insufficient" rather than implying proof.

## Extending to a new industry

Nothing in `core/`, `engines/` or `services/` references trucking, Poland, or accounting by name — those
only exist as rows in the `campaigns` and `services` tables. To add a new industry: create a campaign with
its ICP, add or reuse services, and (optionally) extend `engines/signal_engine.py`'s `SIGNAL_CATALOG` and
`_RULES` if the new market has its own hiring/growth vocabulary worth detecting automatically. No other
code changes are required.

## Adding a service

**Services → Add service.** Name, pricing (monthly or one-off project), a price/target MRR, a company-size
range, and — the part that matters — which recorded signals justify recommending it. A service with no
signals attached will never be recommended, by design.

## Adding a new lead source

Implement `adapters.base.BaseLeadSource.fetch()` returning `LeadRecord`s, and register the class in
`engines/lead_hunter.py`'s `SOURCES` dict. See `adapters/future/README.md` for the list of sources this
version doesn't implement (search-engine discovery, job boards, public company registries, CRM exports) —
each was left out because it needs its own credentials/terms-of-service review, not because the
architecture can't support it.

## Poland Registries (CEIDG / KRS)

A real ELT layer for discovering and enriching Polish businesses from official government
registries, built as an extension of the engines above rather than a parallel system — a
registry hit becomes a `Company` row (with `nip`/`regon`/`krs_number`/`legal_form`/`pkd_codes`
columns) and flows through the exact same qualification, offer-matching, CRM and audit machinery
as every other lead. Open it from **Poland Registries** in the nav.

**What's real and working:**
- An **immutable raw layer** (`raw_records`) — every fetch is kept forever, deduplicated only
  against its own immediately-previous fetch (so a value that changes and later reverts still
  gets its own row — the timeline is never silently collapsed).
- **CEIDG v3** (`poland/ceidg_client.py`) — the real, documented REST API for Poland's sole-trader
  (JDG) registry: search by name, NIP, PKD code, city/voivodeship, registration-date range and
  status (genuine "new business" discovery), plus a `/zmiana` changes feed (genuine "what changed"
  discovery). Needs a free JWT — register at
  [dane.biznes.gov.pl/pl/dane-po-api](https://dane.biznes.gov.pl/pl/dane-po-api) and set
  `CEIDG_API_TOKEN` in `.env`.
- **KRS** (`poland/krs_client.py`) — the real, free, keyless Ministry of Justice API for companies
  (sp. z o.o., S.A., ...). Lookup is by KRS number only; there is no verified search-by-name
  endpoint, so this enriches a company you already have a KRS number for rather than discovering
  new ones.
- **Entity resolution** (`poland/entity_resolution.py`) — matches deterministically on NIP, then
  REGON, then KRS number before falling back to the existing fuzzy-name/domain duplicate detection,
  so a company first found via CEIDG and later found to have incorporated (a KRS number) enriches
  onto the *same* record instead of creating a duplicate.
- **Change/event detection** (`poland/events.py`) — diffs each new fetch against the previous one
  for that entity, writes a `BusinessEvent` either way, and promotes selected event types (e.g. a
  dormant business reactivating) into the existing Signal engine automatically, so qualification
  picks them up with no extra step.
- **Source registry and run log** (`poland/source_registry.py`, the `source_runs` table) — every
  connector call is logged with its status (`SUCCESS`/`PARTIAL_SUCCESS`/`FAILED`/`SKIPPED`), counts
  and errors, visible under **Poland Registries → Recent runs**; nothing fails silently.
- 25 tests against realistic mocked responses built from the official API documentation (raw-layer
  dedup/history, canonical field mapping, entity resolution, event/signal promotion, both clients'
  parsing and error handling, and the full search→ingest→qualify flow end to end).

**Honestly deferred, not implemented:**
- **GUS REGON** is registered in the source registry as `reliability_score: 0` / not connected — it's
  a stateful SOAP 1.2 service (not REST), and like KRS it's lookup-by-identifier only, so it would
  add enrichment overlap with KRS rather than new discovery capability. Worth adding if cross-checking
  REGON's employee-count bracket becomes valuable.
- **Criteria-based discovery of registered companies** (sp. z o.o. etc.) — no verified public
  search-by-PKD/city endpoint was found for KRS in this build; discovery for that segment currently
  means supplying KRS numbers from elsewhere (a company's own site, CEIDG's linked-partnership field,
  or a manually sourced list), not an open-ended "all new companies this week" query. Poland's
  Monitor Sądowy i Gospodarczy (the bulletin that publishes new KRS registrations) is a plausible
  next connector for that gap and hasn't been investigated yet.
- **No live call to the real government endpoints was made from this build environment** — its
  network is restricted to package registries, not `dane.biznes.gov.pl` or `api-krs.ms.gov.pl`.
  Both clients are built and tested exactly to the official documented request/response shapes and
  pass a full mocked test suite, but you should do one real smoke test (a CEIDG search, a KRS lookup
  by a KRS number you know) after setting up your token, before relying on this for volume.
- The KRS JSON canonical mapping (`poland/canonical.py::from_krs`) is built from the well-documented,
  stable "dział 1–6" structure of a KRS extract (the same sections a printed odpis uses) but hasn't
  been checked field-by-field against one live response — if a field comes back empty after your
  first real lookup, check the actual key names in that response and adjust the mapper.
- Everything in the original specification beyond this — the self-learning weight optimizer,
  prompt versioning, a scheduled daily job runner, the full suppression/compliance list manager,
  and PKD/city-based discovery for company-form entities — is not built. The architecture (the
  `source_runs` log, the `BusinessEvent` table, the `SourceDef` registry) was deliberately shaped so
  each of those can be added without restructuring what's here.

## Opportunity Score, Top Opportunities, and the feedback engine

Every qualified lead's five dimensions (Fit, Need, Buying Signal, Ability to Pay, Contactability) are
already blended into one priority composite for sorting — this is now also exposed directly as
`opportunity_score` (0–100, a real database column, sortable) along with a point-by-point breakdown
(`qualification.opportunity.breakdown`) showing exactly how many points each dimension contributed,
always summing exactly to the headline number. It is the *same* number driving Priority, never a second,
different score that could disagree with it.

**Dashboard → Top opportunities** answers "if I have 30 minutes today, which companies should I contact?"
— the leads with the highest Opportunity Score that aren't already closed, each with its evidence,
recommended offer, contact, and whether a draft message already exists.

**Analytics → Feedback** is explicitly *not* a black-box model: it's plain grouped counts and rates —
which lead sources, industries, and signals actually produce leads that qualify and win — computed over
every lead you've actually worked, not a trained weight that silently adjusts itself. Marking a lead
**Not a fit** now requires a structured reason (not relevant / wrong industry / too small / too large /
wrong contact / no email found / bad data / other) specifically so this breakdown means something instead
of being free-text noise.

## Compliance

A company's compliance status (**Compliance** in the nav) defaults to **Review required** the moment it's
created — it is never assumed safe to contact just because no one has said otherwise. Marking a company
**Clear** requires picking a lawful basis (e.g. legitimate interest for B2B outreach to a published
business contact) — that's always your judgment call per company, never an assumption the app makes for
you. A **suppression list** (by company, email, or domain) sits underneath all of it and always wins, even
overriding a company already marked Clear. A message cannot be approved — the same gate that blocks
placeholder text — unless the company's live, freshly-computed status is exactly Clear.

## Known limitations (V1)

- **No authentication.** This is a local-first, single-user tool. Anyone who can reach the port can use
  it. Don't expose it on an untrusted network without putting your own auth/proxy in front of it.
- **No database migrations.** Schema changes on an existing database need manual SQL or Alembic; there's
  no version-controlled migration path yet.
- **Web research reads one company's own site only.** It doesn't search the web to *discover* new
  prospects — see "Adding a new lead source" above for how that would be added.
- **The AI-polish guard is a heuristic** (it discards output that introduces numbers/URLs not present in
  the source), not a formal fact-checker. Review AI-assisted drafts before sending, as the UI reminds you.
- **Single currency (USD)** in pricing displays; MRR figures for Poland are entered in USD-equivalent
  terms rather than converted from PLN.
- **No email/calendar integration.** Sending and scheduling stay manual by design (this is what makes the
  "never auto-sends" guarantee possible) — recording that you sent something is a deliberate, separate step.
- **The feedback engine reports; it doesn't adjust anything automatically.** Source/industry/signal
  quality are there for a person to read and act on (e.g. by changing campaign weights by hand) — there
  is deliberately no self-tuning weight optimizer, matching the "keep explainable scoring" principle
  rather than a black-box model that reweights itself.
- **No daily automation script yet.** Running CEIDG/KRS discovery, re-qualifying, and refreshing the
  feedback tables on a schedule currently means running the relevant API calls yourself (or wiring your
  own cron/Task Scheduler entry to them) — there's no bundled `run_daily.py` orchestration script yet.

## Suggested next steps for V2

1. **Authentication and multi-user support** — accounts, permissions, and per-user task ownership, since
   V1 is intentionally single-user.
2. **Database migrations** (Alembic) so schema changes don't require manual intervention on a live database.
3. **A prospect-discovery adapter** (a search/registry API) so new companies can be found, not just
   researched once you already have a name — the architecture in `adapters/` was built to make this a
   contained addition.
4. **Email/calendar connectors** (send-tracking via IMAP/Gmail API, calendar booking links) as an
   *optional* layer on top of the current manual send-and-record flow, keeping the manual path available
   for anyone who wants the current guarantee.
5. **Multi-currency support** for pricing and MRR reporting.
6. **Bulk research runs** (queue research across a whole campaign with rate-limiting) rather than one
   company at a time.
7. **Richer experiment design** (sequential/multi-armed comparisons rather than the current retrospective
   grouping) once there's enough real send volume to make it worthwhile.
8. **A scheduled daily job runner** (master prompt §32-33) that calls CEIDG/KRS discovery, re-qualifies,
   and produces a compact "today" executive-summary report — the pieces it would call (discovery,
   qualification, feedback) all already exist and are already tested; this is pure orchestration.
9. **Prompt versioning** (§42) — tagging each AI call with a prompt/model/version triple so output
   quality can be compared across changes, for the optional AI-assisted paths only.
