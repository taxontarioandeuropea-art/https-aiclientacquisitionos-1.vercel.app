"""Normalised data model.

Lead.status holds the pipeline stage (see core.constants.PIPELINE_STAGES).
Records created by demo mode carry is_demo=True so they can be removed without touching real data.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

from sqlalchemy import (JSON, Boolean, Column, Date, DateTime, Float, ForeignKey, Index, Integer,
                        String, Table, Text, UniqueConstraint)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from core.utils import utcnow


class Base(DeclarativeBase):
    def as_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for col in self.__table__.columns:
            v = getattr(self, col.key)
            out[col.key] = v.isoformat() if isinstance(v, (date, datetime)) else v
        return out


campaign_services = Table(
    "campaign_services", Base.metadata,
    Column("campaign_id", ForeignKey("campaigns.id", ondelete="CASCADE"), primary_key=True),
    Column("service_id", ForeignKey("services.id", ondelete="CASCADE"), primary_key=True),
)


class Company(Base):
    __tablename__ = "companies"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    legal_name: Mapped[Optional[str]] = mapped_column(String(255))
    website: Mapped[Optional[str]] = mapped_column(String(500))
    domain: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    normalized_name: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    country: Mapped[Optional[str]] = mapped_column(String(80), index=True)
    state: Mapped[Optional[str]] = mapped_column(String(80))
    city: Mapped[Optional[str]] = mapped_column(String(120))
    address: Mapped[Optional[str]] = mapped_column(String(300))
    industry: Mapped[Optional[str]] = mapped_column(String(120), index=True)
    subindustry: Mapped[Optional[str]] = mapped_column(String(120))
    employees: Mapped[Optional[int]] = mapped_column(Integer)
    estimated_revenue: Mapped[Optional[float]] = mapped_column(Float)          # annual, USD-equivalent
    estimated_scale: Mapped[Optional[str]] = mapped_column(String(120))        # e.g. "35 trucks"
    ownership_type: Mapped[Optional[str]] = mapped_column(String(120))
    # Polish official-registry identifiers (populated by the poland/ connectors; never guessed).
    nip: Mapped[Optional[str]] = mapped_column(String(10), index=True)          # tax ID, 10 digits
    regon: Mapped[Optional[str]] = mapped_column(String(14), index=True)        # statistical ID, 9 or 14 digits
    krs_number: Mapped[Optional[str]] = mapped_column(String(10), index=True)   # National Court Register number
    legal_form: Mapped[Optional[str]] = mapped_column(String(120))              # JDG, sp. z o.o., S.A., ...
    pkd_codes: Mapped[list] = mapped_column(JSON, default=list)                 # [{"code": "...", "name": "..."}]
    pkd_main: Mapped[Optional[str]] = mapped_column(String(10))
    registry_status: Mapped[Optional[str]] = mapped_column(String(60))          # AKTYWNY / WYKRESLONY / ... or KRS status
    registry_source: Mapped[Optional[str]] = mapped_column(String(20))          # "ceidg" | "krs" | None
    registration_date: Mapped[Optional[date]] = mapped_column(Date)
    deregistration_date: Mapped[Optional[date]] = mapped_column(Date)
    last_registry_sync_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    technology_stack: Mapped[list] = mapped_column(JSON, default=list)
    accounting_software: Mapped[Optional[str]] = mapped_column(String(120))
    growth_status: Mapped[Optional[str]] = mapped_column(String(120))
    description: Mapped[Optional[str]] = mapped_column(Text)
    email: Mapped[Optional[str]] = mapped_column(String(255))                  # general company mailbox, if published
    phone: Mapped[Optional[str]] = mapped_column(String(60))
    notes: Mapped[Optional[str]] = mapped_column(Text)
    source: Mapped[Optional[str]] = mapped_column(String(255))
    source_url: Mapped[Optional[str]] = mapped_column(String(500))
    field_sources: Mapped[dict] = mapped_column(JSON, default=dict)            # provenance for researched fields
    research_report: Mapped[Optional[dict]] = mapped_column(JSON)
    last_researched_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    archived: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    merged_into_id: Mapped[Optional[int]] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    people: Mapped[list["Person"]] = relationship(back_populates="company", cascade="all, delete-orphan")
    leads: Mapped[list["Lead"]] = relationship(back_populates="company", cascade="all, delete-orphan")
    signals: Mapped[list["Signal"]] = relationship(back_populates="company", cascade="all, delete-orphan")
    interactions: Mapped[list["Interaction"]] = relationship(back_populates="company", cascade="all, delete-orphan")


class Person(Base):
    __tablename__ = "people"
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)
    first_name: Mapped[Optional[str]] = mapped_column(String(120))
    last_name: Mapped[Optional[str]] = mapped_column(String(120))
    full_name: Mapped[Optional[str]] = mapped_column(String(240), index=True)
    title: Mapped[Optional[str]] = mapped_column(String(200))
    department: Mapped[Optional[str]] = mapped_column(String(120))
    email: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    phone: Mapped[Optional[str]] = mapped_column(String(60))
    linkedin_url: Mapped[Optional[str]] = mapped_column(String(500))
    decision_maker_level: Mapped[Optional[str]] = mapped_column(String(30), default="unknown")
    source: Mapped[Optional[str]] = mapped_column(String(255))
    source_url: Mapped[Optional[str]] = mapped_column(String(500))
    confidence: Mapped[Optional[float]] = mapped_column(Float, default=0.8)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    company: Mapped[Optional[Company]] = relationship(back_populates="people")


class Service(Base):
    __tablename__ = "services"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160), unique=True)
    description: Mapped[Optional[str]] = mapped_column(Text)
    target_industries: Mapped[list] = mapped_column(JSON, default=list)
    target_employees_min: Mapped[Optional[int]] = mapped_column(Integer)
    target_employees_max: Mapped[Optional[int]] = mapped_column(Integer)
    target_technology: Mapped[list] = mapped_column(JSON, default=list)
    typical_problems: Mapped[list] = mapped_column(JSON, default=list)
    pricing_model: Mapped[str] = mapped_column(String(20), default="monthly")   # monthly | project
    minimum_price: Mapped[Optional[float]] = mapped_column(Float)
    target_mrr: Mapped[Optional[float]] = mapped_column(Float)
    deliverables: Mapped[list] = mapped_column(JSON, default=list)
    required_signals: Mapped[list] = mapped_column(JSON, default=list)          # any-of signal types that indicate this service
    preferred_decision_makers: Mapped[list] = mapped_column(JSON, default=list)
    message_template: Mapped[Optional[str]] = mapped_column(Text)
    follow_on_service_id: Mapped[Optional[int]] = mapped_column(ForeignKey("services.id", ondelete="SET NULL"))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Campaign(Base):
    __tablename__ = "campaigns"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), unique=True)
    country: Mapped[Optional[str]] = mapped_column(String(80))
    industry: Mapped[Optional[str]] = mapped_column(String(120))
    subindustry: Mapped[Optional[str]] = mapped_column(String(120))
    icp_description: Mapped[Optional[str]] = mapped_column(Text)
    target_employees_min: Mapped[Optional[int]] = mapped_column(Integer)
    target_employees_max: Mapped[Optional[int]] = mapped_column(Integer)
    target_revenue_min: Mapped[Optional[float]] = mapped_column(Float)
    target_revenue_max: Mapped[Optional[float]] = mapped_column(Float)
    target_technology: Mapped[list] = mapped_column(JSON, default=list)
    target_ownership: Mapped[Optional[str]] = mapped_column(String(120))
    target_geography: Mapped[Optional[str]] = mapped_column(String(255))
    minimum_mrr: Mapped[Optional[float]] = mapped_column(Float)
    target_mrr: Mapped[Optional[float]] = mapped_column(Float)
    preferred_decision_maker: Mapped[list] = mapped_column(JSON, default=list)
    campaign_status: Mapped[str] = mapped_column(String(20), default="active")
    research_rules: Mapped[Optional[str]] = mapped_column(Text)
    qualification_rules: Mapped[dict] = mapped_column(JSON, default=dict)      # weights / thresholds overrides
    outreach_strategy: Mapped[Optional[str]] = mapped_column(Text)
    followup_sequence: Mapped[list] = mapped_column(JSON, default=list)        # [{day, type, channel}]
    language: Mapped[str] = mapped_column(String(10), default="en")
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    services: Mapped[list[Service]] = relationship(secondary=campaign_services)
    leads: Mapped[list["Lead"]] = relationship(back_populates="campaign")


class Lead(Base):
    """A company/person combination being evaluated inside one campaign."""
    __tablename__ = "leads"
    __table_args__ = (UniqueConstraint("company_id", "campaign_id", name="uq_lead_company_campaign"),
                      Index("ix_leads_status", "status"))
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)
    person_id: Mapped[Optional[int]] = mapped_column(ForeignKey("people.id", ondelete="SET NULL"))
    campaign_id: Mapped[Optional[int]] = mapped_column(ForeignKey("campaigns.id", ondelete="SET NULL"), index=True)
    status: Mapped[str] = mapped_column(String(20), default="NEW")
    fit_score: Mapped[Optional[int]] = mapped_column(Integer)
    need_score: Mapped[Optional[int]] = mapped_column(Integer)
    signal_score: Mapped[Optional[int]] = mapped_column(Integer)
    ability_to_pay_score: Mapped[Optional[int]] = mapped_column(Integer)
    contactability_score: Mapped[Optional[int]] = mapped_column(Integer)
    overall_priority: Mapped[Optional[str]] = mapped_column(String(10), index=True)
    opportunity_score: Mapped[Optional[int]] = mapped_column(Integer, index=True)  # master prompt §14, 0-100 blend; see qualification.opportunity for the breakdown
    qualification: Mapped[Optional[dict]] = mapped_column(JSON)                # full explainable breakdown
    qualified_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    potential_mrr: Mapped[Optional[float]] = mapped_column(Float)
    potential_project_value: Mapped[Optional[float]] = mapped_column(Float)
    actual_mrr: Mapped[Optional[float]] = mapped_column(Float)                 # only set by the user when marking WON
    recommended_service_id: Mapped[Optional[int]] = mapped_column(ForeignKey("services.id", ondelete="SET NULL"))
    recommended_service: Mapped[Optional[str]] = mapped_column(String(160))
    offer: Mapped[Optional[dict]] = mapped_column(JSON)
    detected_problem: Mapped[Optional[str]] = mapped_column(Text)
    primary_signal_type: Mapped[Optional[str]] = mapped_column(String(80))
    next_action: Mapped[Optional[str]] = mapped_column(String(255))
    next_action_date: Mapped[Optional[date]] = mapped_column(Date)
    last_interaction_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    lost_reason: Mapped[Optional[str]] = mapped_column(String(255))
    disqualify_reason: Mapped[Optional[str]] = mapped_column(String(20))  # one of core.constants.DISQUALIFY_REASONS, set when status becomes NOT_A_FIT
    won_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    company: Mapped[Company] = relationship(back_populates="leads")
    person: Mapped[Optional[Person]] = relationship(foreign_keys=[person_id])
    campaign: Mapped[Optional[Campaign]] = relationship(back_populates="leads")
    messages: Mapped[list["OutreachMessage"]] = relationship(back_populates="lead", cascade="all, delete-orphan")
    tasks: Mapped[list["Task"]] = relationship(back_populates="lead", cascade="all, delete-orphan")
    history: Mapped[list["StageHistory"]] = relationship(back_populates="lead", cascade="all, delete-orphan",
                                                         order_by="StageHistory.changed_at")


class StageHistory(Base):
    __tablename__ = "stage_history"
    id: Mapped[int] = mapped_column(primary_key=True)
    lead_id: Mapped[int] = mapped_column(ForeignKey("leads.id", ondelete="CASCADE"), index=True)
    from_stage: Mapped[Optional[str]] = mapped_column(String(20))
    to_stage: Mapped[str] = mapped_column(String(20))
    changed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    actor: Mapped[str] = mapped_column(String(20), default="user")
    note: Mapped[Optional[str]] = mapped_column(String(255))
    lead: Mapped[Lead] = relationship(back_populates="history")


class Signal(Base):
    """Evidence-backed buying/need signal. Never invented: evidence_text and source are mandatory."""
    __tablename__ = "signals"
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)
    signal_type: Mapped[str] = mapped_column(String(80), index=True)
    description: Mapped[str] = mapped_column(String(500))
    source: Mapped[str] = mapped_column(String(255))
    source_url: Mapped[Optional[str]] = mapped_column(String(500))
    date_detected: Mapped[date] = mapped_column(Date, default=date.today)
    confidence: Mapped[float] = mapped_column(Float, default=0.7)
    evidence_text: Mapped[str] = mapped_column(Text)
    kind: Mapped[str] = mapped_column(String(20), default="FACT")              # FACT | INFERENCE
    origin: Mapped[str] = mapped_column(String(20), default="manual")          # manual | web_research | import | demo
    verified: Mapped[bool] = mapped_column(Boolean, default=False)             # evidence found verbatim in fetched source text
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    company: Mapped[Company] = relationship(back_populates="signals")


class Interaction(Base):
    __tablename__ = "interactions"
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)
    person_id: Mapped[Optional[int]] = mapped_column(ForeignKey("people.id", ondelete="SET NULL"))
    lead_id: Mapped[Optional[int]] = mapped_column(ForeignKey("leads.id", ondelete="CASCADE"), index=True)
    type: Mapped[str] = mapped_column(String(20), default="note")
    direction: Mapped[str] = mapped_column(String(20), default="internal")
    subject: Mapped[Optional[str]] = mapped_column(String(300))
    body: Mapped[Optional[str]] = mapped_column(Text)
    outcome: Mapped[Optional[str]] = mapped_column(String(200))
    occurred_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    message_id: Mapped[Optional[int]] = mapped_column(Integer)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    company: Mapped[Company] = relationship(back_populates="interactions")


class OutreachMessage(Base):
    """Every message is a draft until the USER approves and sends it. Nothing is sent by the app."""
    __tablename__ = "outreach_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    lead_id: Mapped[int] = mapped_column(ForeignKey("leads.id", ondelete="CASCADE"), index=True)
    campaign_id: Mapped[Optional[int]] = mapped_column(ForeignKey("campaigns.id", ondelete="SET NULL"))
    person_id: Mapped[Optional[int]] = mapped_column(ForeignKey("people.id", ondelete="SET NULL"))
    channel: Mapped[str] = mapped_column(String(20), default="email")
    recipient: Mapped[Optional[str]] = mapped_column(String(255))
    subject: Mapped[Optional[str]] = mapped_column(String(300))
    body: Mapped[str] = mapped_column(Text)
    template_key: Mapped[Optional[str]] = mapped_column(String(80), index=True)
    sequence_step: Mapped[int] = mapped_column(Integer, default=0)             # 0 = initial, 1.. = follow-ups
    personalization_evidence: Mapped[list] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(20), default="draft", index=True)
    ai_assisted: Mapped[bool] = mapped_column(Boolean, default=False)
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    replied_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    lead: Mapped[Lead] = relationship(back_populates="messages")


class Task(Base):
    __tablename__ = "tasks"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[Optional[str]] = mapped_column(Text)
    task_type: Mapped[str] = mapped_column(String(30), default="other")
    status: Mapped[str] = mapped_column(String(15), default="open", index=True)
    priority: Mapped[str] = mapped_column(String(10), default="MEDIUM")
    due_date: Mapped[Optional[date]] = mapped_column(Date, index=True)
    lead_id: Mapped[Optional[int]] = mapped_column(ForeignKey("leads.id", ondelete="CASCADE"), index=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)
    auto_generated: Mapped[bool] = mapped_column(Boolean, default=False)
    dedupe_key: Mapped[Optional[str]] = mapped_column(String(120), index=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    lead: Mapped[Optional[Lead]] = relationship(back_populates="tasks")


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    action: Mapped[str] = mapped_column(String(60), index=True)
    entity_type: Mapped[Optional[str]] = mapped_column(String(40), index=True)
    entity_id: Mapped[Optional[int]] = mapped_column(Integer)
    summary: Mapped[str] = mapped_column(String(500))
    details: Mapped[Optional[dict]] = mapped_column(JSON)
    actor: Mapped[str] = mapped_column(String(20), default="user")             # user | system | ai


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(60), primary_key=True)
    value: Mapped[Any] = mapped_column(JSON)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class DuplicateDismissal(Base):
    """User said 'these two are not duplicates'. Keeps them out of the duplicate queue."""
    __tablename__ = "duplicate_dismissals"
    __table_args__ = (UniqueConstraint("entity_type", "id_a", "id_b", name="uq_dup_dismissal"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    entity_type: Mapped[str] = mapped_column(String(20), default="company")
    id_a: Mapped[int] = mapped_column(Integer)
    id_b: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ------------------------------------------------------------------ Poland ELT layer
class RawRecord(Base):
    """Immutable raw layer (master prompt §6): every extracted record, exactly as received,
    before any normalisation. Never updated or overwritten — a re-fetch is a new row."""
    __tablename__ = "raw_records"
    __table_args__ = (Index("ix_raw_source_hash", "source_id", "record_hash"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[str] = mapped_column(String(40), index=True)         # e.g. "ceidg", "krs"
    source_url: Mapped[Optional[str]] = mapped_column(String(500))
    external_id: Mapped[Optional[str]] = mapped_column(String(120), index=True)   # CEIDG id / KRS number / ...
    record_hash: Mapped[str] = mapped_column(String(64), index=True)       # sha256 of raw_payload, for dedup
    raw_payload: Mapped[dict] = mapped_column(JSON)
    parser_version: Mapped[str] = mapped_column(String(20), default="1")
    retrieved_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    business_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id", ondelete="SET NULL"), index=True)

    def as_dict(self) -> dict:
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


class BusinessEvent(Base):
    """A detected change in a business between two registry snapshots (master prompt §25-26).
    Drives event-driven lead generation: a fresh event can be turned into a Signal automatically."""
    __tablename__ = "business_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)
    event_type: Mapped[str] = mapped_column(String(60), index=True)   # new_business, status_changed, pkd_added, ...
    event_date: Mapped[date] = mapped_column(Date, index=True)
    source_id: Mapped[str] = mapped_column(String(40))
    description: Mapped[str] = mapped_column(String(500))
    old_value: Mapped[Optional[str]] = mapped_column(String(500))
    new_value: Mapped[Optional[str]] = mapped_column(String(500))
    confidence: Mapped[float] = mapped_column(Float, default=1.0)     # 1.0 for deterministic registry diffs
    signal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("signals.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    company: Mapped["Company"] = relationship()

    def as_dict(self) -> dict:
        return {"id": self.id, "company_id": self.company_id, "event_type": self.event_type,
                "event_date": self.event_date.isoformat() if self.event_date else None, "source_id": self.source_id,
                "description": self.description, "old_value": self.old_value, "new_value": self.new_value,
                "confidence": self.confidence, "signal_id": self.signal_id}


class SourceRun(Base):
    """One execution of one connector (master prompt §38 'jobs'/'job_runs'): never silently fails —
    every run ends SUCCESS, PARTIAL_SUCCESS, FAILED or SKIPPED with counts and a reason."""
    __tablename__ = "source_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[str] = mapped_column(String(40), index=True)
    operation: Mapped[str] = mapped_column(String(40))             # "search" | "changes" | "enrich"
    params: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="RUNNING")  # RUNNING|SUCCESS|PARTIAL_SUCCESS|FAILED|SKIPPED
    fetched: Mapped[int] = mapped_column(Integer, default=0)
    created_businesses: Mapped[int] = mapped_column(Integer, default=0)
    updated_businesses: Mapped[int] = mapped_column(Integer, default=0)
    events_created: Mapped[int] = mapped_column(Integer, default=0)
    errors: Mapped[list] = mapped_column(JSON, default=list)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    def as_dict(self) -> dict:
        return {"id": self.id, "source_id": self.source_id, "operation": self.operation, "params": self.params,
                "status": self.status, "fetched": self.fetched, "created_businesses": self.created_businesses,
                "updated_businesses": self.updated_businesses, "events_created": self.events_created,
                "errors": self.errors, "started_at": self.started_at.isoformat() if self.started_at else None,
                "finished_at": self.finished_at.isoformat() if self.finished_at else None}


class SuppressionEntry(Base):
    """Master prompt §23: a company, email, or domain that must never be contacted — manually added,
    or written automatically on an opt-out/bounce/complaint. Checked before a message may be approved.
    Suppression is permanent until a person removes it; nothing in this app ever removes an entry on
    its own."""
    __tablename__ = "suppression_entries"
    __table_args__ = (UniqueConstraint("match_type", "value", name="uq_suppression_match"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    match_type: Mapped[str] = mapped_column(String(20))        # "company" | "email" | "domain"
    value: Mapped[str] = mapped_column(String(255), index=True)   # company_id as str, or the email/domain, lowercased
    reason: Mapped[str] = mapped_column(String(40))            # "opt_out" | "complaint" | "bounced" | "manual" | "legal_request"
    note: Mapped[Optional[str]] = mapped_column(Text)
    added_by: Mapped[str] = mapped_column(String(40), default="user")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    def as_dict(self) -> dict:
        return {"id": self.id, "match_type": self.match_type, "value": self.value, "reason": self.reason,
                "note": self.note, "added_by": self.added_by, "created_at": self.created_at.isoformat()}


class ComplianceRecord(Base):
    """Master prompt §23: one row per company, tracking the lawful basis for contacting it and any
    restriction. A company with no row defaults to REVIEW_REQUIRED — compliance status is never
    assumed clear by omission."""
    __tablename__ = "compliance_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), unique=True, index=True)
    status: Mapped[str] = mapped_column(String(20), default="REVIEW_REQUIRED")
    # CLEAR | REVIEW_REQUIRED | RESTRICTED | SUPPRESSED
    lawful_basis: Mapped[Optional[str]] = mapped_column(String(40))
    # "legitimate_interest_b2b" | "public_task_source" | "consent" | None
    contact_type: Mapped[Optional[str]] = mapped_column(String(20))   # "professional" | "personal" | None
    jurisdiction: Mapped[Optional[str]] = mapped_column(String(10))   # ISO country code the contact sits in
    source_id: Mapped[Optional[str]] = mapped_column(String(40))      # which source established the basis (e.g. "ceidg", "manual")
    reviewed_by: Mapped[Optional[str]] = mapped_column(String(120))
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    company: Mapped["Company"] = relationship()

    def as_dict(self) -> dict:
        return {"id": self.id, "company_id": self.company_id, "status": self.status, "lawful_basis": self.lawful_basis,
                "contact_type": self.contact_type, "jurisdiction": self.jurisdiction, "source_id": self.source_id,
                "reviewed_by": self.reviewed_by, "reviewed_at": self.reviewed_at.isoformat() if self.reviewed_at else None,
                "notes": self.notes, "updated_at": self.updated_at.isoformat() if self.updated_at else None}
