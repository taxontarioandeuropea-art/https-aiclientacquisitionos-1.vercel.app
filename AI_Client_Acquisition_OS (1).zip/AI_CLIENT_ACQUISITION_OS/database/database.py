"""Engine / session management.

SQLite for V1. Only portable SQLAlchemy types are used (JSON, String, Float ...), so switching to
PostgreSQL is a matter of changing DATABASE_URL (and adding Alembic migrations, see README).
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator, Optional

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from config import config

engine: Optional[Engine] = None
SessionLocal: Optional[sessionmaker] = None


def init_engine(url: Optional[str] = None, echo: bool = False) -> Engine:
    global engine, SessionLocal
    url = url or config.database_url
    kwargs = {"echo": echo, "future": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
    engine = create_engine(url, **kwargs)
    if url.startswith("sqlite"):
        @event.listens_for(engine, "connect")
        def _sqlite_pragmas(dbapi_conn, _):           # noqa: ANN001
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA journal_mode=WAL")
            cur.close()
    SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)
    return engine


def init_db() -> None:
    """Create all tables if missing. Safe to call on every start."""
    from database.models import Base
    if engine is None:
        init_engine()
    Base.metadata.create_all(engine)


def get_db() -> Iterator[Session]:
    """FastAPI dependency: one session per request; commit on success, rollback on error."""
    if SessionLocal is None:
        init_engine()
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


@contextmanager
def session_scope() -> Iterator[Session]:
    if SessionLocal is None:
        init_engine()
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
