"""AI Client Acquisition OS — application entry point.

Run:  python app.py        (creates the database, loads demo data on first run, serves on http://127.0.0.1:8000)
"""
from __future__ import annotations

import logging
import logging.handlers
import traceback
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from starlette.exceptions import HTTPException as StarletteHTTPException

from config import BASE_DIR, config
from core.errors import AppError
from database import database
from database.database import init_db, init_engine, session_scope

log = logging.getLogger("acq_os")


def setup_logging() -> None:
    if any(isinstance(h, logging.handlers.RotatingFileHandler) for h in logging.getLogger().handlers):
        return
    config.log_dir.mkdir(exist_ok=True)
    fh = logging.handlers.RotatingFileHandler(config.log_dir / "app.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(fh)


def _err(status: int, message: str, operation: str, cause: str, suggestion: str, code: str = "error") -> dict:
    return {"error": {"message": message, "operation": operation, "cause": cause, "suggestion": suggestion, "code": code}}


def create_app(database_url: Optional[str] = None, *, seed_demo: Optional[bool] = None) -> FastAPI:
    setup_logging()
    init_engine(database_url)
    init_db()
    app = FastAPI(title=config.app_name, docs_url="/api/docs", redoc_url=None, openapi_url="/api/openapi.json")
    app.state.templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
    app.state.templates.env.globals["app_name"] = config.app_name
    app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

    from api import campaign_routes, crm_routes, data_routes, pages, poland_routes
    app.include_router(crm_routes.router)
    app.include_router(campaign_routes.router)
    app.include_router(data_routes.router)
    app.include_router(poland_routes.router)
    app.include_router(pages.router)

    def wants_json(request: Request) -> bool:
        return request.url.path.startswith("/api")

    def respond(request: Request, status: int, payload: dict):
        if wants_json(request):
            return JSONResponse(payload, status_code=status)
        return request.app.state.templates.TemplateResponse(request, "error.html", {
            "error": payload["error"], "status": status, "app_name": config.app_name, "nav": pages.NAV, "nav2": pages.NAV_SECONDARY,
            "active": "", "title": "Error", "demo_count": 0}, status_code=status)

    @app.exception_handler(AppError)
    async def app_error(request: Request, exc: AppError):
        log.warning("AppError %s on %s: %s | cause=%s", exc.code, request.url.path, exc.message, exc.cause)
        return respond(request, exc.status_code, {"error": exc.to_dict()})

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request: Request, exc: StarletteHTTPException):
        text = {404: ("That page does not exist", "The address may be mistyped, or the record was deleted.", "Use the menu to go back to a list."),
                405: ("This action is not allowed here", f"{request.method} is not supported for {request.url.path}.", "Use the buttons in the application instead.")}
        m, c, f = text.get(exc.status_code, ("The request could not be completed", str(exc.detail), "Try again."))
        return respond(request, exc.status_code, _err(exc.status_code, m, f"{request.method} {request.url.path}", c, f, "http_error"))

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError):
        fields = "; ".join(f"{'.'.join(str(p) for p in e['loc'][1:]) or e['loc'][0]}: {e['msg']}" for e in exc.errors()[:5])
        return respond(request, 422, _err(422, "Some values are not valid", f"{request.method} {request.url.path}", fields,
                                          "Correct the highlighted fields and try again.", "validation_error"))

    @app.exception_handler(IntegrityError)
    async def integrity_error(request: Request, exc: IntegrityError):
        log.error("IntegrityError on %s: %s", request.url.path, exc)
        return respond(request, 409, _err(409, "This change conflicts with existing data", f"{request.method} {request.url.path}",
                                          "A uniqueness or reference rule in the database was violated (for example a duplicate name).",
                                          "Change the value or open the existing record instead.", "integrity_error"))

    @app.exception_handler(SQLAlchemyError)
    async def db_error(request: Request, exc: SQLAlchemyError):
        log.error("Database error on %s\n%s", request.url.path, traceback.format_exc())
        return respond(request, 500, _err(500, "A database operation failed", f"{request.method} {request.url.path}",
                                          "The database could not complete the request.", "Retry; if it persists, check logs/app.log and that sales.db is writable.", "database_error"))

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        log.error("Unhandled error on %s\n%s", request.url.path, traceback.format_exc())
        return respond(request, 500, _err(500, "Something went wrong", f"{request.method} {request.url.path}",
                                          f"{exc.__class__.__name__}: {str(exc)[:160]}", "Technical details were written to logs/app.log.", "internal_error"))

    if seed_demo is None:
        seed_demo = config.load_demo_on_first_run
    if seed_demo:
        from database.models import Company, Lead
        from services import demo_data
        with session_scope() as db:
            if db.query(Company).count() == 0 and db.query(Lead).count() == 0:
                demo_data.load_demo(db)
                log.info("Demo data loaded on first run")
    return app


app = None


def get_app() -> FastAPI:
    global app
    if app is None:
        app = create_app()
    return app


if __name__ == "__main__":
    import uvicorn
    application = get_app()
    print(f"\n  {config.app_name}\n  Open http://{config.host}:{config.port}\n  (Ctrl+C to stop)\n")
    uvicorn.run(application, host=config.host, port=config.port, log_level="info")
