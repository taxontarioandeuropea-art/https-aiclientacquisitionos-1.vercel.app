"""Automatic column mapping for CSV/XLSX imports (English + a few Polish headers)."""
from __future__ import annotations

import re
from typing import Any, Optional

_C, _P = "company.", "person."

# target -> synonyms (normalised: lowercase alphanumerics only)
_COMPANY = {
    "name": ["company", "companyname", "name", "organization", "organisation", "account", "accountname", "business", "businessname", "firma", "nazwa", "nazwafirmy"],
    "legal_name": ["legalname", "registeredname", "nazwaprawna"],
    "website": ["website", "url", "domain", "site", "web", "homepage", "companywebsite", "www", "strona", "stronawww"],
    "country": ["country", "kraj"],
    "state": ["state", "province", "region", "wojewodztwo", "stateprovince"],
    "city": ["city", "town", "miasto"],
    "address": ["address", "street", "streetaddress", "adres"],
    "industry": ["industry", "sector", "vertical", "branza"],
    "subindustry": ["subindustry", "subsector", "niche"],
    "employees": ["employees", "employeecount", "headcount", "numberofemployees", "noofemployees", "size", "staff", "fte", "pracownicy", "liczbapracownikow"],
    "estimated_revenue": ["revenue", "annualrevenue", "estimatedrevenue", "sales", "przychod", "przychody"],
    "estimated_scale": ["scale", "fleetsize", "trucks", "powerunits", "estimatedscale"],
    "ownership_type": ["ownership", "ownershiptype", "ownershipstructure"],
    "accounting_software": ["accountingsoftware", "accounting", "erp", "accountingsystem"],
    "technology_stack": ["technology", "techstack", "technologies", "tech", "technologystack"],
    "growth_status": ["growth", "growthstatus"],
    "description": ["description", "about", "summary", "companydescription"],
    "notes": ["notes", "comments", "note"],
    "source": ["source", "leadsource"],
    "source_url": ["sourceurl"],
}
_COMPANY_CONTACTABLE = {"phone": ["companyphone", "phone", "telephone", "tel", "telefon"],
                        "email": ["companyemail", "generalemail", "infoemail", "email", "emailaddress"]}
_PERSON = {
    "full_name": ["contactname", "fullname", "contact", "person", "ownername", "decisionmaker", "kontakt", "imieinazwisko"],
    "first_name": ["firstname", "first", "givenname", "imie"],
    "last_name": ["lastname", "last", "surname", "familyname", "nazwisko"],
    "title": ["title", "jobtitle", "position", "role", "contacttitle", "stanowisko"],
    "department": ["department", "dzial"],
    "email": ["email", "emailaddress", "contactemail", "workemail", "mail", "personalemail"],
    "phone": ["contactphone", "mobile", "cell", "directphone", "phonenumber", "phone", "telephone", "tel", "telefon"],
    "linkedin_url": ["linkedin", "linkedinurl", "linkedinprofile", "linkedinlink"],
}
_LEAD = {"campaign": ["campaign", "campaignname"], "stage": ["stage", "status", "pipelinestage"],
         "potential_mrr": ["potentialmrr", "mrr", "expectedmrr"], "notes": ["leadnotes"]}
_CAMPAIGN = {k: [k.replace("_", ""), *v] for k, v in {
    "name": ["campaign", "campaignname", "name"], "country": ["country", "market"], "industry": ["industry", "sector"],
    "subindustry": ["subindustry"], "icp_description": ["icp", "icpdescription", "description", "targetprofile"],
    "target_employees_min": ["minemployees", "employeesmin", "targetemployeesmin"],
    "target_employees_max": ["maxemployees", "employeesmax", "targetemployeesmax"],
    "target_revenue_min": ["minrevenue"], "target_revenue_max": ["maxrevenue"],
    "target_technology": ["technology", "targettechnology"], "target_ownership": ["ownership", "targetownership"],
    "target_geography": ["geography", "targetgeography", "region"], "minimum_mrr": ["minmrr", "minimummrr"],
    "target_mrr": ["targetmrr"], "preferred_decision_maker": ["decisionmaker", "preferreddecisionmaker", "decisionmakers"],
    "campaign_status": ["status", "campaignstatus"], "outreach_strategy": ["outreachstrategy", "strategy"],
    "research_rules": ["researchrules"], "services": ["services", "servicenames"],
}.items()}
_SERVICE = {k: [k.replace("_", ""), *v] for k, v in {
    "name": ["service", "servicename", "name"], "description": ["description"],
    "target_industries": ["industries", "targetindustries"], "target_employees_min": ["minemployees", "employeesmin"],
    "target_employees_max": ["maxemployees", "employeesmax"], "typical_problems": ["problems", "typicalproblems"],
    "pricing_model": ["pricingmodel", "pricing"], "minimum_price": ["minprice", "minimumprice", "price"],
    "target_mrr": ["targetmrr", "mrr"], "deliverables": ["deliverables"], "required_signals": ["signals", "requiredsignals", "triggers"],
    "preferred_decision_makers": ["decisionmakers", "preferreddecisionmakers"], "message_template": ["messagetemplate", "template"],
    "target_technology": ["technology", "targettechnology"],
}.items()}
_INTERACTION = {"company": ["company", "companyname", "account"], "contact_email": ["email", "contactemail"],
                "type": ["type", "interactiontype", "channel"], "direction": ["direction"],
                "subject": ["subject", "title"], "body": ["body", "message", "notes", "note", "content"],
                "outcome": ["outcome", "result"], "occurred_at": ["date", "occurredat", "datetime", "when"],
                "campaign": ["campaign"]}

KIND_FIELDS: dict[str, list[tuple[str, list[str]]]] = {}


def _build() -> None:
    def pairs(prefix, table):
        return [(prefix + k, v) for k, v in table.items()]
    company_only = pairs(_C, {**_COMPANY, **{k: v for k, v in _COMPANY_CONTACTABLE.items()}})
    person_prefixed = [(_P + "full_name", _PERSON["full_name"]), (_P + "first_name", _PERSON["first_name"]),
                       (_P + "last_name", _PERSON["last_name"]), (_P + "title", _PERSON["title"]),
                       (_P + "department", _PERSON["department"]),
                       (_P + "email", ["contactemail", "workemail", "personalemail"]),
                       (_P + "linkedin_url", _PERSON["linkedin_url"])]
    # leads/contacts: bare email/phone belong to the PERSON; only 'company phone/email' belong to the company
    company_leads = pairs(_C, {**_COMPANY, "phone": ["companyphone"], "email": ["companyemail", "generalemail"]})
    person_leads = pairs(_P, _PERSON)
    KIND_FIELDS["leads"] = pairs("lead.", _LEAD) + company_leads + person_leads
    KIND_FIELDS["contacts"] = pairs("lead.", {"campaign": _LEAD["campaign"]}) + \
        [(_C + "name", ["company", "companyname", "account", "organization", "organisation", "firma"]),
         (_C + "website", ["companywebsite", "website", "domain", "url", "www"])] + person_leads
    # companies: bare phone/email belong to the COMPANY; contact columns need contact-ish headers
    KIND_FIELDS["companies"] = company_only + person_prefixed
    KIND_FIELDS["campaigns"] = pairs("campaign.", _CAMPAIGN)
    KIND_FIELDS["services"] = pairs("service.", _SERVICE)
    KIND_FIELDS["interactions"] = pairs("interaction.", _INTERACTION)


_build()
KINDS = list(KIND_FIELDS)


def norm_header(h: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(h or "").lower())


def auto_map(headers: list[str], kind: str) -> dict[str, str]:
    """header -> target field (e.g. 'Company Name' -> 'company.name'). Each target is used once."""
    if kind not in KIND_FIELDS:
        raise ValueError(kind)
    used: set[str] = set()
    mapping: dict[str, str] = {}
    normed = [(h, norm_header(h)) for h in headers]
    for target, syns in KIND_FIELDS[kind]:               # priority order
        if target in used:
            continue
        for h, n in normed:
            if h in mapping or not n:
                continue
            if n in syns:
                mapping[h] = target
                used.add(target)
                break
    return mapping


def required_targets(kind: str) -> list[str]:
    return {"leads": ["company.name"], "companies": ["company.name"], "contacts": ["company.name"],
            "campaigns": ["campaign.name"], "services": ["service.name"], "interactions": ["interaction.company"]}[kind]


def available_targets(kind: str) -> list[str]:
    return [t for t, _ in KIND_FIELDS[kind]]


def apply_mapping(row: dict[str, Any], mapping: dict[str, str]) -> dict[str, dict[str, Any]]:
    """Split one raw row into {'company': {...}, 'person': {...}, ...} using the mapping."""
    out: dict[str, dict[str, Any]] = {}
    for header, target in mapping.items():
        if not target or "." not in target:
            continue
        group, field_ = target.split(".", 1)
        val = row.get(header)
        if val is None or (isinstance(val, str) and not val.strip()):
            continue
        out.setdefault(group, {})[field_] = val.strip() if isinstance(val, str) else val
    return out
