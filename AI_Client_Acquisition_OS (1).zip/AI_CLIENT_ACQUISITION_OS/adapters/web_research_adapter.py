"""Web research source.

Fetches a company's OWN public website pages (homepage + about/careers/contact-type pages), respecting
robots.txt, and extracts only what is literally on those pages: description, published contact mailboxes,
technology mentions and evidence-backed signals. Every finding carries its source URL and a verbatim excerpt.
It does not search the web for prospects (add a search/registry adapter for that — see adapters/future).
"""
from __future__ import annotations

import ipaddress
import re
import socket
import time
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any, Optional
from urllib import robotparser
from urllib.parse import urljoin, urlparse

import httpx

from adapters.base import BaseLeadSource, LeadRecord, SourceError
from config import config
from core.utils import normalize_domain, sanitize_url
from engines.signal_engine import SignalCandidate, detect_signals_in_text

MAX_BYTES = 1_500_000
PAGE_HINTS = ["career", "jobs", "join", "hiring", "kariera", "praca", "rekrutacja", "about", "company", "team", "leadership",
              "contact", "kontakt", "services", "news", "press", "blog", "o-nas"]
TECHNOLOGIES = {
    "QuickBooks": r"\bquick\s?books(?: online| desktop)?\b|\bQBO\b", "Xero": r"\bxero\b", "NetSuite": r"\bnet\s?suite\b",
    "Sage": r"\bsage (?:intacct|50|100|300)\b|\bsage\b", "SAP": r"\bSAP (?:business one|s/4hana|erp)\b",
    "Microsoft Dynamics": r"\bdynamics 365\b|\bbusiness central\b", "Odoo": r"\bodoo\b",
    "Samsara": r"\bsamsara\b", "Motive": r"\bmotive (?:eld|fleet)\b|\bkeeptruckin\b", "McLeod": r"\bmcleod\b",
    "Salesforce": r"\bsalesforce\b", "HubSpot": r"\bhubspot\b", "Bill.com": r"\bbill\.com\b", "Gusto": r"\bgusto\b",
    "Comarch": r"\bcomarch\b", "Symfonia": r"\bsymfonia\b", "enova": r"\benova365\b|\benova\b",
}
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PHONE_RE = re.compile(r"tel:([+\d][\d\s().-]{6,})", re.I)
_GENERIC_MAILBOX = ("info", "contact", "sales", "office", "hello", "support", "admin", "kontakt", "biuro", "hr", "jobs", "careers")
_BLOCK = {"p", "div", "li", "br", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "section", "article", "ul", "ol", "table", "header", "footer"}
_SKIP = {"script", "style", "noscript", "svg", "template"}


class WebResearchError(SourceError):
    pass


class _Page(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title, self.meta, self.site_name = "", "", ""
        self.chunks: list[str] = []
        self.links: list[tuple[str, str]] = []
        self.mailtos: list[str] = []
        self.tels: list[str] = []
        self._skip = 0
        self._in_title = False
        self._a_href: Optional[str] = None
        self._a_text: list[str] = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "title":
            self._in_title = True
        elif tag == "meta":
            n = (a.get("name") or a.get("property") or "").lower()
            if n in ("description", "og:description") and not self.meta:
                self.meta = (a.get("content") or "").strip()
            if n == "og:site_name":
                self.site_name = (a.get("content") or "").strip()
        elif tag in _SKIP:
            self._skip += 1
        elif tag == "a":
            self._a_href, self._a_text = a.get("href"), []
            href = a.get("href") or ""
            if href.lower().startswith("mailto:"):
                self.mailtos.append(href[7:].split("?")[0].strip())
            elif href.lower().startswith("tel:"):
                self.tels.append(href[4:].strip())
        if tag in _BLOCK:
            self.chunks.append("\n")

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        elif tag in _SKIP and self._skip:
            self._skip -= 1
        elif tag == "a" and self._a_href:
            self.links.append((self._a_href, " ".join(self._a_text).strip()))
            self._a_href = None
        if tag in _BLOCK:
            self.chunks.append("\n")

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        elif not self._skip:
            self.chunks.append(data)
            if self._a_href is not None:
                self._a_text.append(data.strip())

    @property
    def text(self) -> str:
        raw = "".join(self.chunks)
        lines = [re.sub(r"[ \t\r\f\v]+", " ", ln).strip() for ln in raw.split("\n")]
        return "\n".join(ln for ln in lines if ln)


@dataclass
class ResearchFindings:
    website: str
    pages: list[dict] = field(default_factory=list)
    title: str = ""
    site_name: str = ""
    description: str = ""
    emails: list[dict] = field(default_factory=list)
    phones: list[dict] = field(default_factory=list)
    technologies: list[dict] = field(default_factory=list)
    signals: list[SignalCandidate] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    texts: dict = field(default_factory=dict)          # url -> text (used to re-verify evidence)


class WebResearchSource(BaseLeadSource):
    name = "web_research"
    description = "Read a company's own public website pages for description, contacts, technology and signals (with evidence)."

    def __init__(self, client: Optional[httpx.Client] = None, *, max_pages: int = 6, allow_private: Optional[bool] = None,
                 delay: float = 0.3):
        self._client = client
        self.max_pages = max(1, max_pages)
        self.allow_private = config.allow_private_urls if allow_private is None else allow_private
        self.delay = delay

    # --------------------------------------------------------------- safety
    def _check_url(self, url: str) -> str:
        clean = sanitize_url(url)
        if not clean:
            raise WebResearchError("Invalid website URL", f"'{url}' is not a valid http(s) URL.", "Enter a full address like https://example.com")
        host = urlparse(clean).hostname or ""
        if not self.allow_private:
            try:
                infos = socket.getaddrinfo(host, None)
            except socket.gaierror:
                raise WebResearchError(f"Cannot resolve {host}", "DNS lookup failed.", "Check the address and your internet connection.")
            for info in infos:
                ip = ipaddress.ip_address(info[4][0])
                if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
                    raise WebResearchError("Blocked: address resolves to a private network", f"{host} → {ip}",
                                           "Only public websites are fetched (set ALLOW_PRIVATE_URLS=true in .env to override).")
        return clean

    def _get(self, client: httpx.Client, url: str, hops: int = 3) -> httpx.Response:
        current = self._check_url(url)
        for _ in range(hops + 1):
            r = client.get(current, headers={"User-Agent": config.user_agent, "Accept": "text/html,*/*;q=0.5"}, follow_redirects=False)
            if r.is_redirect and r.headers.get("location"):
                current = self._check_url(urljoin(current, r.headers["location"]))
                continue
            return r
        raise WebResearchError("Too many redirects", url)

    def _robots(self, client: httpx.Client, origin: str) -> robotparser.RobotFileParser:
        rp = robotparser.RobotFileParser()
        try:
            r = self._get(client, origin + "/robots.txt")
            if r.status_code == 200:
                rp.parse(r.text.splitlines())
            else:
                rp.parse([])
        except (httpx.HTTPError, WebResearchError):
            rp.parse([])
        return rp

    # ------------------------------------------------------------- research
    def research(self, website: str) -> ResearchFindings:
        website = self._check_url(website)
        findings = ResearchFindings(website=website)
        own = self._client is None
        client = self._client or httpx.Client(timeout=config.http_timeout)
        try:
            p = urlparse(website)
            origin = f"{p.scheme}://{p.netloc}"
            robots = self._robots(client, origin)
            queue, seen = [website], set()
            while queue and len(seen) < self.max_pages:
                url = queue.pop(0)
                key = url.split("#")[0].rstrip("/")
                if key in seen:
                    continue
                seen.add(key)
                if not robots.can_fetch(config.user_agent, url):
                    findings.errors.append(f"robots.txt disallows {url}")
                    continue
                try:
                    r = self._get(client, url)
                except (httpx.HTTPError, WebResearchError) as exc:
                    findings.errors.append(f"{url}: {str(exc)[:120]}")
                    continue
                ctype = r.headers.get("content-type", "")
                if r.status_code != 200 or "html" not in ctype.lower():
                    findings.pages.append({"url": url, "status": r.status_code, "used": False})
                    continue
                html = r.text[:MAX_BYTES]
                page = _Page()
                try:
                    page.feed(html)
                except Exception as exc:       # noqa: BLE001 - malformed HTML must not stop research
                    findings.errors.append(f"{url}: could not parse HTML ({exc.__class__.__name__})")
                    continue
                self._absorb(findings, url, page)
                if len(seen) == 1:               # homepage: discover the useful subpages
                    queue.extend(self._pick_links(page, url, p.netloc))
                if self.delay and queue:
                    time.sleep(self.delay)
        finally:
            if own:
                client.close()
        return findings

    def _pick_links(self, page: _Page, base: str, netloc: str) -> list[str]:
        scored: list[tuple[int, str]] = []
        for href, text in page.links:
            if not href or href.startswith(("#", "mailto:", "tel:", "javascript:")):
                continue
            u = urljoin(base, href)
            pu = urlparse(u)
            if pu.netloc.replace("www.", "") != netloc.replace("www.", "") or pu.scheme not in ("http", "https"):
                continue
            hay = (pu.path + " " + text).lower()
            for rank, hint in enumerate(PAGE_HINTS):
                if hint in hay:
                    scored.append((rank, u.split("#")[0]))
                    break
        scored.sort(key=lambda x: x[0])
        out, seen = [], set()
        for _, u in scored:
            if u not in seen:
                seen.add(u)
                out.append(u)
        return out

    def _absorb(self, f: ResearchFindings, url: str, page: _Page) -> None:
        text = page.text
        f.texts[url] = text
        f.pages.append({"url": url, "status": 200, "used": True, "title": page.title.strip()[:160]})
        if not f.title:
            f.title, f.site_name = page.title.strip(), page.site_name
        if not f.description and page.meta:
            f.description = page.meta[:600]
        for m in set(page.mailtos) | set(_EMAIL_RE.findall(text)):
            addr = m.strip().lower()
            if not _EMAIL_RE.fullmatch(addr) or addr.endswith((".png", ".jpg", ".gif", ".svg", ".webp")):
                continue
            if not any(e["email"] == addr for e in f.emails):
                f.emails.append({"email": addr, "source_url": url, "generic": addr.split("@")[0] in _GENERIC_MAILBOX})
        for t in page.tels:
            t = t.strip()
            if t and not any(x["phone"] == t for x in f.phones):
                f.phones.append({"phone": t, "source_url": url})
        for tech, rx in TECHNOLOGIES.items():
            m = re.search(rx, text, re.I)
            if m and not any(t["name"] == tech for t in f.technologies):
                start = max(text.rfind("\n", 0, m.start()), 0)
                end = text.find("\n", m.end())
                excerpt = re.sub(r"\s+", " ", text[start:end if end > 0 else len(text)]).strip()[:300]
                f.technologies.append({"name": tech, "evidence_text": excerpt, "source_url": url})
        existing = {c.signal_type for c in f.signals}
        for c in detect_signals_in_text(text, url):
            if c.signal_type not in existing:
                f.signals.append(c)
                existing.add(c.signal_type)

    # ------------------------------------------------- BaseLeadSource API
    def fetch(self, *, urls: Optional[list[str]] = None, **_: Any) -> list[LeadRecord]:
        """Turn a list of company websites into lead records (company name is derived from the page title —
        flagged for review). Unknown facts stay empty; nothing is invented."""
        records: list[LeadRecord] = []
        for url in urls or []:
            rec = LeadRecord(source=f"Web research: {url}", source_url=url)
            try:
                f = self.research(url)
            except SourceError as exc:
                rec.errors.append(f"{url}: {exc}")
                records.append(rec)
                continue
            name = (f.site_name or re.split(r"\s[\|\-–—:]\s", f.title)[0] or "").strip()
            if not name:
                rec.errors.append(f"{url}: no company name found on the page")
                records.append(rec)
                continue
            rec.company = {"name": name, "website": f.website, "description": f.description or None,
                           "source": rec.source, "source_url": f.website,
                           "notes": "Company name was derived from the website title — verify before outreach."}
            generic = next((e for e in f.emails if e["generic"]), None) or (f.emails[0] if f.emails else None)
            if generic:
                rec.company["email"] = generic["email"]
            if f.phones:
                rec.company["phone"] = f.phones[0]["phone"]
            techs = [t["name"] for t in f.technologies]
            if techs:
                rec.company["technology_stack"] = techs
            rec.signals = [{"type": c.signal_type, "evidence_text": c.evidence_text, "source": "Company website",
                            "source_url": c.source_url, "confidence": c.confidence, "kind": c.kind, "verified": True,
                            "origin": "web_research"} for c in f.signals]
            records.append(rec)
        return records
