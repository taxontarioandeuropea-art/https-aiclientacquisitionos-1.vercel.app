"""XLSX reader (openpyxl, read-only, values not formulas)."""
from __future__ import annotations

import io
import zipfile
from typing import Any

from adapters.base import SourceError
from adapters.csv_adapter import MAX_COLS, MAX_ROWS, TabularLeadSource, _limits


class ExcelLeadSource(TabularLeadSource):
    name = "xlsx"
    description = "Import leads from an Excel .xlsx file (first sheet, auto-mapped columns)."

    def read_table(self, content: bytes) -> tuple[list[str], list[dict[str, Any]]]:
        _limits(content)
        if not zipfile.is_zipfile(io.BytesIO(content)):
            raise SourceError("This is not a valid .xlsx file", "The file is not an Open XML workbook.",
                              "Re-save it from Excel as .xlsx (legacy .xls is not supported), or export CSV.")
        from openpyxl import load_workbook
        try:
            wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        except Exception as exc:               # noqa: BLE001 - openpyxl raises many types
            raise SourceError("The workbook could not be read", str(exc)[:160], "Check the file is not corrupted or password-protected.")
        ws = wb.worksheets[0]
        it = ws.iter_rows(values_only=True)
        headers: list[str] = []
        for row in it:
            if row and any(c is not None and str(c).strip() for c in row):
                headers = [str(c).strip() if c is not None else "" for c in row]
                break
        if not headers:
            raise SourceError("The sheet has no header row", "The first sheet is empty.", "Add a header row with column names.")
        if len(headers) > MAX_COLS:
            raise SourceError("Too many columns", f"{len(headers)} columns found.", "Remove unused columns.")
        rows = []
        for r in it:
            if not r or not any(c is not None and str(c).strip() for c in r):
                continue
            rows.append({h: (r[j] if j < len(r) and r[j] is not None else "") for j, h in enumerate(headers) if h})
            if len(rows) > MAX_ROWS:
                raise SourceError(f"More than {MAX_ROWS} rows", "File too large for one import.", "Split the workbook.")
        wb.close()
        return headers, rows
