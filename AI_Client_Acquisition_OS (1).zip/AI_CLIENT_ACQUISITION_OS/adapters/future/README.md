# Future lead-source and integration adapters

Implement `adapters.base.BaseLeadSource.fetch()` returning `LeadRecord`s and register the class in
`engines/lead_hunter.py::SOURCES`. Nothing here is implemented in V1 — no fake integrations.

TODO candidates (each needs its own credentials/terms review):
- Search-engine / company-database API (prospect discovery by ICP)
- Job-board adapter (hiring signals with the posting URL as evidence)
- Public registries (KRS/CEIDG in Poland, state registries in the USA)
- LinkedIn-compatible workflows (user-exported lists only; no scraping)
- CRM exports (HubSpot, Pipedrive, Salesforce), Google / Microsoft contacts
- Accounting software / QBO / ERP read-only connectors, Power BI export
