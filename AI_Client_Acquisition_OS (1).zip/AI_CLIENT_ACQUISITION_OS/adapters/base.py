"""Lead-source abstraction. The core never depends on one source: every source returns LeadRecords,
which the ingestion pipeline turns into companies / contacts / leads (with deduplication)."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class LeadRecord:
    company: dict[str, Any] = field(default_factory=dict)
    person: dict[str, Any] = field(default_factory=dict)
    signals: list[dict[str, Any]] = field(default_factory=list)     # each: type, evidence_text, source, source_url ...
    source: str = "Unknown source"
    source_url: Optional[str] = None
    row: Optional[int] = None
    errors: list[str] = field(default_factory=list)


class BaseLeadSource(ABC):
    """Implement `fetch` to add a new source (job boards, registries, LinkedIn-compatible exports, CRM ...)."""
    name = "base"
    description = ""

    @abstractmethod
    def fetch(self, **params: Any) -> list[LeadRecord]:
        """Return normalised lead records. Must never fabricate data: unknown values stay empty."""

    def describe(self) -> dict:
        return {"name": self.name, "description": self.description}


class SourceError(Exception):
    """Raised by adapters with a user-presentable message."""
    def __init__(self, message: str, cause: str = "", suggestion: str = ""):
        super().__init__(message)
        self.cause, self.suggestion = cause, suggestion
