"""CSV / XLSX readers implementing BaseLeadSource. Uploads are validated (type, size, content) before parsing."""
from __future__ import annotations

import csv
import io
from typing import Any, Optional

from adapters.base import BaseLeadSource, LeadRecord, SourceError
from adapters.mapping import apply_mapping, auto_map
from config import config

MAX_ROWS = 20000
MAX_COLS = 120


def _limits(content: bytes) -> None:
    if not content:
        raise SourceError("The file is empty", "Nothing was uploaded.", "Choose a CSV or XLSX file with a header row.")
    if len(content) > config.max_upload_mb * 1024 * 1024:
        raise SourceError(f"The file is larger than {config.max_upload_mb} MB", "Upload size limit exceeded.",
                          "Split the file or raise MAX_UPLOAD_MB in .env.")


def decode_csv_bytes(content: bytes) -> str:
    if b"\x00" in content[:4096]:
        raise SourceError("This does not look like a CSV text file", "Binary content (NUL bytes) was detected.",
                          "If it is an Excel file, save it with the .xlsx extension.")
    for enc in ("utf-8-sig", "cp1250", "cp1252", "latin-1"):
        try:
            return content.decode(enc)
        except UnicodeDecodeError:
            continue
    raise SourceError("Cannot decode the CSV file", "Unknown text encoding.", "Save the file as UTF-8 CSV.")


class TabularLeadSource(BaseLeadSource):
    """Shared behaviour: read a table, auto-map columns, emit LeadRecords."""

    def read_table(self, content: bytes) -> tuple[list[str], list[dict[str, Any]]]:
        raise NotImplementedError

    def fetch(self, *, content: bytes = b"", mapping: Optional[dict[str, str]] = None, kind: str = "leads",
              label: str = "file", **_: Any) -> list[LeadRecord]:
        headers, rows = self.read_table(content)
        mapping = mapping or auto_map(headers, kind)
        records = []
        for i, row in enumerate(rows, start=2):                 # row 1 is the header
            parts = apply_mapping(row, mapping)
            rec = LeadRecord(company=parts.get("company", {}), person=parts.get("person", {}),
                             source=f"{self.name.upper()} import: {label}", row=i)
            rec.company.setdefault("source", rec.source)
            rec.person.setdefault("source", rec.source)
            if "lead" in parts:
                rec.company["_lead"] = parts["lead"]
            records.append(rec)
        return records


class CSVLeadSource(TabularLeadSource):
    name = "csv"
    description = "Import leads from a CSV file (auto-mapped columns)."

    def read_table(self, content: bytes) -> tuple[list[str], list[dict[str, Any]]]:
        _limits(content)
        text = decode_csv_bytes(content)
        try:
            dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        reader = csv.reader(io.StringIO(text), dialect)
        try:
            headers = [h.strip() for h in next(reader)]
        except StopIteration:
            raise SourceError("The CSV has no header row", "The first line is empty.", "Add a header row with column names.")
        if len(headers) > MAX_COLS:
            raise SourceError("Too many columns", f"{len(headers)} columns found (max {MAX_COLS}).", "Remove unused columns.")
        rows = []
        for r in reader:
            if not any((c or "").strip() for c in r):
                continue
            rows.append({h: (r[j].strip() if j < len(r) else "") for j, h in enumerate(headers)})
            if len(rows) > MAX_ROWS:
                raise SourceError(f"More than {MAX_ROWS} rows", "File too large for one import.", "Split the file.")
        return headers, rows
