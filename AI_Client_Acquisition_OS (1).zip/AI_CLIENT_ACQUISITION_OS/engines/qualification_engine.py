"""Qualification engine.

Five separate dimensions instead of one opaque score:
  FIT, NEED, BUYING SIGNAL, ABILITY TO PAY, CONTACTABILITY.
Every dimension returns a level, a 0-100 score and a list of reasons. Each reason is tagged FACT
(taken from a stored record/signal) or INFERENCE (a stated assumption). Nothing is guessed silently:
missing data produces an UNKNOWN/LOW result and a listed data gap.
"""
from __future__ import annotations

from datetime import date
from typing import Any, Optional

from sqlalchemy.orm import Session

from core import audit
from core.constants import FACT, INFERENCE, LEVEL_RANK
from core.errors import NotFound
from core.settings_store import get_settings
from core.utils import classify_title, norm_country, today as _today, utcnow
from database.models import Campaign, Company, Lead, Person, Signal
from engines.signal_engine import (catalog_entry, noisy_or, rank_signals, recency_factor, signal_strength)

DIMENSIONS = ["fit", "need", "signal", "ability_to_pay", "contactability"]
DIM_LABELS = {"fit": "Fit", "need": "Need", "signal": "Buying signal",
              "ability_to_pay": "Ability to pay", "contactability": "Contactability"}
DEFAULT_RULES = {
    "weights": {"fit": 0.25, "need": 0.25, "signal": 0.20, "ability_to_pay": 0.15, "contactability": 0.15},
    "high_threshold": 65, "medium_threshold": 35,
    "priority_high_composite": 62, "priority_low_composite": 38,
}
GROWTH_WORDS = ("grow", "expand", "scal", "hiring", "rapid")


def rules_for(campaign: Optional[Campaign]) -> dict:
    rules = {k: (dict(v) if isinstance(v, dict) else v) for k, v in DEFAULT_RULES.items()}
    over = (campaign.qualification_rules if campaign and campaign.qualification_rules else {}) or {}
    for k, v in over.items():
        if k == "weights" and isinstance(v, dict):
            rules["weights"].update({a: float(b) for a, b in v.items() if a in DIMENSIONS})
        elif k in rules:
            rules[k] = v
    return rules


def level_for(score: Optional[float], rules: dict) -> str:
    if score is None:
        return "UNKNOWN"
    if score >= rules["high_threshold"]:
        return "HIGH"
    if score >= rules["medium_threshold"]:
        return "MEDIUM"
    return "LOW"


def _r(kind: str, text: str, effect: str = "positive", **extra: Any) -> dict:
    return {"kind": kind, "text": text, "effect": effect, **extra}


def _haystack(*parts: Optional[str]) -> str:
    return " ".join(p for p in parts if p).lower()


def _split_terms(target: str) -> list[str]:
    import re
    return [t.strip().lower() for t in re.split(r"[/,;|]", target) if t.strip()]


# ------------------------------------------------------------------ FIT
def _range_result(value: Optional[float], lo: Optional[float], hi: Optional[float]) -> str:
    if value is None:
        return "unknown"
    if (lo is None or value >= lo) and (hi is None or value <= hi):
        return "match"
    if (lo is not None and value < lo and value >= lo * 0.5) or (hi is not None and value > hi and value <= hi * 1.5):
        return "partial"
    return "miss"


def _fit(company: Company, campaign: Optional[Campaign], markets: dict, rules: dict) -> dict:
    criteria: list[tuple[str, float, str, str, str]] = []      # (name, weight, result, kind, text)

    def add(name, weight, result, text, kind=FACT):
        criteria.append((name, weight, result, kind, text))

    if campaign:
        c_country, c_industry = campaign.country, campaign.industry
        emin, emax = campaign.target_employees_min, campaign.target_employees_max
        rmin, rmax = campaign.target_revenue_min, campaign.target_revenue_max
        tech, ownership, geo = campaign.target_technology or [], campaign.target_ownership, campaign.target_geography
        c_sub = campaign.subindustry
    else:
        cs = markets.get("company_size") or {}
        rv = markets.get("revenue") or {}
        c_country = None
        countries = markets.get("countries") or []
        c_industry = ", ".join(markets.get("industries") or []) or None
        emin, emax, rmin, rmax = cs.get("min"), cs.get("max"), rv.get("min"), rv.get("max")
        tech, ownership, geo, c_sub = markets.get("technology") or [], ", ".join(markets.get("ownership") or []) or None, None, None
        if countries:
            c_country = None
            cc = norm_country(company.country)
            if not cc:
                add("country", 25, "unknown", "Country is unknown", FACT)
            elif cc in [norm_country(x) for x in countries]:
                add("country", 25, "match", f"Country {cc} is in your target markets")
            else:
                add("country", 25, "miss", f"Country {cc} is outside your target markets ({', '.join(countries)})")

    if c_country:
        cc, tc = norm_country(company.country), norm_country(c_country)
        if not cc:
            add("country", 25, "unknown", "Company country is unknown")
        elif cc == tc:
            add("country", 25, "match", f"Country matches campaign target ({tc})")
        else:
            add("country", 25, "miss", f"Country {cc} differs from campaign target {tc}")
    if c_industry:
        hay = _haystack(company.industry, company.subindustry, company.description)
        if not (company.industry or company.subindustry):
            add("industry", 25, "unknown", "Company industry is unknown")
        elif any(t in hay or (company.industry or "").lower() in t for t in _split_terms(c_industry) if t):
            extra = ""
            if c_sub and c_sub.lower() in hay:
                extra = f" and sub-industry ({c_sub})"
            add("industry", 25, "match", f"Industry matches target ({company.industry}{extra})")
        else:
            add("industry", 25, "miss", f"Industry '{company.industry}' differs from target '{c_industry}'")
    if emin is not None or emax is not None:
        res = _range_result(company.employees, emin, emax)
        span = f"{emin or 0}-{emax or '∞'}"
        txt = {"match": f"{company.employees} employees is within the target range ({span})",
               "partial": f"{company.employees} employees is close to the target range ({span})",
               "miss": f"{company.employees} employees is outside the target range ({span})",
               "unknown": "Employee count is unknown"}[res]
        add("size", 25, res, txt)
    if rmin is not None or rmax is not None:
        res = _range_result(company.estimated_revenue, rmin, rmax)
        txt = {"match": "Estimated revenue is within the target range", "partial": "Estimated revenue is close to the target range",
               "miss": "Estimated revenue is outside the target range", "unknown": "Revenue is unknown"}[res]
        add("revenue", 10, res, txt)
    if tech:
        hay = _haystack(company.accounting_software, " ".join(company.technology_stack or []))
        hits = [t for t in tech if t.lower() in hay]
        if not hay.strip():
            add("technology", 15, "unknown", "Technology stack / accounting software is unknown")
        elif hits:
            add("technology", 15, "match", f"Uses target technology: {', '.join(hits)}")
        else:
            add("technology", 15, "miss", f"No target technology detected ({', '.join(tech)})")
    if ownership:
        if not company.ownership_type:
            add("ownership", 10, "unknown", "Ownership type is unknown")
        elif ownership.lower() in company.ownership_type.lower() or company.ownership_type.lower() in ownership.lower():
            add("ownership", 10, "match", f"Ownership matches target ({company.ownership_type})")
        else:
            add("ownership", 10, "miss", f"Ownership '{company.ownership_type}' differs from target '{ownership}'")
    if geo:
        hay = _haystack(company.state, company.city, company.address, company.country)
        if not hay.strip():
            add("geography", 5, "unknown", "Location is unknown")
        elif any(t in hay for t in _split_terms(geo)):
            add("geography", 5, "match", f"Located in target geography ({geo})")
        else:
            add("geography", 5, "miss", f"Not in target geography ({geo})")

    if not criteria:
        return {"score": None, "level": "UNKNOWN",
                "reasons": [_r(FACT, "No ICP criteria are defined for this campaign or in Settings → Markets", "unknown")],
                "gaps": ["Define ICP criteria (country, industry, size ...) on the campaign"]}
    total_w = sum(w for _, w, *_ in criteria)
    earned = sum(w * {"match": 1.0, "partial": 0.5}.get(res, 0.0) for _, w, res, *_ in criteria)
    known = [c for c in criteria if c[2] != "unknown"]
    score = round(100 * earned / total_w) if known else None
    reasons = [_r(kind, text, {"match": "positive", "partial": "neutral", "miss": "negative", "unknown": "unknown"}[res])
               for _, _, res, kind, text in criteria]
    # Core ICP mismatches (country / industry / ownership) cap the score: one miss = at most Medium, two = Low.
    core_misses = [n for n, _, res, *_ in criteria if res == "miss" and n in ("country", "industry", "ownership")]
    if score is not None and core_misses:
        cap = rules["high_threshold"] - 5 if len(core_misses) == 1 else rules["medium_threshold"] - 1
        if score > cap:
            score = cap
            reasons.append(_r(FACT, f"Core ICP mismatch ({', '.join(core_misses)}) — fit is capped at "
                                    f"{'Medium' if len(core_misses) == 1 else 'Low'}", "negative"))
    gaps = [text for _, _, res, _, text in criteria if res == "unknown"]
    return {"score": score, "level": level_for(score, rules), "reasons": reasons, "gaps": gaps}


# ------------------------------------------------------- NEED / SIGNAL
def _signal_dimension(dim: str, signals: list[Signal], company: Company, on: date, rules: dict) -> dict:
    """dim is 'need' or 'signal' (intent)."""
    key = "need" if dim == "need" else "intent"
    contributions: list[tuple[float, Signal]] = [(signal_strength(s, key, on), s) for s in signals]
    contributions = [(v, s) for v, s in contributions if v > 0.02]
    extra: list[float] = []
    reasons: list[dict] = []
    if dim == "need" and company.growth_status and any(w in company.growth_status.lower() for w in GROWTH_WORDS):
        extra.append(0.25)
        reasons.append(_r(FACT, f"Company record lists growth status '{company.growth_status}'", "positive"))
    if not contributions and not extra:
        label = "need" if dim == "need" else "buying intent"
        return {"score": None, "level": "UNKNOWN",
                "reasons": [_r(FACT, f"No evidence of {label} has been recorded yet (not researched, or nothing found)", "unknown")],
                "gaps": ["Run research or add signals with evidence"]}
    score = round(100 * noisy_or([v for v, _ in contributions] + extra))
    for v, s in sorted(contributions, key=lambda x: -x[0])[:5]:
        entry = catalog_entry(s.signal_type)
        age = (on - s.date_detected).days if s.date_detected else None
        when = f", {age} days ago" if age is not None else ""
        note = " (older evidence, weight reduced)" if dim == "signal" and age is not None and age > 90 else ""
        reasons.append(_r(s.kind or FACT, f"{entry['label']} — “{s.evidence_text[:160]}” [{s.source}{when}]{note}",
                          "positive", signal_id=s.id))
    return {"score": score, "level": level_for(score, rules), "reasons": reasons, "gaps": []}


# ------------------------------------------------------ ABILITY TO PAY
GROWTH_TYPES = {"funding", "new_contracts", "acquisition", "rapid_growth", "expansion", "new_location"}


def _ability(company: Company, campaign: Optional[Campaign], signals: list[Signal], settings: dict, rules: dict) -> dict:
    pricing, heur = settings["pricing"], settings["heuristics"]
    min_mrr = (campaign.minimum_mrr if campaign and campaign.minimum_mrr else None) or pricing.get("minimum_mrr") or 700
    spend_pct = (rules.get("finance_spend_pct") or heur.get("finance_spend_pct") or 0.007)
    rev_per_emp = (rules.get("revenue_per_employee") or heur.get("revenue_per_employee") or 150000)
    reasons: list[dict] = []
    revenue, kind = company.estimated_revenue, FACT
    if revenue is None and company.employees:
        revenue = company.employees * rev_per_emp
        kind = INFERENCE
        reasons.append(_r(INFERENCE, f"Revenue not recorded; assuming ${rev_per_emp:,.0f} per employee × {company.employees} employees "
                                     f"≈ ${revenue:,.0f}/yr (assumption — edit in Settings/campaign rules)", "neutral"))
    if revenue is None:
        return {"score": None, "level": "UNKNOWN",
                "reasons": [_r(FACT, "No revenue, employee count or scale is recorded, so budget cannot be estimated", "unknown")],
                "gaps": ["Add estimated revenue or employee count"]}
    capacity = revenue * spend_pct / 12
    ratio = capacity / float(min_mrr)
    base = 90 if ratio >= 2 else 75 if ratio >= 1.2 else 55 if ratio >= 0.8 else 35 if ratio >= 0.5 else 15
    if kind == INFERENCE:
        base = min(base, 70)
    basis = "revenue" if kind == FACT else "revenue inferred from headcount"
    reasons.append(_r(kind, f"Estimated finance-services budget ≈ ${capacity:,.0f}/month ({spend_pct*100:.1f}% of ${revenue:,.0f}/yr {basis}) "
                            f"vs. minimum ${float(min_mrr):,.0f} MRR" + ("" if kind == FACT else " [inferred]"),
                      "positive" if ratio >= 0.8 else "negative"))
    boosts = [s for s in signals if s.signal_type in GROWTH_TYPES]
    bonus = min(20, 10 * len({s.signal_type for s in boosts}))
    if bonus:
        reasons.append(_r(INFERENCE, "Growth/funding signals suggest available budget: " +
                          ", ".join(sorted({catalog_entry(s.signal_type)['label'] for s in boosts})), "positive"))
    score = min(100, base + bonus)
    return {"score": score, "level": level_for(score, rules), "reasons": reasons, "gaps": []}


# -------------------------------------------------------- CONTACTABILITY
def _contact(person: Optional[Person], campaign: Optional[Campaign], rules: dict) -> dict:
    if not person:
        return {"score": 0, "level": "LOW", "reasons": [_r(FACT, "No decision maker has been identified yet", "negative")],
                "gaps": ["Find and add the decision maker"]}
    level = person.decision_maker_level if person.decision_maker_level not in (None, "", "unknown") else classify_title(person.title)
    base = {"decision_maker": 45, "influencer": 35, "user": 15}.get(level, 10)
    reasons = [_r(FACT, f"{person.full_name or 'Contact'} — {person.title or 'title unknown'} "
                        f"({level.replace('_', ' ')})", "positive" if base >= 35 else "neutral")]
    prefs = [p.lower() for p in ((campaign.preferred_decision_maker if campaign else None) or [])]
    if prefs and person.title and any(p in person.title.lower() for p in prefs):
        base += 10
        reasons.append(_r(FACT, "Title matches the campaign's preferred decision maker", "positive"))
    channels = []
    if person.email:
        base += 30; channels.append("email")
    if person.linkedin_url:
        base += 10; channels.append("LinkedIn")
    if person.phone:
        base += 10; channels.append("phone")
    gaps = []
    if channels:
        reasons.append(_r(FACT, f"Reachable via {', '.join(channels)}", "positive"))
    else:
        reasons.append(_r(FACT, "No email, LinkedIn or phone on file", "negative"))
        gaps.append("Find a way to reach the contact (email / LinkedIn / phone)")
    if person.confidence is not None and person.confidence < 0.5:
        reasons.append(_r(FACT, f"Contact data confidence is low ({person.confidence:.0%}) — verify before outreach", "negative"))
    score = min(100, base)
    return {"score": score, "level": level_for(score, rules), "reasons": reasons, "gaps": gaps}


# ---------------------------------------------------------------- OVERALL
def compute_qualification(company: Company, person: Optional[Person], campaign: Optional[Campaign],
                          signals: list[Signal], *, settings: dict, on: Optional[date] = None) -> dict:
    on = on or _today()
    rules = rules_for(campaign)
    dims = {
        "fit": _fit(company, campaign, settings["markets"], rules),
        "need": _signal_dimension("need", signals, company, on, rules),
        "signal": _signal_dimension("signal", signals, company, on, rules),
        "ability_to_pay": _ability(company, campaign, signals, settings, rules),
        "contactability": _contact(person, campaign, rules),
    }
    w = rules["weights"]
    composite = round(sum(w[d] * (dims[d]["score"] or 0) for d in DIMENSIONS) / sum(w.values()))
    lv = {d: dims[d]["level"] for d in DIMENSIONS}
    fit_ok = LEVEL_RANK[lv["fit"]] >= 3
    strong_evidence = LEVEL_RANK[lv["need"]] >= 3 or LEVEL_RANK[lv["signal"]] >= 3
    if LEVEL_RANK[lv["fit"]] <= 1 and lv["fit"] != "UNKNOWN":
        priority, cause = "LOW", "the company does not match the ICP"
    elif composite >= rules["priority_high_composite"] and fit_ok and strong_evidence:
        priority, cause = "HIGH", "strong fit with strong need or buying-signal evidence"
    elif composite < rules["priority_low_composite"]:
        priority, cause = "LOW", "evidence and fit are too weak so far"
    elif lv["need"] == "UNKNOWN" and lv["signal"] == "UNKNOWN":
        priority, cause = "MEDIUM", "the company matches the ICP but no evidence of need or intent exists yet — research to confirm"
    else:
        priority, cause = "MEDIUM", "partial fit and/or evidence"
    gaps = [g for d in DIMENSIONS for g in dims[d].get("gaps", [])]
    top = rank_signals(signals, on)[:3]
    why_parts: list[str] = []
    if lv["fit"] in ("HIGH", "MEDIUM"):
        ok = [r["text"] for r in dims["fit"]["reasons"] if r["effect"] == "positive"]
        if ok:
            why_parts.append("ICP match — " + "; ".join(ok[:3]) + ".")
    for s in top:
        why_parts.append(f"{catalog_entry(s.signal_type)['label']}: “{s.evidence_text[:140]}” ({s.source}).")
    if lv["ability_to_pay"] in ("HIGH", "MEDIUM"):
        why_parts.append(dims["ability_to_pay"]["reasons"][-1]["text"] + ".")
    if lv["contactability"] in ("HIGH", "MEDIUM"):
        why_parts.append(dims["contactability"]["reasons"][0]["text"] + ".")
    if not why_parts:
        why_parts.append("Not enough evidence yet — research the company and record signals with sources.")
    opportunity = _opportunity_breakdown(dims, w, composite)
    return {
        "dimensions": dims,
        "levels": lv,
        "overall": {"priority": priority, "composite": composite, "cause": cause,
                    "explanation": f"Priority {priority}: {cause}. " + " ".join(why_parts)},
        "opportunity": opportunity,
        "data_gaps": gaps,
        "evidence_signal_ids": [s.id for s in top],
        "rules": {"weights": w, "high_threshold": rules["high_threshold"], "medium_threshold": rules["medium_threshold"]},
        "computed_at": utcnow().isoformat(timespec="seconds"),
    }


def _opportunity_breakdown(dims: dict, weights: dict, composite: int) -> dict:
    """Master prompt §12-14, §29: the Opportunity Score is the same weighted blend already used for
    priority (never a second, different number that would contradict it) — this function only adds the
    point-by-point breakdown so a person can see where the number came from, in the exact style of the
    master prompt's own example ('+18 international operations / +16 recent growth / ... / TOTAL: 91').

    Rounding each dimension's share independently and then summing can land a point or two off the
    already-rounded composite (classic apportionment rounding), which would make the breakdown fail to
    add up to the headline number it's explaining. Largest-remainder apportionment guarantees the parts
    sum to exactly `composite`: floor every share, then hand the few leftover points to the dimensions
    with the largest fractional remainder, one each.
    """
    total_w = sum(weights.values()) or 1
    exact = {d: weights[d] * (dims[d]["score"] or 0) / total_w for d in DIMENSIONS}
    floors = {d: int(exact[d]) for d in DIMENSIONS}
    remainder = composite - sum(floors.values())
    order = sorted(DIMENSIONS, key=lambda d: -(exact[d] - floors[d]))
    for d in order[:max(remainder, 0)]:
        floors[d] += 1
    parts = []
    for d in DIMENSIONS:
        best_reason = next((r["text"] for r in dims[d]["reasons"] if r["effect"] == "positive"), None)
        parts.append({"dimension": d, "label": DIM_LABELS[d], "points": floors[d],
                      "of_score": dims[d]["score"], "weight": weights[d], "reason": best_reason})
    parts.sort(key=lambda p: -p["points"])
    return {"score": composite, "breakdown": parts}


def recommended_next_action(result: dict, lead: Lead) -> str:
    lv = result["levels"]
    if lv["need"] == "UNKNOWN" and lv["signal"] == "UNKNOWN":
        return "Research company"
    if lv["contactability"] == "LOW":
        return "Find decision maker"
    pr = result["overall"]["priority"]
    if pr in ("HIGH", "MEDIUM"):
        return "Send personalized message" if lead.status in ("NEW", "RESEARCHED", "QUALIFIED") else (lead.next_action or "Follow up")
    return "Review fit — consider Nurture or Not a fit"


def suggested_stage(result: dict, lead: Lead) -> Optional[str]:
    """A suggestion only — the user decides."""
    pr, lv = result["overall"]["priority"], result["levels"]
    if lead.status in ("NEW", "RESEARCHED"):
        if pr in ("HIGH", "MEDIUM") and lv["contactability"] != "LOW":
            return "QUALIFIED"
        if pr == "LOW" and lv["fit"] == "LOW":
            return "NOT_A_FIT"
    return None


def _pretty(level: Optional[str]) -> str:
    return (level or "unknown").capitalize()


def qualify_lead(db: Session, lead_id: int | Lead, *, actor: str = "ai", reason: Optional[str] = None) -> dict:
    lead = lead_id if isinstance(lead_id, Lead) else db.get(Lead, lead_id)
    if not lead:
        raise NotFound("Lead", lead_id)
    company = lead.company
    signals = db.query(Signal).filter(Signal.company_id == company.id).all()
    settings = get_settings(db)
    result = compute_qualification(company, lead.person, lead.campaign, signals, settings=settings)
    old = lead.qualification or {}
    old_levels = old.get("levels") or {}
    new_levels = result["levels"]
    changes = {d: (old_levels.get(d), new_levels[d]) for d in DIMENSIONS if old_levels.get(d) != new_levels[d]}
    old_pr = lead.overall_priority
    new_evidence = [s for s in signals if lead.qualified_at and s.created_at and s.created_at > lead.qualified_at]

    lead.fit_score = result["dimensions"]["fit"]["score"]
    lead.need_score = result["dimensions"]["need"]["score"]
    lead.signal_score = result["dimensions"]["signal"]["score"]
    lead.ability_to_pay_score = result["dimensions"]["ability_to_pay"]["score"]
    lead.contactability_score = result["dimensions"]["contactability"]["score"]
    lead.overall_priority = result["overall"]["priority"]
    lead.opportunity_score = result["overall"]["composite"]
    lead.qualification = result
    lead.qualified_at = utcnow()
    ranked = rank_signals(signals)
    lead.primary_signal_type = ranked[0].signal_type if ranked else None
    if lead.status in ("NEW", "RESEARCHED") or not lead.next_action:
        lead.next_action = recommended_next_action(result, lead)
    result["suggested_stage"] = suggested_stage(result, lead)

    if changes or old_pr != lead.overall_priority:
        if new_evidence:
            why = f"New evidence detected ({', '.join(catalog_entry(s.signal_type)['label'] for s in new_evidence[:3])})"
        else:
            why = reason or ("Initial qualification" if not old else "Company, contact or campaign data changed")
        lines = [f"{DIM_LABELS[d]}: {_pretty(a)} → {_pretty(b)}" for d, (a, b) in changes.items()]
        audit.log(db, "qualification_updated",
                  f"{company.name}: priority {_pretty(old_pr)} → {_pretty(lead.overall_priority)}. " + "; ".join(lines),
                  entity_type="lead", entity_id=lead.id, actor=actor,
                  details={"changes": {d: {"from": a, "to": b} for d, (a, b) in changes.items()},
                           "priority": {"from": old_pr, "to": lead.overall_priority}, "reason": why,
                           "composite": result["overall"]["composite"]})
    db.flush()
    return result
