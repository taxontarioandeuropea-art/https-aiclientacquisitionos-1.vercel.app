"""Experiment engine: which ICP + signal + offer + message + channel combinations actually produce
replies, meetings, proposals, clients and MRR? Always shows sample size and never claims statistical proof."""
from __future__ import annotations

from typing import Optional

from sqlalchemy.orm import Session

from core.settings_store import get_settings
from core.utils import pct, wilson_interval
from engines.analytics_engine import IDX, first_message, lead_dimension, load_leads, max_reached

DIMENSIONS = {"campaign": "Campaign / ICP", "industry": "Industry", "country": "Country", "signal": "Signal",
              "offer": "Offer (service)", "template": "Message template", "channel": "Channel"}


def _flag(n: int, min_sample: int) -> str:
    return "insufficient" if n < min_sample else "directional" if n < 100 else "reasonable"


def experiments(db: Session, group_by: Optional[list[str]] = None, campaign_id: Optional[int] = None) -> dict:
    group_by = [g for g in (group_by or ["campaign", "signal", "offer"]) if g in DIMENSIONS] or ["campaign"]
    min_sample = int(get_settings(db, "analytics").get("min_sample_size", 30))
    leads = [l for l in load_leads(db, campaign_id)]
    reached = max_reached(db, leads)
    fm = first_message(db, [l.id for l in leads])
    contacted = [l for l in leads if l.id in fm or reached[l.id] >= IDX["CONTACTED"]]
    msgs_by_lead: dict[int, int] = {}
    from database.models import OutreachMessage
    if contacted:
        for lid, in db.query(OutreachMessage.lead_id).filter(OutreachMessage.lead_id.in_([l.id for l in contacted]),
                                                              OutreachMessage.sent_at.isnot(None)).all():
            msgs_by_lead[lid] = msgs_by_lead.get(lid, 0) + 1

    def blank(key):
        return {"key": key, "n": 0, "messages_sent": 0, "replies": 0, "meetings": 0, "proposals": 0, "won": 0, "mrr": 0.0}
    groups: dict[tuple, dict] = {}
    total = blank(("All contacted leads",))
    for l in contacted:
        key = tuple(lead_dimension(l, d, fm.get(l.id)) or "(unknown)" for d in group_by)
        r = reached[l.id]
        for g in (groups.setdefault(key, blank(key)), total):
            g["n"] += 1
            g["messages_sent"] += msgs_by_lead.get(l.id, 0)
            g["replies"] += int(r >= IDX["REPLIED"]); g["meetings"] += int(r >= IDX["CALL"])
            g["proposals"] += int(r >= IDX["PROPOSAL"]); g["won"] += int(l.status == "WON")
            g["mrr"] += (l.actual_mrr or 0) if l.status == "WON" else 0
    base_rate = (total["replies"] / total["n"]) if total["n"] else 0.0
    rows = []
    for g in groups.values():
        lo, hi = wilson_interval(g["replies"], g["n"])
        flag = _flag(g["n"], min_sample)
        if flag == "insufficient":
            verdict = f"Only {g['n']} contacted lead(s) — too few to conclude anything (minimum {min_sample})."
        elif lo > base_rate:
            verdict = "Reply rate looks higher than your average and the range clears it — worth repeating, not proof."
        elif hi < base_rate:
            verdict = "Reply rate looks lower than your average and the range stays below it — consider changing this approach."
        else:
            verdict = "No reliable difference from your average yet."
        rows.append({**g, "key": list(g["key"]), "label": " + ".join(g["key"]), "reply_rate": pct(g["replies"], g["n"]),
                     "reply_ci": [round(lo * 100, 1), round(hi * 100, 1)], "meeting_rate": pct(g["meetings"], g["n"]),
                     "close_rate": pct(g["won"], g["n"]), "sample": flag, "verdict": verdict})
    rows.sort(key=lambda r: (-r["mrr"], -r["won"], -r["replies"], -r["n"]))
    lo, hi = wilson_interval(total["replies"], total["n"])
    return {"group_by": group_by, "dimensions": DIMENSIONS, "min_sample": min_sample, "rows": rows,
            "baseline": {**total, "key": list(total["key"]), "reply_rate": pct(total["replies"], total["n"]),
                         "reply_ci": [round(lo * 100, 1), round(hi * 100, 1)]},
            "caveat": ("Patterns are descriptive. Small samples are noisy: results below the minimum sample size are flagged "
                       "'insufficient', and none of these figures is presented as statistically proven.")}
