"""Signal engine.

A signal is only ever created from (a) something the user enters together with evidence, or
(b) text that was actually fetched from a source, where the evidence sentence is copied verbatim
from that text and re-verified. The engine cannot "invent" a signal: evidence and source are mandatory.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import Iterable, Optional

from sqlalchemy.orm import Session

from core import audit
from core.constants import FACT, INFERENCE
from core.errors import NotFound, ValidationProblem
from core.utils import sanitize_text, sanitize_url, today as _today
from database.models import Company, Signal


def _e(label, category, need, intent, observation, implication, problem, kind=FACT):
    return dict(label=label, category=category, need=need, intent=intent, observation=observation,
                implication=implication, problem=problem, kind=kind)


# need / intent are transparent weights (0-100) used by the qualification engine; edit freely.
SIGNAL_CATALOG: dict[str, dict] = {
    "hiring_accountant": _e("Hiring an accountant", "hiring", 65, 85, "is hiring an accountant",
        "month-end close, reconciliations and reporting as the team's capacity gets stretched",
        "Accounting workload appears to be outgrowing current capacity"),
    "hiring_controller": _e("Hiring a controller", "hiring", 75, 85, "is hiring a controller",
        "financial reporting, month-end close and internal controls",
        "Finance leadership and close discipline are being added"),
    "hiring_finance_manager": _e("Hiring a finance manager", "hiring", 70, 85, "is hiring a finance manager",
        "management reporting, budgeting and cash visibility",
        "Management reporting capacity is being built"),
    "hiring_bookkeeper": _e("Hiring a bookkeeper", "hiring", 60, 80, "is hiring a bookkeeper",
        "day-to-day bookkeeping keeping up with transaction volume",
        "Bookkeeping volume is outgrowing current capacity"),
    "searching_qbo_support": _e("Searching for QuickBooks support", "intent", 80, 95, "is looking for QuickBooks support",
        "books that need cleanup or dependable ongoing oversight",
        "The QuickBooks file needs expert attention"),
    "accounting_vacancy": _e("Accounting vacancy", "hiring", 60, 75, "has an open accounting-related vacancy",
        "payables/receivables throughput and close timelines",
        "Accounting operations are short-staffed"),
    "financial_reporting_vacancy": _e("Financial reporting vacancy", "hiring", 65, 75, "is recruiting for a financial reporting role",
        "the quality and timeliness of financial reporting",
        "Financial reporting is a recognised gap"),
    "rapid_growth": _e("Rapid growth", "growth", 60, 40, "is growing quickly",
        "financial controls and reporting keeping pace with growth",
        "Growth is putting pressure on finance processes"),
    "new_location": _e("New location", "growth", 50, 50, "is opening a new location",
        "multi-location reporting and consolidation",
        "More locations increase reporting complexity"),
    "new_entity": _e("New legal entity", "structure", 65, 55, "has set up a new legal entity",
        "separate books, intercompany entries and consolidated reporting",
        "A new entity needs its own books and consolidation"),
    "acquisition": _e("Acquisition", "growth", 70, 65, "has made an acquisition",
        "integrating acquired books, consolidation and reliable reporting",
        "Acquired operations must be integrated into the books"),
    "funding": _e("Funding", "growth", 55, 60, "has secured new funding",
        "investor-grade reporting and tighter financial controls",
        "New capital raises reporting expectations"),
    "new_contracts": _e("New contracts", "growth", 45, 45, "has announced new contracts",
        "billing, cash-flow tracking and profitability by customer or lane",
        "New volume increases billing and cash-flow complexity"),
    "expansion": _e("Expansion", "growth", 55, 50, "is expanding its operations",
        "month-end close, reconciliations and management reporting",
        "Expansion is adding operational and reporting load"),
    "multiple_entities": _e("Multiple entities", "structure", 65, 20, "operates multiple entities",
        "intercompany accounting and consolidated reporting",
        "Multiple entities make consolidated reporting harder"),
    "operational_complexity": _e("Operational complexity", "structure", 55, 20, "runs increasingly complex operations",
        "cost tracking and reporting across the operation",
        "Operational complexity strains standard bookkeeping", INFERENCE),
    "technology_migration": _e("Technology migration", "technology", 55, 60, "is migrating technology systems",
        "data migration, chart-of-accounts mapping and integrations",
        "A systems change puts data quality at risk"),
    "erp_migration": _e("ERP migration", "technology", 70, 75, "is implementing or migrating an ERP",
        "data migration, controls and reporting during the ERP transition",
        "An ERP transition needs finance-side ownership"),
    "accounting_software_implementation": _e("Accounting software implementation", "technology", 70, 80,
        "is implementing new accounting software",
        "chart-of-accounts design, data migration and process set-up",
        "A new accounting system needs correct set-up and migration"),
    "public_accounting_problem": _e("Publicly visible accounting problem", "problem", 85, 65,
        "has had a publicly visible accounting or reporting issue",
        "restatements, reconciliations and stronger review controls",
        "There is public evidence of accounting/reporting weakness"),
    "automation_need": _e("Automation need", "problem", 55, 50, "appears to rely on manual finance processes",
        "repetitive data entry and reconciliation work that can be automated",
        "Manual finance processes are consuming time", INFERENCE),
    "financial_reporting_need": _e("Financial reporting need", "problem", 65, 45, "appears to need stronger financial reporting",
        "reporting that management can rely on for decisions",
        "Management reporting appears weak or missing", INFERENCE),
    "controller_cfo_need": _e("Controller / CFO support need", "problem", 70, 50,
        "may need controller- or CFO-level oversight",
        "finance leadership without the cost of a full-time hire",
        "Finance leadership appears to be missing", INFERENCE),
    "uses_quickbooks": _e("Uses QuickBooks", "technology", 30, 5, "appears to use QuickBooks",
        "how well the QuickBooks file is kept and closed each month",
        "QuickBooks is in use; quality of the file is unknown", INFERENCE),
}

_DEFAULT_ENTRY = dict(label="Custom signal", category="custom", need=35, intent=35,
                      observation="has a signal worth noting", implication="its finance and reporting requirements",
                      problem="A custom signal was recorded", kind=INFERENCE)


def catalog_entry(signal_type: str) -> dict:
    entry = SIGNAL_CATALOG.get(signal_type)
    if entry:
        return entry
    e = dict(_DEFAULT_ENTRY)
    e["label"] = signal_type.replace("_", " ").strip().capitalize()
    return e


def catalog_public() -> list[dict]:
    return [{"type": k, "label": v["label"], "category": v["category"], "kind": v["kind"],
             "need": v["need"], "intent": v["intent"]} for k, v in SIGNAL_CATALOG.items()]


# ------------------------------------------------------------- weighting
def recency_factor(detected: Optional[date], on: Optional[date] = None) -> float:
    on = on or _today()
    if not detected:
        return 0.5
    age = (on - detected).days
    if age <= 30:
        return 1.0
    if age <= 90:
        return 0.75
    if age <= 180:
        return 0.5
    return 0.3


def signal_strength(sig: Signal, dimension: str, on: Optional[date] = None) -> float:
    """0..1 contribution of one signal to 'need' or 'intent'."""
    entry = catalog_entry(sig.signal_type)
    weight = entry["need"] if dimension == "need" else entry["intent"]
    rec = recency_factor(sig.date_detected, on)
    if dimension == "need":
        rec = max(0.6, rec)         # a need does not disappear as quickly as intent
    return (weight / 100.0) * (sig.confidence if sig.confidence is not None else 0.6) * rec


def noisy_or(values: Iterable[float]) -> float:
    """Combine independent pieces of evidence without ever exceeding 1.0."""
    p = 1.0
    for v in values:
        p *= (1.0 - max(0.0, min(1.0, v)))
    return 1.0 - p


def rank_signals(signals: list[Signal], on: Optional[date] = None) -> list[Signal]:
    return sorted(signals, key=lambda s: max(signal_strength(s, "need", on), signal_strength(s, "intent", on)),
                  reverse=True)


# ---------------------------------------------------------- persistence
def _norm_ws(t: str) -> str:
    return re.sub(r"\s+", " ", t or "").strip().casefold()


def validate_evidence(evidence: str, source_text: str) -> bool:
    """True only if the evidence appears verbatim (whitespace/case-insensitive) in the source text."""
    ev = _norm_ws(evidence)
    return len(ev) >= 8 and ev in _norm_ws(source_text)


def add_signal(db: Session, company_id: int, signal_type: str, evidence_text: str, source: str, *,
               description: Optional[str] = None, source_url: Optional[str] = None, confidence: float = 0.7,
               kind: Optional[str] = None, origin: str = "manual", date_detected: Optional[date] = None,
               verified: bool = False, is_demo: bool = False, actor: str = "user") -> tuple[Signal, bool]:
    """Create a signal. Returns (signal, created). Refuses signals without evidence and source."""
    company = db.get(Company, company_id)
    if not company:
        raise NotFound("Company", company_id)
    signal_type = (sanitize_text(signal_type, 80) or "").strip().lower().replace(" ", "_")
    evidence = sanitize_text(evidence_text, 2000) or ""
    src = sanitize_text(source, 255) or ""
    if not signal_type:
        raise ValidationProblem("Signal type is required", operation="add signal")
    if len(evidence) < 8:
        raise ValidationProblem(
            "A signal needs evidence text", operation="add signal",
            cause="Signals cannot be recorded without the evidence that supports them.",
            suggestion="Paste the sentence or fact you observed (e.g. the job-post wording) and name the source.")
    if not src:
        raise ValidationProblem("A signal needs a source", operation="add signal",
                                cause="Every signal must say where the evidence came from.",
                                suggestion="Enter a source such as 'Company careers page' or 'Phone call'.")
    if not 0.0 <= float(confidence) <= 1.0:
        raise ValidationProblem("Confidence must be between 0 and 1", operation="add signal")
    existing = db.query(Signal).filter(Signal.company_id == company_id, Signal.signal_type == signal_type).all()
    for s in existing:
        if _norm_ws(s.evidence_text) == _norm_ws(evidence):
            return s, False
    entry = catalog_entry(signal_type)
    sig = Signal(company_id=company_id, signal_type=signal_type,
                 description=sanitize_text(description, 500) or entry["label"],
                 source=src, source_url=sanitize_url(source_url), date_detected=date_detected or _today(),
                 confidence=float(confidence), evidence_text=evidence, kind=kind or entry["kind"],
                 origin=origin, verified=verified, is_demo=is_demo)
    db.add(sig)
    db.flush()
    audit.log(db, "signal_added", f"Signal '{entry['label']}' added to {company.name}",
              entity_type="signal", entity_id=sig.id, actor=actor,
              details={"company_id": company_id, "type": signal_type, "source": src, "origin": origin})
    return sig, True


def serialize_signal(s: Signal) -> dict:
    entry = catalog_entry(s.signal_type)
    d = s.as_dict()
    d["label"] = entry["label"]
    d["category"] = entry["category"]
    return d


# ------------------------------------------------------- text detection
_HIRING_CONTEXT = re.compile(
    r"\b(we(?:'| a)re hiring|now hiring|hiring|join our team|open positions?|job (?:opening|description|posting)|"
    r"apply (?:now|today|here)|vacanc\w+|we(?:'| a)re looking for|we are seeking|seeking|position|responsibilities|"
    r"poszukujemy|rekrutacja|oferta pracy|aplikuj|wymagania)\b", re.I)
_CAREERS_URL = re.compile(r"/(careers?|jobs?|join|hiring|kariera|praca|rekrutacja|work-with-us)(/|$|\?|\.)", re.I)

# (type, regex, needs_hiring_context, confidence, kind)
_RULES: list[tuple[str, re.Pattern, bool, float, str]] = [
    ("hiring_controller", re.compile(r"\b(?:financial |finance |assistant )?controller\b|\bkontroler finansowy\b", re.I), True, 0.85, FACT),
    ("hiring_finance_manager", re.compile(r"\b(?:finance|financial|accounting) manager\b|\bdyrektor finansowy\b|\bhead of finance\b", re.I), True, 0.85, FACT),
    ("hiring_bookkeeper", re.compile(r"\bbook-?keeper\b", re.I), True, 0.85, FACT),
    ("hiring_accountant", re.compile(r"\b(?:staff |senior |junior |cost )?accountant\b|\bksięgow\w+|\bksiegow\w+|\bgłówny księgowy\b", re.I), True, 0.85, FACT),
    ("financial_reporting_vacancy", re.compile(r"\bfinancial reporting\b|\bfinancial analyst\b|\bfp&a\b|\breporting analyst\b|\banalityk finansowy\b", re.I), True, 0.75, FACT),
    ("accounting_vacancy", re.compile(r"\baccounts (?:payable|receivable)\b|\bbilling specialist\b|\bpayroll (?:specialist|clerk|administrator)\b", re.I), True, 0.75, FACT),
    ("searching_qbo_support", re.compile(r"\b(?:looking for|need|seeking|hiring)\b[^.]{0,60}\bquick\s?books\b[^.]{0,40}\b(?:support|help|expert|proadvisor|cleanup|clean-up)\b", re.I), False, 0.8, FACT),
    ("uses_quickbooks", re.compile(r"\bquick\s?books(?: online| desktop)?\b|\bQBO\b", re.I), False, 0.55, INFERENCE),
    ("accounting_software_implementation", re.compile(r"\bimplement\w* (?:quickbooks|xero|sage|netsuite|new accounting)\b|\bnew accounting (?:system|software)\b", re.I), False, 0.75, FACT),
    ("erp_migration", re.compile(r"\berp (?:implementation|migration|upgrade|rollout)\b|\bmigrat\w+ to (?:netsuite|sap|dynamics|odoo)\b|\bnew erp\b", re.I), False, 0.75, FACT),
    ("technology_migration", re.compile(r"\bmigrat\w+ to (?:the )?cloud\b|\bdigital transformation\b|\bnew (?:tms|wms|crm) (?:system|platform)\b", re.I), False, 0.6, FACT),
    ("acquisition", re.compile(r"\b(?:acquired|acquisition of|announces? (?:the )?acquisition|merged with|przejęcie|przejęła)\b", re.I), False, 0.7, FACT),
    ("funding", re.compile(r"\braised \$?[\d.,]+ ?(?:m|million|k|thousand)?\b|\bsecured (?:a )?(?:new )?(?:funding|investment|financing|credit facility)\b|\bseries [a-d]\b|\binvestment from\b", re.I), False, 0.7, FACT),
    ("new_location", re.compile(r"\bnew (?:terminal|location|office|facility|warehouse|branch|yard|depot|hub)\b|\bnow open in\b|\bgrand opening\b|\bopened (?:a )?new\b", re.I), False, 0.7, FACT),
    ("expansion", re.compile(r"\bexpand\w*\b|\bexpansion\b|\badded \d+ (?:new )?(?:trucks|tractors|vehicles|units)\b|\bfleet (?:growth|expansion)\b|\bgrowing fleet\b", re.I), False, 0.6, FACT),
    ("new_contracts", re.compile(r"\bawarded (?:a )?(?:new )?contract\b|\bnew contracts?\b|\bsigned (?:a )?(?:multi-year )?(?:contract|agreement)\b", re.I), False, 0.6, FACT),
    ("rapid_growth", re.compile(r"\brapid(?:ly)? growth\b|\bfast(?:est)?[- ]growing\b|\bgrew \d+%|\bgrowth of \d+%|\binc\.? 5000\b", re.I), False, 0.65, FACT),
    ("multiple_entities", re.compile(r"\bsubsidiar(?:y|ies)\b|\bfamily of companies\b|\bsister compan(?:y|ies)\b|\bholding company\b|\bgroup of companies\b", re.I), False, 0.6, FACT),
    ("new_entity", re.compile(r"\b(?:launch\w*|formed|established|created) (?:a )?new (?:company|division|subsidiary|entity)\b", re.I), False, 0.65, FACT),
    ("public_accounting_problem", re.compile(r"\brestat\w+|\bmaterial weakness\b|\baccounting (?:error|irregularit\w+)\b|\blate filing\b|\bdelayed (?:financial )?(?:statements|filing)\b", re.I), False, 0.7, FACT),
]

_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")


@dataclass
class SignalCandidate:
    signal_type: str
    evidence_text: str
    source_url: str
    confidence: float
    kind: str
    description: str


def _sentence_for(text: str, start: int, end: int, max_len: int = 320) -> str:
    left = max(text.rfind(". ", 0, start), text.rfind("\n", 0, start), text.rfind("! ", 0, start), text.rfind("? ", 0, start))
    left = 0 if left < 0 else left + 1
    right_candidates = [i for i in (text.find(". ", end), text.find("\n", end), text.find("! ", end), text.find("? ", end)) if i >= 0]
    right = min(right_candidates) + 1 if right_candidates else len(text)
    sent = text[left:right].strip()
    if len(sent) > max_len:
        mid = (start + end) // 2
        a = max(0, mid - max_len // 2)
        sent = text[a:a + max_len].strip()
    return re.sub(r"\s+", " ", sent)


def detect_signals_in_text(text: str, source_url: str, *, is_careers_page: Optional[bool] = None) -> list[SignalCandidate]:
    """Find candidate signals in fetched text. Evidence is always a verbatim excerpt of `text`."""
    if not text:
        return []
    careers = _CAREERS_URL.search(source_url or "") is not None if is_careers_page is None else is_careers_page
    out: list[SignalCandidate] = []
    seen: set[str] = set()
    for sig_type, rx, needs_hiring, conf, kind in _RULES:
        if sig_type in seen:
            continue
        for m in rx.finditer(text):
            evidence = _sentence_for(text, m.start(), m.end())
            if needs_hiring and not (careers or _HIRING_CONTEXT.search(evidence)):
                continue
            if not validate_evidence(evidence, text):     # belt and braces: never emit unverifiable evidence
                continue
            entry = catalog_entry(sig_type)
            out.append(SignalCandidate(sig_type, evidence, source_url, conf, kind, entry["label"]))
            seen.add(sig_type)
            break
    # a specific vacancy makes the generic accounting vacancy redundant
    specific = {"hiring_controller", "hiring_finance_manager", "hiring_bookkeeper", "hiring_accountant"}
    specific_evidence = {_norm_ws(c.evidence_text) for c in out if c.signal_type in specific}
    generic = {"accounting_vacancy", "financial_reporting_vacancy"}
    # a generic vacancy that only restates a specific hiring signal's sentence adds no information
    return [c for c in out if not (c.signal_type in generic and _norm_ws(c.evidence_text) in specific_evidence)]
