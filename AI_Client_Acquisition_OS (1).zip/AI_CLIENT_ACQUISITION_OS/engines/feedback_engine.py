"""Feedback / self-learning engine (master prompt §27-28, §47).

Explicitly NOT a black-box model: every number here is a plain grouped count or rate over real
outcomes already recorded elsewhere in the app (company source, qualification level, pipeline
stage, disqualification reason). Nothing is weighted by a trained model, and nothing adjusts
itself automatically — a person reads these breakdowns and decides what to do differently, which
is exactly what §27 asks for ("Keep explainable scoring").

Two things live here:
  - quality tables: "which sources / industries / signals tend to produce leads that convert",
    grouped over EVERY qualified lead (not just contacted ones — that distinction matters: this
    answers 'is the data we're sourcing any good', where engines/experiment_engine.py separately
    answers 'does outreach using this angle get replies'. Different questions, deliberately not
    merged into one view.)
  - top_opportunities(): "if I have 30 minutes today, which 5 companies should I contact?" (§47) —
    ranked purely by the Opportunity Score, with the full evidence/offer/contact package attached.
"""
from __future__ import annotations

from typing import Optional

from sqlalchemy.orm import Session

from core.constants import DISQUALIFY_REASON_LABELS, DISQUALIFY_REASONS, TERMINAL_STAGES
from core.utils import pct
from database.models import Company, Lead, OutreachMessage, Signal
from engines.signal_engine import catalog_entry, rank_signals

QUALIFIED_LEVELS = ("HIGH", "MEDIUM")


def _source_bucket(source: Optional[str]) -> str:
    """Collapse a freeform source string ('CSV import: q3-leads.csv', 'Web research: https://x.example')
    to its category so volume-y imports don't each become their own one-row bucket."""
    if not source:
        return "Unknown"
    return source.split(":")[0].strip()


def _rate_row(key: str, leads: list[Lead]) -> dict:
    n = len(leads)
    qualified = sum(1 for l in leads if l.overall_priority in QUALIFIED_LEVELS)
    won = sum(1 for l in leads if l.status == "WON")
    disqualified = sum(1 for l in leads if l.status == "NOT_A_FIT")
    avg_opp = round(sum(l.opportunity_score or 0 for l in leads) / n) if n else None
    return {"key": key, "leads": n, "qualified": qualified, "qualified_rate": pct(qualified, n),
            "won": won, "won_rate": pct(won, n), "disqualified": disqualified,
            "disqualified_rate": pct(disqualified, n), "avg_opportunity_score": avg_opp}


def source_quality(db: Session, campaign_id: Optional[int] = None) -> list[dict]:
    q = db.query(Lead).join(Company, Lead.company_id == Company.id).filter(Company.archived.is_(False))
    if campaign_id:
        q = q.filter(Lead.campaign_id == campaign_id)
    leads = q.all()
    groups: dict[str, list[Lead]] = {}
    for l in leads:
        groups.setdefault(_source_bucket(l.company.source), []).append(l)
    rows = [_rate_row(k, v) for k, v in groups.items()]
    rows.sort(key=lambda r: (-r["won"], -r["qualified_rate"], -r["leads"]))
    return rows


def industry_quality(db: Session, campaign_id: Optional[int] = None) -> list[dict]:
    q = db.query(Lead).join(Company, Lead.company_id == Company.id).filter(Company.archived.is_(False))
    if campaign_id:
        q = q.filter(Lead.campaign_id == campaign_id)
    leads = q.all()
    groups: dict[str, list[Lead]] = {}
    for l in leads:
        groups.setdefault(l.company.industry or "Unknown", []).append(l)
    rows = [_rate_row(k, v) for k, v in groups.items()]
    rows.sort(key=lambda r: (-r["won"], -r["qualified_rate"], -r["leads"]))
    return rows


def signal_quality(db: Session, campaign_id: Optional[int] = None) -> list[dict]:
    """Per signal TYPE (not per contacted lead — see module docstring): of the leads whose top-ranked
    signal was this type, how many turned out to actually qualify or win? A signal that shows up often
    but rarely accompanies a qualified lead is weak evidence for THIS business, whatever the catalog's
    static weight assumed."""
    q = db.query(Lead).join(Company, Lead.company_id == Company.id).filter(Company.archived.is_(False))
    if campaign_id:
        q = q.filter(Lead.campaign_id == campaign_id)
    leads = q.all()
    sigs_by_company: dict[int, list[Signal]] = {}
    ids = {l.company_id for l in leads}
    if ids:
        for s in db.query(Signal).filter(Signal.company_id.in_(ids)).all():
            sigs_by_company.setdefault(s.company_id, []).append(s)
    groups: dict[str, list[Lead]] = {}
    for l in leads:
        top = rank_signals(sigs_by_company.get(l.company_id, []))
        key = catalog_entry(top[0].signal_type)["label"] if top else "No signal"
        groups.setdefault(key, []).append(l)
    rows = [_rate_row(k, v) for k, v in groups.items()]
    rows.sort(key=lambda r: (-r["won"], -r["qualified_rate"], -r["leads"]))
    return rows


def disqualification_breakdown(db: Session, campaign_id: Optional[int] = None) -> list[dict]:
    q = db.query(Lead).join(Company, Lead.company_id == Company.id).filter(
        Company.archived.is_(False), Lead.status == "NOT_A_FIT")
    if campaign_id:
        q = q.filter(Lead.campaign_id == campaign_id)
    leads = q.all()
    total = len(leads)
    counts = {r: 0 for r in DISQUALIFY_REASONS}
    for l in leads:
        if l.disqualify_reason in counts:
            counts[l.disqualify_reason] += 1
    rows = [{"reason": r, "label": DISQUALIFY_REASON_LABELS[r], "count": c, "pct": pct(c, total)}
            for r, c in counts.items() if c]
    rows.sort(key=lambda r: -r["count"])
    return rows


def top_opportunities(db: Session, *, limit: int = 5, campaign_id: Optional[int] = None) -> list[dict]:
    """Master prompt §47: 'If I have only 30 minutes today, which N companies should I contact?'
    Ranked purely by Opportunity Score among leads not yet closed — unlike the dashboard's
    task-driven priority list, this ignores due dates entirely and just answers 'best opportunity
    right now'."""
    q = (db.query(Lead).join(Company, Lead.company_id == Company.id)
         .filter(Company.archived.is_(False), ~Lead.status.in_(TERMINAL_STAGES), Lead.opportunity_score.isnot(None)))
    if campaign_id:
        q = q.filter(Lead.campaign_id == campaign_id)
    leads = q.order_by(Lead.opportunity_score.desc()).limit(limit).all()
    sigs_by_company: dict[int, list[Signal]] = {}
    ids = {l.company_id for l in leads}
    if ids:
        for s in db.query(Signal).filter(Signal.company_id.in_(ids)).all():
            sigs_by_company.setdefault(s.company_id, []).append(s)
    out = []
    for l in leads:
        top_sigs = rank_signals(sigs_by_company.get(l.company_id, []))[:3]
        draft = (db.query(OutreachMessage).filter(OutreachMessage.lead_id == l.id, OutreachMessage.status != "rejected")
                 .order_by(OutreachMessage.created_at.desc()).first())
        out.append({
            "lead_id": l.id, "company_id": l.company_id, "company": l.company.name,
            "person": ({"name": l.person.full_name, "title": l.person.title, "email": l.person.email} if l.person else None),
            "score": l.opportunity_score, "confidence": (l.qualification or {}).get("overall", {}).get("priority"),
            "reason": (l.qualification or {}).get("overall", {}).get("explanation"),
            "evidence": [{"signal": catalog_entry(s.signal_type)["label"], "text": s.evidence_text, "source": s.source}
                        for s in top_sigs],
            "recommended_offer": ({"service": l.recommended_service, "potential_mrr": l.potential_mrr,
                                   "text": (l.offer or {}).get("offer", {}).get("text")} if l.recommended_service else None),
            "suggested_email": ({"id": draft.id, "subject": draft.subject, "status": draft.status} if draft
                                else "No draft yet — open the lead and generate one."),
            "next_action": l.next_action, "next_action_date": l.next_action_date.isoformat() if l.next_action_date else None,
            "stage": l.status,
        })
    return out
