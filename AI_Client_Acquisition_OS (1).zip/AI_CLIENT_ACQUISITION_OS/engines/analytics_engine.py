"""Funnel, MRR and market analytics. Optimised for paying clients and MRR, not lead volume.
'Reached a stage' is computed from stage history, so a lead that was later lost still counts where it got to."""
from __future__ import annotations

from typing import Any, Optional

from sqlalchemy.orm import Session

from core.constants import PIPELINE_STAGES, PIPELINE_VALUE_STAGES, STAGE_LABELS
from core.settings_store import get_settings
from core.utils import country_bucket, pct
from database.models import Campaign, Company, Lead, OutreachMessage, StageHistory
from engines.signal_engine import catalog_entry

IDX = {s: i for i, s in enumerate(PIPELINE_STAGES)}
FUNNEL = [("leads", "Leads", 0), ("qualified", "Qualified", IDX["QUALIFIED"]), ("contacted", "Contacted", IDX["CONTACTED"]),
          ("replies", "Replies", IDX["REPLIED"]), ("calls", "Calls / meetings", IDX["CALL"]),
          ("proposals", "Proposals", IDX["PROPOSAL"]), ("won", "Won", IDX["WON"])]
DEFINITIONS = {
    "qualification_rate": "Qualified ÷ Leads", "response_rate": "Replies ÷ Contacted", "meeting_rate": "Calls ÷ Contacted",
    "proposal_rate": "Proposals ÷ Calls", "close_rate": "Won ÷ Proposals", "won_per_contacted": "Won ÷ Contacted",
}


def load_leads(db: Session, campaign_id: Optional[int] = None, country: Optional[str] = None) -> list[Lead]:
    q = db.query(Lead).join(Company, Lead.company_id == Company.id).filter(Company.archived.is_(False))
    if campaign_id:
        q = q.filter(Lead.campaign_id == campaign_id)
    if country:
        q = q.filter(Company.country == country)
    return q.all()


def max_reached(db: Session, leads: list[Lead]) -> dict[int, int]:
    reached = {l.id: IDX.get(l.status, 0) if l.status in IDX else 0 for l in leads}
    ids = list(reached)
    if ids:
        for lid, stage in db.query(StageHistory.lead_id, StageHistory.to_stage).filter(StageHistory.lead_id.in_(ids)).all():
            if stage in IDX and IDX[stage] > reached[lid]:
                reached[lid] = IDX[stage]
    return reached


def _rate(n: float, d: float, definition: str) -> dict:
    return {"value": pct(n, d), "n": n, "d": d, "definition": definition}


def funnel(db: Session, campaign_id: Optional[int] = None, country: Optional[str] = None) -> dict:
    leads = load_leads(db, campaign_id, country)
    reached = max_reached(db, leads)
    counts = {k: sum(1 for l in leads if reached[l.id] >= idx) for k, _, idx in FUNNEL}
    won = [l for l in leads if l.status == "WON"]
    counts["won"] = len(won)
    mrr = sum(l.actual_mrr or 0 for l in won)
    est = get_settings(db, "pipeline")["stage_estimates"]
    open_vals = [l for l in leads if l.status in PIPELINE_VALUE_STAGES]
    pipeline_value = sum(l.potential_mrr or 0 for l in open_vals)
    weighted = sum((l.potential_mrr or 0) * est.get(l.status, 0) for l in open_vals)
    stages = [{"key": k, "label": label, "count": counts[k]} for k, label, _ in FUNNEL]
    for i, s in enumerate(stages):
        s["pct_of_leads"] = pct(s["count"], counts["leads"])
        s["pct_of_previous"] = pct(s["count"], stages[i - 1]["count"]) if i else None
    return {
        "stages": stages, "counts": counts, "mrr": mrr, "pipeline_value": pipeline_value, "weighted_pipeline": round(weighted, 2),
        "avg_mrr": round(mrr / len(won), 2) if won else None,
        "rates": {
            "qualification_rate": _rate(counts["qualified"], counts["leads"], DEFINITIONS["qualification_rate"]),
            "response_rate": _rate(counts["replies"], counts["contacted"], DEFINITIONS["response_rate"]),
            "meeting_rate": _rate(counts["calls"], counts["contacted"], DEFINITIONS["meeting_rate"]),
            "proposal_rate": _rate(counts["proposals"], counts["calls"], DEFINITIONS["proposal_rate"]),
            "close_rate": _rate(counts["won"], counts["proposals"], DEFINITIONS["close_rate"]),
            "won_per_contacted": _rate(counts["won"], counts["contacted"], DEFINITIONS["won_per_contacted"]),
        },
        "estimate_note": "Weighted pipeline uses your own stage estimates (Settings → Pipeline). They are assumptions, not predictions.",
    }


def markets(db: Session) -> list[dict]:
    leads = load_leads(db)
    out = {b: {"market": b, "mrr": 0.0, "won": 0, "pipeline": 0.0, "leads": 0} for b in ("USA", "Poland", "Other")}
    for l in leads:
        m = out[country_bucket(l.company.country)]
        m["leads"] += 1
        if l.status == "WON":
            m["mrr"] += l.actual_mrr or 0; m["won"] += 1
        elif l.status in PIPELINE_VALUE_STAGES:
            m["pipeline"] += l.potential_mrr or 0
    return list(out.values())


def first_message(db: Session, lead_ids: list[int]) -> dict[int, OutreachMessage]:
    out: dict[int, OutreachMessage] = {}
    if not lead_ids:
        return out
    for m in (db.query(OutreachMessage).filter(OutreachMessage.lead_id.in_(lead_ids), OutreachMessage.sent_at.isnot(None),
                                                OutreachMessage.sequence_step == 0).order_by(OutreachMessage.sent_at).all()):
        out.setdefault(m.lead_id, m)
    return out


def lead_dimension(lead: Lead, dim: str, first_msg: Optional[OutreachMessage]) -> Optional[str]:
    if dim == "campaign":
        return lead.campaign.name if lead.campaign else "(no campaign)"
    if dim == "industry":
        return lead.company.industry or "(unknown)"
    if dim == "country":
        return lead.company.country or "(unknown)"
    if dim in ("service", "offer"):
        return lead.recommended_service or "(none)"
    if dim == "signal":
        return catalog_entry(lead.primary_signal_type)["label"] if lead.primary_signal_type else "(none)"
    if dim == "template":
        return first_msg.template_key if first_msg else None
    if dim == "channel":
        return first_msg.channel if first_msg else None
    return None


def mrr_breakdown(db: Session, by: str, campaign_id: Optional[int] = None) -> list[dict]:
    leads = load_leads(db, campaign_id)
    reached = max_reached(db, leads)
    fm = first_message(db, [l.id for l in leads])
    rows: dict[str, dict[str, Any]] = {}
    for l in leads:
        key = lead_dimension(l, by, fm.get(l.id))
        if key is None:
            continue
        r = rows.setdefault(key, {"key": key, "leads": 0, "contacted": 0, "won": 0, "mrr": 0.0, "pipeline_mrr": 0.0})
        r["leads"] += 1
        r["contacted"] += int(reached[l.id] >= IDX["CONTACTED"])
        if l.status == "WON":
            r["won"] += 1; r["mrr"] += l.actual_mrr or 0
        elif l.status in PIPELINE_VALUE_STAGES:
            r["pipeline_mrr"] += l.potential_mrr or 0
    out = list(rows.values())
    for r in out:
        r["avg_mrr"] = round(r["mrr"] / r["won"], 2) if r["won"] else None
    out.sort(key=lambda r: (-r["mrr"], -r["pipeline_mrr"], -r["leads"]))
    return out
