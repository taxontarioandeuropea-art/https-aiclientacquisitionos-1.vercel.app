"""Lead hunter: runs any BaseLeadSource and feeds the result through the shared ingestion pipeline.
Adding a new source = implement BaseLeadSource.fetch and register it below."""
from __future__ import annotations

from typing import Any, Optional

from sqlalchemy.orm import Session

from adapters.base import BaseLeadSource, SourceError
from adapters.csv_adapter import CSVLeadSource
from adapters.excel_adapter import ExcelLeadSource
from adapters.web_research_adapter import WebResearchSource
from core.errors import AppError
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from services import lead_service

SOURCES: dict[str, type[BaseLeadSource]] = {
    "csv": CSVLeadSource, "xlsx": ExcelLeadSource, "web_research": WebResearchSource,
}
# TODO (see adapters/future/README.md): search engines, company databases, job boards, public registries,
# LinkedIn-compatible exports, CRM exports.


def list_sources() -> list[dict]:
    return [cls().describe() if cls is not WebResearchSource else {"name": "web_research", "description": WebResearchSource.description}
            for cls in SOURCES.values()]


def run_source(db: Session, source: BaseLeadSource, *, campaign_id: Optional[int], label: str, params: dict[str, Any],
               qualify: bool = True, actor: str = "user") -> dict:
    try:
        records = source.fetch(**params)
    except SourceError as exc:
        raise AppError(str(exc), operation=f"read {label}", cause=exc.cause or None, suggestion=exc.suggestion or None) from exc
    report = lead_service.ingest_records(db, records, campaign_id=campaign_id, source_label=label, actor=actor)
    if qualify and report.lead_ids:
        from database.models import Lead
        for lead in db.query(Lead).filter(Lead.id.in_(set(report.lead_ids))).all():
            qualify_lead(db, lead, actor="ai")
            generate_offer(db, lead, actor="ai")
    return report.as_dict()


def discover_from_urls(db: Session, urls: list[str], campaign_id: Optional[int], *, source: Optional[WebResearchSource] = None,
                       actor: str = "user") -> dict:
    src = source or WebResearchSource(max_pages=4)
    return run_source(db, src, campaign_id=campaign_id, label=f"web research ({len(urls)} sites)", params={"urls": urls}, actor=actor)
