"""Compliance engine (master prompt §23).

Every company has exactly one status, computed fresh each time rather than trusted from a stale
column, in this order:
    1. SUPPRESSED   — company, its email, or its domain is on the suppression list. Permanent
                       until a person removes the entry.
    2. RESTRICTED   — a ComplianceRecord exists and was explicitly set to RESTRICTED (e.g. a
                       jurisdiction or contact type the user has decided not to pursue).
    3. CLEAR        — a ComplianceRecord exists, has a lawful_basis, and was marked CLEAR.
    4. REVIEW_REQUIRED — everything else, including a company with NO record at all.

REVIEW_REQUIRED is the default for a reason: the master prompt is explicit that uncertain status
must never be treated as "safe to contact" by omission (§23 — "If compliance status is uncertain:
STATUS = REVIEW_REQUIRED. Do not automatically send."). This engine is what the message-approval
gate in api/crm_routes.py checks before letting a draft move to 'approved'.

For B2B outreach to a company's own published business contact (not a named individual's personal
address), the standard lawful basis under GDPR/Polish law is "legitimate interest" — but that is a
judgment call the user makes per company, not an inference this engine is willing to make for them;
auto-assigning it would be exactly the kind of silent assumption §23 forbids.
"""
from __future__ import annotations

from typing import Any, Optional

from sqlalchemy.orm import Session

from core import audit
from core.errors import NotFound, ValidationProblem
from core.utils import normalize_domain, normalize_email, sanitize_text, utcnow
from database.models import Company, ComplianceRecord, Person, SuppressionEntry

STATUSES = ("CLEAR", "REVIEW_REQUIRED", "RESTRICTED", "SUPPRESSED")
LAWFUL_BASES = ("legitimate_interest_b2b", "public_task_source", "consent")
CONTACT_TYPES = ("professional", "personal")
SUPPRESSION_REASONS = ("opt_out", "complaint", "bounced", "manual", "legal_request")


# ------------------------------------------------------------------ suppression
def _norm_value(match_type: str, value: str) -> str:
    if match_type == "email":
        v = normalize_email(value)
    elif match_type == "domain":
        v = normalize_domain(value) or value.strip().lower()
    else:
        v = str(value).strip()
    if not v:
        raise ValidationProblem(f"'{value}' is not a usable {match_type} value", operation="add suppression entry")
    return v


def add_suppression(db: Session, match_type: str, value: str, *, reason: str = "manual", note: Optional[str] = None,
                    actor: str = "user") -> tuple[SuppressionEntry, bool]:
    if match_type not in ("company", "email", "domain"):
        raise ValidationProblem("match_type must be company, email or domain", operation="add suppression entry")
    if reason not in SUPPRESSION_REASONS:
        raise ValidationProblem(f"Unknown reason '{reason}'", operation="add suppression entry",
                                suggestion=f"Use one of: {', '.join(SUPPRESSION_REASONS)}")
    v = _norm_value(match_type, value)
    existing = db.query(SuppressionEntry).filter_by(match_type=match_type, value=v).first()
    if existing:
        return existing, False
    entry = SuppressionEntry(match_type=match_type, value=v, reason=reason, note=sanitize_text(note, 1000), added_by=actor)
    db.add(entry)
    db.flush()
    audit.log(db, "suppression_added", f"Suppressed {match_type}: {v} ({reason})", entity_type="suppression", entity_id=entry.id, actor=actor)
    return entry, True


def remove_suppression(db: Session, entry_id: int, *, actor: str = "user") -> None:
    entry = db.get(SuppressionEntry, entry_id)
    if not entry:
        raise NotFound("Suppression entry", entry_id)
    audit.log(db, "suppression_removed", f"Removed suppression: {entry.match_type} {entry.value}",
              entity_type="suppression", entity_id=entry_id, actor=actor, details={"snapshot": entry.as_dict()})
    db.delete(entry)
    db.flush()


def list_suppressions(db: Session) -> list[dict]:
    return [e.as_dict() for e in db.query(SuppressionEntry).order_by(SuppressionEntry.created_at.desc()).all()]


def _suppression_hit(db: Session, company: Company, person: Optional[Person]) -> Optional[SuppressionEntry]:
    checks = [("company", str(company.id))]
    if company.domain:
        checks.append(("domain", company.domain))
    if company.email:
        checks.append(("email", normalize_email(company.email)))
    if person and person.email:
        checks.append(("email", normalize_email(person.email)))
    for match_type, value in checks:
        if not value:
            continue
        hit = db.query(SuppressionEntry).filter_by(match_type=match_type, value=value).first()
        if hit:
            return hit
    return None


# ------------------------------------------------------------------ compliance status
def get_record(db: Session, company_id: int) -> Optional[ComplianceRecord]:
    return db.query(ComplianceRecord).filter_by(company_id=company_id).first()


def status_for(db: Session, company_id: int, *, person: Optional[Person] = None) -> dict:
    """The live, computed status for one company. Never trust a cached value — recompute every time,
    since a suppression entry added after a record was marked CLEAR must still block sending."""
    company = db.get(Company, company_id)
    if not company:
        raise NotFound("Company", company_id)
    hit = _suppression_hit(db, company, person)
    if hit:
        return {"status": "SUPPRESSED", "reason": f"On the suppression list ({hit.reason}): {hit.match_type} = {hit.value}",
                "lawful_basis": None, "contact_type": None, "record": None}
    rec = get_record(db, company_id)
    if not rec:
        return {"status": "REVIEW_REQUIRED", "reason": "No compliance record exists for this company yet.",
                "lawful_basis": None, "contact_type": None, "record": None}
    if rec.status == "CLEAR" and not rec.lawful_basis:
        # a record can't be trusted as CLEAR without a stated basis, even if someone set the column directly
        return {"status": "REVIEW_REQUIRED", "reason": "Marked CLEAR but no lawful basis is recorded.",
                "lawful_basis": None, "contact_type": rec.contact_type, "record": rec.as_dict()}
    reason = {
        "CLEAR": f"Lawful basis on file: {rec.lawful_basis}.",
        "RESTRICTED": rec.notes or "Marked restricted by a reviewer.",
        "REVIEW_REQUIRED": rec.notes or "Explicitly marked for review.",
    }.get(rec.status, "Unknown status.")
    return {"status": rec.status, "reason": reason, "lawful_basis": rec.lawful_basis, "contact_type": rec.contact_type,
            "record": rec.as_dict()}


def set_record(db: Session, company_id: int, data: dict[str, Any], *, actor: str = "user") -> ComplianceRecord:
    company = db.get(Company, company_id)
    if not company:
        raise NotFound("Company", company_id)
    status = data.get("status")
    if status and status not in STATUSES:
        raise ValidationProblem(f"Unknown status '{status}'", operation="save compliance record",
                                suggestion=f"Use one of: {', '.join(STATUSES)}")
    lawful_basis = data.get("lawful_basis")
    if lawful_basis and lawful_basis not in LAWFUL_BASES:
        raise ValidationProblem(f"Unknown lawful basis '{lawful_basis}'", operation="save compliance record",
                                suggestion=f"Use one of: {', '.join(LAWFUL_BASES)}")
    if status == "CLEAR" and not (lawful_basis or (get_record(db, company_id) or ComplianceRecord()).lawful_basis):
        raise ValidationProblem("A lawful basis is required to mark a company CLEAR", operation="save compliance record",
                                suggestion="Choose a lawful basis, or save as REVIEW_REQUIRED / RESTRICTED instead.")
    contact_type = data.get("contact_type")
    if contact_type and contact_type not in CONTACT_TYPES:
        raise ValidationProblem("contact_type must be professional or personal", operation="save compliance record")
    rec = get_record(db, company_id)
    if not rec:
        rec = ComplianceRecord(company_id=company_id, status="REVIEW_REQUIRED")
        db.add(rec)
    changes = {}
    for field in ("status", "lawful_basis", "contact_type", "jurisdiction", "source_id"):
        if field in data and data[field] != getattr(rec, field):
            changes[field] = {"from": getattr(rec, field), "to": data[field]}
            setattr(rec, field, data[field])
    if "notes" in data:
        rec.notes = sanitize_text(data["notes"], 2000)
    if changes:
        rec.reviewed_by, rec.reviewed_at = actor, utcnow()
        db.flush()
        audit.log(db, "compliance_updated", f"Compliance status for {company.name}: {rec.status}",
                  entity_type="company", entity_id=company_id, actor=actor, details={"changes": changes})
    db.flush()
    return rec


def check_before_approve(db: Session, lead) -> None:
    """Called from the message-approval gate. Raises AppError (never silently proceeds) unless
    status is exactly CLEAR."""
    from core.errors import AppError
    result = status_for(db, lead.company_id, person=lead.person)
    if result["status"] == "CLEAR":
        return
    labels = {"SUPPRESSED": "This company is on the suppression list and must not be contacted.",
              "RESTRICTED": "This company is marked restricted for outreach.",
              "REVIEW_REQUIRED": "This company's compliance status has not been reviewed."}
    raise AppError(labels.get(result["status"], "Compliance status blocks sending"), operation="approve message",
                   cause=result["reason"], status_code=423,
                   suggestion="Review it under Compliance → Company status before approving this message.")


def summary(db: Session) -> dict:
    from sqlalchemy import func
    counts = dict(db.query(ComplianceRecord.status, func.count(ComplianceRecord.id)).group_by(ComplianceRecord.status).all())
    total_companies = db.query(func.count(Company.id)).filter(Company.archived.is_(False)).scalar() or 0
    with_record = sum(counts.values())
    counts["REVIEW_REQUIRED"] = counts.get("REVIEW_REQUIRED", 0) + (total_companies - with_record)
    return {"counts": {s: counts.get(s, 0) for s in STATUSES if s != "SUPPRESSED"},
            "suppressed": db.query(func.count(SuppressionEntry.id)).scalar() or 0,
            "total_companies": total_companies}
