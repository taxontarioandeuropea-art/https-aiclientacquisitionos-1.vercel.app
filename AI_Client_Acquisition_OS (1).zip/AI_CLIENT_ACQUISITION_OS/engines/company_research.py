"""Company research pipeline:
Company -> basic info -> industry -> size -> technology -> growth -> public signals -> decision makers ->
potential problems -> service match -> outreach recommendation.

Every statement in the report is tagged FACT / INFERENCE / RECOMMENDATION and keeps its source.
"""
from __future__ import annotations

from datetime import date
from typing import Any, Optional

from sqlalchemy.orm import Session

from adapters.base import SourceError
from adapters.web_research_adapter import ResearchFindings, WebResearchSource
from ai.base import AIProviderError
from ai.providers import get_provider
from core import audit
from core.constants import FACT, INFERENCE, LEVEL_RANK, RECOMMENDATION
from core.errors import NotFound
from core.settings_store import RESEARCH_DEPTH_PAGES, get_settings
from core.utils import today as _today, utcnow
from database.models import Company, Lead, Person, Signal
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from engines.signal_engine import add_signal, catalog_entry, rank_signals, validate_evidence

ACCOUNTING_TECH = {"QuickBooks", "Xero", "NetSuite", "Sage", "SAP", "Microsoft Dynamics", "Odoo", "Comarch", "Symfonia", "enova"}
COMPLETENESS_FIELDS = ["industry", "employees", "country", "website", "accounting_software", "description"]


def st(kind: str, text: str, source: Optional[str] = None, url: Optional[str] = None, **extra: Any) -> dict:
    return {"kind": kind, "text": text, "source": source, "source_url": url, **extra}


def _persist_web_findings(db: Session, company: Company, f: ResearchFindings, actor: str) -> dict:
    added_signals, added_fields = 0, []
    src = {"source": "Company website", "date": _today().isoformat()}
    fs = dict(company.field_sources or {})
    techs = [t["name"] for t in f.technologies]
    new_stack = list(dict.fromkeys((company.technology_stack or []) + techs))
    if new_stack != (company.technology_stack or []):
        company.technology_stack = new_stack
        fs["technology_stack"] = {**src, "url": f.technologies[0]["source_url"] if f.technologies else f.website}
        added_fields.append("technology_stack")
    acct = next((t for t in f.technologies if t["name"] in ACCOUNTING_TECH), None)
    if acct and not company.accounting_software:
        company.accounting_software = acct["name"]
        fs["accounting_software"] = {**src, "url": acct["source_url"], "evidence": acct["evidence_text"]}
        added_fields.append("accounting_software")
    if f.description and not company.description:
        company.description = f.description
        fs["description"] = {**src, "url": f.website}
        added_fields.append("description")
    generic = next((e for e in f.emails if e["generic"]), None)
    if generic and not company.email:
        company.email = generic["email"]
        fs["email"] = {**src, "url": generic["source_url"]}
        added_fields.append("email")
    if f.phones and not company.phone:
        company.phone = f.phones[0]["phone"]
        fs["phone"] = {**src, "url": f.phones[0]["source_url"]}
        added_fields.append("phone")
    company.field_sources = fs
    for c in f.signals:
        if not validate_evidence(c.evidence_text, f.texts.get(c.source_url, "")):
            continue                                    # never store evidence we cannot re-verify
        _, created = add_signal(db, company.id, c.signal_type, c.evidence_text, "Company website", source_url=c.source_url,
                                confidence=c.confidence, kind=c.kind, origin="web_research", verified=True,
                                is_demo=company.is_demo, actor=actor)
        added_signals += int(created)
    return {"signals_added": added_signals, "fields_added": added_fields}


def run_research(db: Session, company_id: int, *, use_web: bool = True, use_ai: bool = False, actor: str = "ai",
                 web_source: Optional[WebResearchSource] = None) -> dict:
    from services import crm_service
    company = db.get(Company, company_id)
    if not company:
        raise NotFound("Company", company_id)
    settings = get_settings(db)
    log: dict[str, Any] = {"web": None, "errors": [], "signals_added": 0, "fields_added": []}
    if use_web:
        if not company.website:
            log["errors"].append("No website on record, so no web research was possible. Add the website and run research again.")
        else:
            pages = RESEARCH_DEPTH_PAGES.get(settings["ai"].get("research_depth", "standard"), 6)
            src = web_source or WebResearchSource(max_pages=pages)
            try:
                findings = src.research(company.website)
                res = _persist_web_findings(db, company, findings, actor)
                log.update(res)
                log["web"] = {"pages": findings.pages, "emails_found": len(findings.emails), "technologies": [t["name"] for t in findings.technologies]}
                log["errors"] += findings.errors
            except SourceError as exc:
                log["errors"].append(f"{exc} — {getattr(exc, 'cause', '')} {getattr(exc, 'suggestion', '')}".strip())
    company.last_researched_at = utcnow()
    leads = db.query(Lead).filter(Lead.company_id == company.id).all()
    for lead in leads:
        if lead.status == "NEW":
            crm_service.move_stage(db, lead.id, "RESEARCHED", actor="system", note="Research completed")
        qualify_lead(db, lead, actor=actor)
        generate_offer(db, lead, actor=actor)
    db.flush()
    report = build_report(db, company)
    report["research_log"] = log
    if use_ai:
        report["ai_summary"] = _ai_summary(report, settings["ai"])
    company.research_report = report
    audit.log(db, "research_run", f"Research run on {company.name}: {log['signals_added']} new signals"
                                  + (f", {len(log['errors'])} problems" if log["errors"] else ""),
              entity_type="company", entity_id=company.id, actor=actor,
              details={"log": log})
    db.flush()
    return report


def _ai_summary(report: dict, ai_settings: dict) -> dict:
    provider = get_provider(ai_settings)
    facts = "\n".join(f"[{s['kind']}] {s['text']}" for s in report["sections"]["executive_summary"])
    if not provider.is_configured():
        return {"text": None, "note": "No AI provider is configured (Settings → AI). The rule-based summary above is used."}
    try:
        text = provider.generate("Summarise these research findings for a sales owner in under 120 words. Use ONLY the statements "
                                 "given; keep FACT vs INFERENCE wording; add nothing new.", facts,
                                 temperature=float(ai_settings.get("temperature", 0.4)))
    except AIProviderError as exc:
        return {"text": None, "note": f"AI summary failed: {exc.cause}"}
    from engines.message_engine import _new_facts_introduced
    if _new_facts_introduced(facts, text):
        return {"text": None, "note": "The AI summary introduced figures that are not in the research and was discarded."}
    return {"text": text, "provider": provider.name, "note": "AI-generated from the statements above — review before relying on it."}


def _completeness(c: Company) -> float:
    return sum(1 for f in COMPLETENESS_FIELDS if getattr(c, f)) / len(COMPLETENESS_FIELDS)


def _company_source(c: Company, field: str) -> tuple[str, Optional[str]]:
    fs = (c.field_sources or {}).get(field)
    if fs:
        return fs.get("source", "Company website"), fs.get("url")
    return c.source or "Company record", c.source_url


def build_report(db: Session, company: Company, lead: Optional[Lead] = None) -> dict:
    on = _today()
    leads = db.query(Lead).filter(Lead.company_id == company.id).all()
    if lead is None and leads:
        lead = sorted(leads, key=lambda l: -LEVEL_RANK.get(l.overall_priority or "UNKNOWN", 0))[0]
    signals = rank_signals(db.query(Signal).filter(Signal.company_id == company.id).all(), on)
    people = db.query(Person).filter(Person.company_id == company.id).all()
    offer = (lead.offer if lead else None) or None
    q = (lead.qualification if lead else None) or {}
    src = company.source or "Company record"

    where = ", ".join(x for x in [company.city, company.state, company.country] if x)
    profile_line = f"{company.name}" + (f" is a {company.industry} company" if company.industry else " (industry not recorded)") \
        + (f" based in {where}" if where else "") + (f" with about {company.employees} employees" if company.employees else "") + "."
    summary = [st(FACT, profile_line, src, company.source_url)]
    if signals:
        verified = sum(1 for s in signals if s.verified)
        summary.append(st(FACT, f"{len(signals)} evidence-backed signal(s) recorded ({verified} verified against fetched source text); "
                                f"strongest: {catalog_entry(signals[0].signal_type)['label']} — source: {signals[0].source}.",
                          signals[0].source, signals[0].source_url))
    else:
        summary.append(st(FACT, "No buying or need signals have been recorded yet, so no conclusions about need can be drawn."))
    if offer:
        summary.append(st(INFERENCE, offer["problem"]["text"] + ".", "Signal evidence (see Evidence)"))
        summary.append(st(RECOMMENDATION, f"Recommended service: {offer['service']} — {offer['offer']['text']}. "
                                          f"Potential MRR ≈ ${offer['potential_mrr']:,.0f} (estimate, not a quote).", None))
    if lead and lead.overall_priority:
        summary.append(st(FACT, f"Qualification: priority {lead.overall_priority.capitalize()} (see Buying signals and Evidence).", "Qualification engine"))

    ind_src, ind_url = _company_source(company, "industry")
    sections: dict[str, Any] = {"executive_summary": summary}
    sections["company_profile"] = {
        "company": company.name, "market": company.country or "Unknown", "industry": " / ".join(x for x in [company.industry, company.subindustry] if x) or "Unknown",
        "size": f"{company.employees} employees" if company.employees else (company.estimated_scale or "Unknown"),
        "technology": ", ".join(([company.accounting_software] if company.accounting_software else []) + [t for t in (company.technology_stack or []) if t != company.accounting_software]) or "Unknown",
        "signals": [catalog_entry(s.signal_type)["label"] for s in signals[:6]],
        "possible_need": (offer["problem"]["text"] if offer else "Not determined — needs evidence"),
        "recommended_service": offer["service"] if offer else "None yet (no evidence-based match)",
        "potential_mrr": offer["potential_mrr"] if offer else None,
        "decision_maker": ", ".join(f"{p.full_name} ({p.title})" for p in people[:3] if p.full_name) or "Not identified",
        "next_action": (lead.next_action if lead else None) or "Research company",
    }
    d_src, d_url = _company_source(company, "description")
    sections["business_model"] = [st(FACT, company.description, d_src, d_url)] if company.description else \
        [st(FACT, "No description recorded — run web research or add one.")]
    sections["industry"] = [st(FACT, f"Industry: {company.industry}" + (f" / {company.subindustry}" if company.subindustry else ""), ind_src, ind_url)] \
        if company.industry else [st(FACT, "Industry is not recorded.")]
    sections["size"] = [st(FACT, x, src, company.source_url) for x in
                        ([f"{company.employees} employees"] if company.employees else []) +
                        ([f"Estimated annual revenue ${company.estimated_revenue:,.0f}"] if company.estimated_revenue else []) +
                        ([f"Scale: {company.estimated_scale}"] if company.estimated_scale else [])] or [st(FACT, "Size is not recorded.")]
    t_src, t_url = _company_source(company, "technology_stack")
    tech = ([f"Accounting software: {company.accounting_software}"] if company.accounting_software else []) + \
           ([f"Technology mentioned: {', '.join(company.technology_stack)}"] if company.technology_stack else [])
    sections["technology"] = [st(FACT, x, t_src, t_url) for x in tech] or [st(FACT, "No technology information recorded.")]
    sections["growth"] = ([st(FACT, f"Growth status: {company.growth_status}", src)] if company.growth_status else []) + \
        [st(s.kind, f"{catalog_entry(s.signal_type)['label']}: {s.description}", s.source, s.source_url, date=str(s.date_detected))
         for s in signals if catalog_entry(s.signal_type)["category"] == "growth"] or [st(FACT, "No growth information recorded.")]
    sections["buying_signals"] = [st(s.kind, f"{catalog_entry(s.signal_type)['label']} — {s.description}", s.source, s.source_url,
                                     date=str(s.date_detected), confidence=s.confidence, verified=s.verified) for s in signals]
    sections["evidence"] = [{"signal": catalog_entry(s.signal_type)["label"], "evidence_text": s.evidence_text, "source": s.source,
                             "source_url": s.source_url, "date_detected": str(s.date_detected), "verified": s.verified,
                             "kind": s.kind, "origin": s.origin} for s in signals]
    seen, problems = set(), []
    for s in signals:
        p = catalog_entry(s.signal_type)["problem"]
        if p not in seen:
            seen.add(p)
            problems.append(st(INFERENCE, p, s.source, s.source_url, based_on=catalog_entry(s.signal_type)["label"]))
    sections["possible_finance_problems"] = problems or [st(FACT, "No evidence of finance problems has been recorded.")]
    sections["decision_makers"] = [st(FACT, f"{p.full_name or p.email} — {p.title or 'title unknown'}"
                                            f"{' · ' + p.email if p.email else ''}", p.source, p.source_url,
                                      level=p.decision_maker_level, confidence=p.confidence) for p in people] or \
        [st(FACT, "No decision maker identified yet — find one before outreach.")]
    sections["recommended_service"] = [st(RECOMMENDATION, f"{offer['service']} (match score {offer['score']}, confidence {offer['confidence'].lower()})")] if offer else \
        [st(FACT, "No evidence-based service match yet.")]
    sections["recommended_offer"] = ([st(RECOMMENDATION, offer["offer"]["text"]), st(RECOMMENDATION, f"Pricing: {offer['pricing']['display']}")] +
                                     ([st(RECOMMENDATION, offer["alternative"]["text"])] if offer.get("alternative") else [])) if offer else []
    if signals and offer:
        top = signals[0]
        e = catalog_entry(top.signal_type)
        sections["outreach_angle"] = [st(RECOMMENDATION, f"Open with the observed fact ({e['label'].lower()}), link it to {e['implication']}, "
                                                          f"then offer {offer['service'].lower()} with a low-friction question.", top.source, top.source_url)]
    else:
        sections["outreach_angle"] = [st(FACT, "No outreach angle yet — the app will not write generic outreach without evidence.")]
    sections["next_action"] = [st(RECOMMENDATION, (lead.next_action if lead else None) or "Research company")]

    verified_ratio = (sum(1 for s in signals if s.verified) / len(signals)) if signals else 0
    comp = _completeness(company)
    reasons = [f"{len(signals)} signal(s) with sources ({verified_ratio:.0%} verified)", f"{comp:.0%} of key company fields filled",
               "decision maker identified" if people else "no decision maker identified"]
    level = "HIGH" if len(signals) >= 2 and comp >= 0.6 and people else "MEDIUM" if signals or comp >= 0.6 else "LOW"
    sections["confidence"] = {"level": level, "reasons": reasons}
    gaps = [f"{f.replace('_', ' ')} unknown" for f in COMPLETENESS_FIELDS if not getattr(company, f)]
    if not people:
        gaps.append("decision maker unknown")
    return {"generated_at": utcnow().isoformat(timespec="seconds"), "company_id": company.id, "lead_id": lead.id if lead else None,
            "legend": {FACT: "Read from a recorded source", INFERENCE: "Reasoning from facts", RECOMMENDATION: "Suggested action"},
            "sections": sections, "data_gaps": gaps, "qualification": q.get("overall")}


TITLES = [("executive_summary", "Executive summary"), ("business_model", "Business model"), ("industry", "Industry"), ("size", "Size"),
          ("technology", "Technology"), ("growth", "Growth"), ("buying_signals", "Buying signals"), ("possible_finance_problems", "Possible finance problems"),
          ("decision_makers", "Decision makers"), ("recommended_service", "Recommended service"), ("recommended_offer", "Recommended offer"),
          ("outreach_angle", "Outreach angle"), ("next_action", "Next action")]


def report_to_markdown(report: dict, company_name: str) -> str:
    s = report["sections"]
    lines = [f"# Research report — {company_name}", f"_Generated {report['generated_at']}_", "",
             "Legend: **FACT** = read from a recorded source · **INFERENCE** = reasoning from facts · **RECOMMENDATION** = suggested action", ""]
    p = s["company_profile"]
    lines += ["## Company profile", ""] + [f"- **{k.replace('_', ' ').title()}**: {', '.join(v) if isinstance(v, list) else v}" for k, v in p.items()] + [""]
    for key, title in TITLES:
        items = s.get(key) or []
        lines += [f"## {title}", ""]
        for it in items:
            src = f" _(source: {it['source']}{', ' + it['source_url'] if it.get('source_url') else ''})_" if it.get("source") else ""
            lines.append(f"- **{it['kind']}** {it['text']}{src}")
        lines.append("")
    lines += ["## Evidence", ""]
    for e in s["evidence"]:
        lines += [f"- **{e['signal']}** ({e['kind']}, {'verified' if e['verified'] else 'user-entered'}): “{e['evidence_text']}” — {e['source']}"
                  f"{' · ' + e['source_url'] if e['source_url'] else ''} · detected {e['date_detected']}"]
    if not s["evidence"]:
        lines.append("- No evidence recorded.")
    c = s["confidence"]
    lines += ["", "## Confidence", "", f"**{c['level']}** — " + "; ".join(c["reasons"]), ""]
    if report.get("data_gaps"):
        lines += ["## Data gaps", ""] + [f"- {g}" for g in report["data_gaps"]]
    return "\n".join(lines)
