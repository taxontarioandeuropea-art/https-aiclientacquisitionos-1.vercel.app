"""Offer matching engine:  Problem -> Service -> Offer -> Price.

A service is only recommended when at least one recorded signal (with evidence) maps to it through the
service's `required_signals`. There is no generic fallback service: no evidence, no recommendation.
"""
from __future__ import annotations

from datetime import date
from typing import Any, Optional

from sqlalchemy.orm import Session

from core import audit
from core.constants import FACT, INFERENCE, RECOMMENDATION
from core.errors import NotFound
from core.utils import classify_title, today as _today
from database.models import Campaign, Company, Lead, Person, Service, Signal
from engines.signal_engine import catalog_entry, noisy_or, rank_signals, signal_strength

MIN_MATCH_SCORE = 25


def _price_display(s: Service) -> str:
    if s.pricing_model == "project":
        return f"Project-based (from ${s.minimum_price:,.0f})" if s.minimum_price else "Project-based"
    lo, hi = s.minimum_price, s.target_mrr
    if lo and hi and lo != hi:
        return f"${lo:,.0f}–${hi:,.0f} / month"
    if hi or lo:
        return f"~${(hi or lo):,.0f} / month"
    return "Price not set"


def estimate_mrr(service: Optional[Service], ability_level: Optional[str]) -> float:
    """Estimated recurring revenue if the service is sold. An estimate, never a quote."""
    if not service or service.pricing_model == "project":
        return 0.0
    target = service.target_mrr or service.minimum_price or 0.0
    if ability_level == "LOW" and service.minimum_price:
        return float(service.minimum_price)
    return float(target)


def _size_ok(service: Service, company: Company) -> Optional[bool]:
    if company.employees is None or (service.target_employees_min is None and service.target_employees_max is None):
        return None
    lo, hi = service.target_employees_min, service.target_employees_max
    return (lo is None or company.employees >= lo) and (hi is None or company.employees <= hi)


def score_service(service: Service, company: Company, person: Optional[Person], signals: list[Signal],
                  campaign: Optional[Campaign], on: date) -> dict:
    triggers = {t.lower() for t in (service.required_signals or [])}
    matched = [s for s in signals if s.signal_type.lower() in triggers]
    reasons: list[dict] = []
    evidence = noisy_or(signal_strength(s, "need", on) for s in matched)
    score = evidence * 60
    for s in sorted(matched, key=lambda x: -signal_strength(x, "need", on))[:3]:
        reasons.append({"kind": FACT, "effect": "positive", "signal_id": s.id,
                        "text": f"{catalog_entry(s.signal_type)['label']} — “{s.evidence_text[:140]}” [{s.source}]"})
    factor = 1.0
    inds = [i.lower() for i in (service.target_industries or [])]
    if inds:
        hay = f"{company.industry or ''} {company.subindustry or ''}".lower()
        if any(i in hay or (company.industry or "").lower() in i for i in inds if i):
            score += 10
            reasons.append({"kind": FACT, "effect": "positive", "text": f"Industry ({company.industry}) is a target for this service"})
        elif hay.strip():
            factor *= 0.6
            reasons.append({"kind": FACT, "effect": "negative", "text": f"Industry ({company.industry}) is not in this service's target industries"})
    size = _size_ok(service, company)
    if size is True:
        score += 10
        reasons.append({"kind": FACT, "effect": "positive", "text": f"{company.employees} employees fits the service's size range"})
    elif size is False:
        factor *= 0.8
        reasons.append({"kind": FACT, "effect": "negative", "text": f"{company.employees} employees is outside the service's size range"})
    if service.target_technology:
        hay = f"{company.accounting_software or ''} {' '.join(company.technology_stack or [])}".lower().strip()
        if hay and any(t.lower() in hay for t in service.target_technology):
            score += 15
            reasons.append({"kind": FACT, "effect": "positive", "text": f"Uses {company.accounting_software or 'target technology'}, which this service supports"})
        elif hay:
            factor *= 0.7
            reasons.append({"kind": FACT, "effect": "negative", "text": "Known technology differs from the service's target technology"})
    if person and service.preferred_decision_makers:
        title = (person.title or "").lower()
        if any(p.lower() in title for p in service.preferred_decision_makers):
            score += 5
            reasons.append({"kind": FACT, "effect": "positive", "text": f"{person.title} is a preferred decision maker for this service"})
    if campaign and campaign.minimum_mrr and service.pricing_model == "monthly" and service.target_mrr and service.target_mrr < campaign.minimum_mrr:
        factor *= 0.5
        reasons.append({"kind": FACT, "effect": "negative",
                        "text": f"Service target MRR (${service.target_mrr:,.0f}) is below the campaign minimum (${campaign.minimum_mrr:,.0f})"})
    total = round(min(100.0, score) * factor)
    return {"service": service, "score": total, "matched": matched, "reasons": reasons}


def match_services(company: Company, person: Optional[Person], signals: list[Signal], services: list[Service],
                   campaign: Optional[Campaign], *, on: Optional[date] = None, ability_level: Optional[str] = None) -> list[dict]:
    on = on or _today()
    pool = [s for s in services if s.is_active]
    if campaign and campaign.services:
        allowed = {s.id for s in campaign.services}
        pool = [s for s in pool if s.id in allowed]
    ranked = []
    for svc in pool:
        r = score_service(svc, company, person, signals, campaign, on)
        if r["matched"] and r["score"] >= MIN_MATCH_SCORE:
            ranked.append(r)
    ranked.sort(key=lambda r: -r["score"])
    return [build_offer(r, company, services, ability_level) for r in ranked]


def build_offer(r: dict, company: Company, all_services: list[Service], ability_level: Optional[str]) -> dict:
    svc: Service = r["service"]
    matched: list[Signal] = r["matched"]
    top = rank_signals(matched)[0]
    entry = catalog_entry(top.signal_type)
    deliver = [d for d in (svc.deliverables or []) if d][:3]
    offer_text = f"{svc.name}: " + (" + ".join(deliver) if deliver else (svc.description or "scope to be defined"))
    follow_on = next((s for s in all_services if s.id == svc.follow_on_service_id and s.is_active), None) if svc.follow_on_service_id else None
    if svc.pricing_model == "project":
        project_value, mrr = float(svc.minimum_price or svc.target_mrr or 0), estimate_mrr(follow_on, ability_level)
    else:
        project_value, mrr = 0.0, estimate_mrr(svc, ability_level)
    conf = "HIGH" if r["score"] >= 65 else "MEDIUM" if r["score"] >= 40 else "LOW"
    return {
        "service_id": svc.id, "service": svc.name, "score": r["score"], "confidence": conf,
        "problem": {"kind": INFERENCE, "text": entry["problem"],
                    "evidence": [{"signal_id": s.id, "type": s.signal_type, "label": catalog_entry(s.signal_type)["label"],
                                  "evidence_text": s.evidence_text, "source": s.source, "source_url": s.source_url,
                                  "kind": s.kind} for s in rank_signals(matched)[:4]]},
        "offer": {"kind": RECOMMENDATION, "text": offer_text, "deliverables": deliver},
        "pricing": {"model": svc.pricing_model, "display": _price_display(svc), "minimum": svc.minimum_price, "target_mrr": svc.target_mrr},
        "alternative": ({"service_id": follow_on.id, "service": follow_on.name, "kind": RECOMMENDATION,
                         "text": f"Then propose {follow_on.name} as ongoing support ({_price_display(follow_on)})"} if follow_on else None),
        "potential_mrr": mrr, "potential_project_value": project_value,
        "reasons": r["reasons"],
    }


def generate_offer(db: Session, lead_id: int | Lead, *, actor: str = "ai") -> dict:
    """Match services for a lead and store the top recommendation on it."""
    lead = lead_id if isinstance(lead_id, Lead) else db.get(Lead, lead_id)
    if not lead:
        raise NotFound("Lead", lead_id)
    company = lead.company
    signals = db.query(Signal).filter(Signal.company_id == company.id).all()
    services = db.query(Service).all()
    ability = ((lead.qualification or {}).get("levels") or {}).get("ability_to_pay")
    matches = match_services(company, lead.person, signals, services, lead.campaign, ability_level=ability)
    if not matches:
        return {"recommended": None, "alternatives": [],
                "message": "No evidence-based service match. Record signals with evidence (or run research) — "
                           "no generic service is recommended without evidence.",
                "next_action": "Research company"}
    best = matches[0]
    old_service = lead.recommended_service
    lead.recommended_service_id = best["service_id"]
    lead.recommended_service = best["service"]
    lead.offer = best
    lead.detected_problem = best["problem"]["text"]
    lead.potential_mrr = best["potential_mrr"]
    lead.potential_project_value = best["potential_project_value"]
    db.flush()
    if old_service != lead.recommended_service:
        audit.log(db, "service_changed" if old_service else "offer_generated",
                  f"{company.name}: recommended service {old_service or '—'} → {lead.recommended_service} "
                  f"(potential MRR ${lead.potential_mrr:,.0f})", entity_type="lead", entity_id=lead.id, actor=actor,
                  details={"score": best["score"], "confidence": best["confidence"],
                           "signals": [e["signal_id"] for e in best["problem"]["evidence"]]})
    return {"recommended": best, "alternatives": matches[1:3]}
