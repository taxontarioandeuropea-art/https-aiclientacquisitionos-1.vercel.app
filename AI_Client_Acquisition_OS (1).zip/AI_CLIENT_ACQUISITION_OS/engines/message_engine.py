"""Message engine: Observation -> Business implication -> Relevant service -> Specific value -> Low-friction CTA.

Messages are composed only from stored, evidence-backed data. With no evidence the engine refuses to write
(no generic 'I help businesses with accounting' spam). Output is always a DRAFT: the user approves and sends.
"""
from __future__ import annotations

import re
from typing import Any, Optional

from sqlalchemy.orm import Session

from ai.base import AIProviderError, BaseAIProvider
from ai.providers import get_provider
from core import audit
from core.constants import FACT
from core.errors import InsufficientEvidence, NotFound
from core.settings_store import get_settings
from core.utils import safe_format
from database.models import Campaign, Company, Lead, OutreachMessage, Person, Service, Signal
from engines.offer_engine import generate_offer
from engines.signal_engine import SIGNAL_CATALOG, catalog_entry, rank_signals

FOLLOWUP_TYPES = {"bump": "Short reminder", "value": "Value-based follow-up", "final": "Final follow-up"}


def _lc(s: str) -> str:
    """Lower-case the first letter unless the word is an acronym (QBO, ERP ...)."""
    return s if (not s or (len(s) > 1 and s[1].isupper())) else s[0].lower() + s[1:]


def _natural_join(items: list[str]) -> str:
    items = [_lc(i.strip()) for i in items if i and i.strip()]
    if len(items) <= 1:
        return "".join(items)
    return ", ".join(items[:-1]) + " and " + items[-1]


def _first_name(person: Optional[Person]) -> str:
    if not person:
        return ""
    return (person.first_name or (person.full_name or "").split(" ")[0]).strip()


def _evidence_item(s: Signal) -> dict:
    return {"signal_id": s.id, "type": s.signal_type, "label": catalog_entry(s.signal_type)["label"],
            "evidence_text": s.evidence_text, "source": s.source, "source_url": s.source_url, "kind": s.kind}


def _observation(company: Company, sig: Signal) -> tuple[str, str]:
    """(full sentence, short clause) built from the signal — never from thin air."""
    entry = catalog_entry(sig.signal_type)
    lead_in = "I noticed that" if sig.kind == FACT else "It looks like"
    if sig.signal_type not in SIGNAL_CATALOG:
        clause = f"has this on record: {sig.description.rstrip('.')}"
    else:
        clause = entry["observation"]
    return f"{lead_in} {company.name} {clause}", clause


def _signature(user: dict) -> tuple[str, list[str]]:
    warnings: list[str] = []
    sig = (user.get("signature") or "").strip()
    if sig:
        return sig, warnings
    name = (user.get("name") or "").strip()
    if not name:
        warnings.append("Your name/signature is not set (Settings → User); a placeholder was used.")
        name = "[Your name]"
    lines = [name] + [x for x in [user.get("role"), user.get("company")] if x]
    return "\n".join(lines), warnings


def _industry_phrase(company: Company, campaign: Optional[Campaign]) -> str:
    base = (campaign.industry if campaign and campaign.industry else company.industry or "").split("/")[-1].strip().lower()
    return f"{base} companies" if base else "companies like yours"


def compose_variants(company: Company, person: Optional[Person], campaign: Optional[Campaign], offer: dict,
                     service: Optional[Service], signals: list[Signal], user: dict, channel: str = "email") -> list[dict]:
    """Pure composition. `signals` must already be ranked; the first is the observation."""
    if not signals:
        raise InsufficientEvidence("No signals to personalise from", operation="generate message",
                                   suggestion="Run research or add a signal with evidence first.")
    primary = signals[0]
    obs_sentence, obs_clause = _observation(company, primary)
    entry = catalog_entry(primary.signal_type)
    implication = entry["implication"]
    svc_name = offer["service"]
    deliverables = offer["offer"].get("deliverables") or []
    industry = _industry_phrase(company, campaign)
    first = _first_name(person)
    greeting = f"Hi {first}," if first else "Hello,"
    sign, warnings = _signature(user)
    if channel == "email" and not (person and person.email):
        warnings.append("No email address on file for this contact — find a verified one; do not guess.")
    if not person:
        warnings.append("No contact is attached to this lead.")
    service_line = (safe_format(service.message_template, first_name=first, company=company.name, industry=industry,
                                service=svc_name, deliverables=_natural_join(deliverables))
                    if service and service.message_template else f"I work with {industry} on {svc_name.lower()}.")
    value_line = (f"In practice that means {_natural_join(deliverables)}." if deliverables else
                  (service.description.split(".")[0] + "." if service and service.description else ""))
    cta_a = f"Would it be useful to compare how {company.name} handles this today with a more structured approach?"
    cta_b = "Open to a 15-minute call in the next week or two to see whether it is relevant?"
    topic = implication.split(",")[0]
    evidence = [_evidence_item(s) for s in signals[:2]]

    def subject(kind: int) -> Optional[str]:
        if channel != "email":
            return None
        return [f"{svc_name} for {company.name}", f"Question about {company.name}'s {topic}", f"{company.name}: {svc_name.lower()}"][kind]

    v1 = "\n\n".join(x for x in [greeting,
                                  f"{obs_sentence}. That usually creates pressure around {implication}.",
                                  f"{service_line} {value_line}".strip(), cta_a, sign] if x)
    v2 = "\n\n".join([greeting,
                      f"Quick question: as {company.name} {obs_clause}, how are you handling {implication}?",
                      f"{service_line} {value_line}".strip(), cta_b, sign])
    v3 = "\n\n".join([greeting, f"{obs_sentence}. {service_line} Worth a quick conversation?", sign])
    if channel != "email":
        short_sign = sign.split("\n")[0]
        v1 = "\n\n".join([greeting, f"{obs_sentence}. {service_line} {cta_b}", short_sign])
        v2 = "\n\n".join([greeting, f"Quick question: as {company.name} {obs_clause}, how are you handling {implication}?", short_sign])
        v3 = "\n\n".join([greeting, f"{obs_sentence}. {service_line} Worth a quick conversation?", short_sign])
    out = [
        {"template_key": "observation_led", "label": "Observation-led", "subject": subject(0), "body": v1},
        {"template_key": "question_led", "label": "Question-led", "subject": subject(1), "body": v2},
        {"template_key": "brief_direct", "label": "Brief and direct", "subject": subject(2), "body": v3},
    ]
    for v in out:
        v["evidence"] = evidence
        v["warnings"] = list(warnings) + ([f"LinkedIn-style message is {len(v['body'])} characters; consider trimming."]
                                          if channel == "linkedin" and len(v["body"]) > 600 else [])
    return out


def compose_followup(company: Company, person: Optional[Person], offer: dict, signals: list[Signal], user: dict,
                     ftype: str, initial_subject: Optional[str], channel: str = "email") -> dict:
    primary = signals[0]
    _, clause = _observation(company, primary)
    entry = catalog_entry(primary.signal_type)
    first = _first_name(person)
    greeting = f"Hi {first}," if first else "Hello,"
    sign, warnings = _signature(user)
    deliverables = offer["offer"].get("deliverables") or []
    svc = offer["service"].lower()
    if ftype == "value":
        text = (f"One more thought on {entry['implication']}: companies in a similar position usually benefit most from "
                f"{_natural_join(deliverables) or svc}. I'm happy to walk through how that would look for {company.name} — "
                "open to a short call?")
    elif ftype == "final":
        text = (f"I don't want to fill your inbox, so this is my last note. If {entry['implication'].split(',')[0]} becomes a "
                "priority, just reply and we can pick it up then. All the best.")
    else:
        text = (f"Following up on my earlier note — I noticed {company.name} {clause}. If {svc} is on your radar, "
                "I'd be glad to share how I would approach it. Is that worth a quick chat?")
    return {"template_key": f"followup_{ftype}", "label": FOLLOWUP_TYPES.get(ftype, "Follow-up"),
            "subject": initial_subject if channel == "email" else None,
            "body": "\n\n".join([greeting, text, sign]), "evidence": [_evidence_item(primary)], "warnings": warnings}


# ------------------------------------------------------------------ AI polish
_AI_SYSTEM = ("You are an editor for B2B outreach messages. Improve flow and tone only. Use ONLY the facts already in "
              "the draft. Do not add new claims, numbers, names, dates, links, promises or urgency. Keep every fact and the "
              "call to action. Keep it under 130 words. Return only the message body.")


def _new_facts_introduced(original: str, polished: str) -> bool:
    nums = lambda t: set(re.findall(r"\d[\d,.]*", t))
    if nums(polished) - nums(original):
        return True
    return bool(re.search(r"https?://|www\.", polished)) and not re.search(r"https?://|www\.", original)


def polish_with_ai(provider: BaseAIProvider, variant: dict, ai_settings: dict) -> Optional[dict]:
    """Returns a polished copy or None when the provider output fails the no-new-facts guard."""
    try:
        text = provider.generate(_AI_SYSTEM, variant["body"], temperature=float(ai_settings.get("temperature", 0.4)),
                                 max_tokens=int(ai_settings.get("max_tokens", 700)))
    except AIProviderError:
        raise
    if not text or _new_facts_introduced(variant["body"], text) or len(text) < 40:
        return None
    return {**variant, "template_key": variant["template_key"] + "_ai", "label": variant["label"] + " (AI-polished)",
            "body": text, "ai": True}


# ------------------------------------------------------------------ persistence
def _load(db: Session, lead_id: int) -> tuple[Lead, Company, Optional[Person], list[Signal]]:
    lead = db.get(Lead, lead_id)
    if not lead:
        raise NotFound("Lead", lead_id)
    signals = rank_signals(db.query(Signal).filter(Signal.company_id == lead.company_id).all())
    return lead, lead.company, lead.person, signals


def _ensure_offer(db: Session, lead: Lead) -> dict:
    if not lead.offer:
        res = generate_offer(db, lead)
        if not res.get("recommended"):
            raise InsufficientEvidence("No evidence-based service match for this lead", operation="generate message",
                                       cause=res.get("message"), suggestion="Run research or add a signal, then generate an offer.")
    return lead.offer


def _save(db: Session, lead: Lead, v: dict, channel: str, step: int, actor: str) -> Optional[OutreachMessage]:
    dup = db.query(OutreachMessage).filter(OutreachMessage.lead_id == lead.id, OutreachMessage.sequence_step == step,
                                           OutreachMessage.status == "draft", OutreachMessage.body == v["body"]).first()
    if dup:
        return None
    person = lead.person
    recipient = (person.email if channel == "email" and person and person.email else
                 person.linkedin_url if channel == "linkedin" and person and person.linkedin_url else None)
    m = OutreachMessage(lead_id=lead.id, campaign_id=lead.campaign_id, person_id=person.id if person else None,
                        channel=channel, recipient=recipient, subject=v.get("subject"), body=v["body"],
                        template_key=v["template_key"], sequence_step=step, personalization_evidence=v["evidence"],
                        status="draft", ai_assisted=bool(v.get("ai")), warnings=v.get("warnings", []), is_demo=lead.is_demo)
    db.add(m)
    db.flush()
    audit.log(db, "message_generated", f"{lead.company.name}: {v['label']} draft ({channel}, step {step})",
              entity_type="message", entity_id=m.id, actor="ai" if v.get("ai") else actor,
              details={"lead_id": lead.id, "template": v["template_key"], "evidence": [e["signal_id"] for e in v["evidence"]]})
    return m


def generate_messages(db: Session, lead_id: int, *, channel: Optional[str] = None, use_ai: bool = False,
                      actor: str = "ai") -> list[OutreachMessage]:
    lead, company, person, signals = _load(db, lead_id)
    settings = get_settings(db)
    if not signals:
        raise InsufficientEvidence(
            "No evidence available to personalise this message", operation="generate message",
            cause="This company has no recorded signals. The app will not write generic outreach.",
            suggestion="Run research on the company or add a signal with its evidence and source.")
    offer = _ensure_offer(db, lead)
    service = db.get(Service, offer["service_id"])
    channel = channel or (settings["outreach"].get("default_channels") or ["email"])[0]
    variants = compose_variants(company, person, lead.campaign, offer, service, signals, settings["user"], channel)
    if use_ai:
        provider = get_provider(settings["ai"])
        extra = []
        for v in variants[:2]:
            p = polish_with_ai(provider, v, settings["ai"])
            if p:
                extra.append(p)
        variants += extra
    saved = [m for v in variants if (m := _save(db, lead, v, channel, 0, actor))]
    return saved


def generate_followup(db: Session, lead_id: int, step: int, *, channel: Optional[str] = None, actor: str = "ai") -> Optional[OutreachMessage]:
    lead, company, person, signals = _load(db, lead_id)
    settings = get_settings(db)
    if not signals:
        raise InsufficientEvidence("No evidence available to personalise this follow-up", operation="generate follow-up",
                                   suggestion="Add or research signals first.")
    offer = _ensure_offer(db, lead)
    from engines.followup_engine import sequence_for
    seq = sequence_for(lead.campaign, settings)
    if step < 1 or step > len(seq):
        raise InsufficientEvidence(f"Follow-up step {step} is outside this campaign's sequence ({len(seq)} steps)",
                                   operation="generate follow-up", suggestion="Adjust the sequence on the campaign.")
    ftype = seq[step - 1].get("type", "bump")
    initial = (db.query(OutreachMessage).filter(OutreachMessage.lead_id == lead.id, OutreachMessage.sequence_step == 0)
               .order_by(OutreachMessage.id).first())
    channel = channel or seq[step - 1].get("channel") or (initial.channel if initial else "email")
    v = compose_followup(company, person, offer, signals, settings["user"], ftype, initial.subject if initial else None, channel)
    return _save(db, lead, v, channel, step, actor)
