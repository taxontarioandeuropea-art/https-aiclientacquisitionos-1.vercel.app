"""Follow-up engine. Day 0 initial -> configurable follow-ups -> nurture decision. Never spams:
the sequence stops on reply, on terminal stages and at the configured maximum."""
from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Optional

from sqlalchemy.orm import Session

from core import audit
from core.errors import NotFound
from core.settings_store import get_settings
from core.utils import today as _today, utcnow
from database.models import Campaign, Lead, OutreachMessage, Task
from services import task_service


def default_sequence(settings: dict) -> list[dict]:
    out = settings["outreach"]
    intervals = [int(x) for x in (out.get("followup_intervals") or [])]
    n = len(intervals)
    types = ["bump"] if n == 1 else ["bump", "final"] if n == 2 else ["bump"] + ["value"] * (n - 2) + ["final"] if n else []
    ch = (out.get("default_channels") or ["email"])[0]
    return [{"day": d, "type": t, "channel": ch} for d, t in zip(intervals, types)]


def sequence_for(campaign: Optional[Campaign], settings: dict) -> list[dict]:
    seq = list((campaign.followup_sequence if campaign else None) or []) or default_sequence(settings)
    clean = []
    for s in seq:
        try:
            clean.append({"day": int(s["day"]), "type": s.get("type", "bump"), "channel": s.get("channel") or "email"})
        except (KeyError, TypeError, ValueError):
            continue
    clean.sort(key=lambda s: s["day"])
    return clean[: int(settings["outreach"].get("max_followups", 3))]


def initial_sent_date(db: Session, lead: Lead) -> Optional[date]:
    m = (db.query(OutreachMessage).filter(OutreachMessage.lead_id == lead.id, OutreachMessage.sequence_step == 0,
                                          OutreachMessage.sent_at.isnot(None)).order_by(OutreachMessage.sent_at).first())
    return m.sent_at.date() if m else None


def mark_sent(db: Session, message_id: int, *, sent_at: Optional[datetime] = None, actor: str = "user") -> OutreachMessage:
    from services import crm_service
    m = db.get(OutreachMessage, message_id)
    if not m:
        raise NotFound("Message", message_id)
    lead = m.lead
    m.status, m.sent_at = "sent", sent_at or utcnow()
    if not m.approved_at:
        m.approved_at = m.sent_at
    itype = m.channel if m.channel in ("email", "linkedin") else ("form" if m.channel == "contact_form" else "other")
    crm_service.log_interaction(db, lead_id=lead.id, type=itype, direction="outbound", subject=m.subject,
                                body=m.body, occurred_at=m.sent_at, message_id=m.id, person_id=m.person_id, actor=actor)
    audit.log(db, "message_sent", f"{lead.company.name}: {m.channel} message marked as sent (step {m.sequence_step})",
              entity_type="message", entity_id=m.id, actor=actor, details={"lead_id": lead.id, "template": m.template_key})
    if lead.status in ("NEW", "RESEARCHED", "QUALIFIED"):
        crm_service.move_stage(db, lead.id, "CONTACTED", actor=actor, note="Message sent")
    # a follow-up task for this step is now satisfied
    for t in db.query(Task).filter(Task.dedupe_key == f"lead:{lead.id}:followup:{m.sequence_step}", Task.status == "open").all():
        t.status, t.completed_at = "done", utcnow()
    if lead.status == "CONTACTED":
        schedule_next(db, lead, m.sequence_step)
    db.flush()
    return m


def schedule_next(db: Session, lead: Lead, sent_step: int) -> Optional[Task]:
    settings = get_settings(db)
    seq = sequence_for(lead.campaign, settings)
    base = initial_sent_date(db, lead) or _today()
    if sent_step < len(seq):
        nxt = seq[sent_step]
        due = base + timedelta(days=nxt["day"])
        label = {"bump": "short reminder", "value": "value-based follow-up", "final": "final follow-up"}.get(nxt["type"], "follow-up")
        person = lead.person.full_name if lead.person and lead.person.full_name else lead.company.name
        t = task_service.create_task(
            db, f"Follow-up #{sent_step + 1} ({label}) to {person} — {lead.company.name}", due_date=due,
            task_type="follow_up", priority=lead.overall_priority or "MEDIUM", lead_id=lead.id, auto_generated=True,
            dedupe_key=f"lead:{lead.id}:followup:{sent_step + 1}", is_demo=lead.is_demo, actor="system")
        lead.next_action, lead.next_action_date = t.title[:255], due
        return t
    wait = int(settings["outreach"].get("nurture_wait_days", 7))
    t = task_service.create_task(
        db, f"Sequence finished for {lead.company.name} — decide: move to Nurture?",
        due_date=_today() + timedelta(days=wait), task_type="update_crm", priority="LOW", lead_id=lead.id,
        auto_generated=True, dedupe_key=f"lead:{lead.id}:followup:end", is_demo=lead.is_demo, actor="system")
    lead.next_action, lead.next_action_date = t.title[:255], t.due_date
    return t


def on_reply(db: Session, lead: Lead, *, message: Optional[OutreachMessage] = None, actor: str = "user") -> None:
    """A reply stops the sequence. Idempotent."""
    from services import crm_service
    now = utcnow()
    m = message or (db.query(OutreachMessage).filter(OutreachMessage.lead_id == lead.id, OutreachMessage.status == "sent")
                    .order_by(OutreachMessage.sent_at.desc()).first())
    if m and m.status != "replied":
        m.status, m.replied_at = "replied", now
    for t in db.query(Task).filter(Task.lead_id == lead.id, Task.status == "open", Task.task_type == "follow_up",
                                   Task.auto_generated.is_(True), Task.dedupe_key.like(f"lead:{lead.id}:followup:%")).all():
        t.status = "cancelled"
    lead.last_interaction_at = now
    if lead.status in ("NEW", "RESEARCHED", "QUALIFIED", "CONTACTED"):
        crm_service.move_stage(db, lead.id, "REPLIED", actor=actor, note="Reply received")


def mark_replied(db: Session, message_id: int, actor: str = "user") -> OutreachMessage:
    m = db.get(OutreachMessage, message_id)
    if not m:
        raise NotFound("Message", message_id)
    on_reply(db, m.lead, message=m, actor=actor)
    return m


def due_followups(db: Session, on: Optional[date] = None) -> list[Task]:
    on = on or _today()
    return (db.query(Task).filter(Task.status == "open", Task.task_type == "follow_up", Task.due_date <= on)
            .order_by(Task.due_date).all())
