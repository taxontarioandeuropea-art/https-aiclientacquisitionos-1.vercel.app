#!/usr/bin/env bash
# Double-click this file on macOS (or run `./start.command` in a terminal on macOS/Linux) to
# set up and launch AI Client Acquisition OS with no other steps.
set -e
cd "$(dirname "${BASH_SOURCE[0]}")"

echo "============================================"
echo "  AI Client Acquisition OS"
echo "============================================"
echo

# --- Find a real Python 3 interpreter --------------------------------------
PYBIN=""
if command -v python3 >/dev/null 2>&1; then
    PYBIN=python3
elif command -v python >/dev/null 2>&1; then
    PYBIN=python
else
    echo "Could not find Python on this computer."
    echo "Install it from https://python.org/downloads, then run this file again."
    read -n 1 -s -r -p "Press any key to close..."
    exit 1
fi

# --- Create an isolated environment the first time --------------------------
# Everything installs into .venv, inside this folder, so it never touches or
# conflicts with any other Python project or install on this computer.
if [ ! -x ".venv/bin/python" ]; then
    echo "Setting up the app for the first time - this can take a minute..."
    "$PYBIN" -m venv .venv
fi

VENV_PY=".venv/bin/python"

echo "Checking dependencies..."
"$VENV_PY" -m pip install --quiet --upgrade pip
"$VENV_PY" -m pip install --quiet -r requirements.txt

# --- Open the browser automatically a couple of seconds after start ---------
(
    sleep 2
    if command -v open >/dev/null 2>&1; then
        open http://127.0.0.1:8000 2>/dev/null || true
    elif command -v xdg-open >/dev/null 2>&1; then
        xdg-open http://127.0.0.1:8000 2>/dev/null || true
    fi
) &

echo
echo "Starting the app - this window is the server. Close it, or press Ctrl+C, to stop."
echo
"$VENV_PY" app.py

echo
read -n 1 -s -r -p "The server has stopped. Press any key to close..."
echo
