"""JSON shapes returned by the API. Kept in one place so UI and exports agree."""
from __future__ import annotations

from typing import Optional

from core.constants import STAGE_LABELS
from database.models import Company, Interaction, Lead, OutreachMessage, Person
from engines.signal_engine import catalog_entry, rank_signals


def person_dict(p: Optional[Person]) -> Optional[dict]:
    return p.as_dict() if p else None


def company_brief(c: Company) -> dict:
    return {"id": c.id, "name": c.name, "website": c.website, "country": c.country, "industry": c.industry,
            "employees": c.employees, "is_demo": c.is_demo}


def lead_dict(lead: Lead, signals_by_company: Optional[dict] = None) -> dict:
    q = lead.qualification or {}
    levels = q.get("levels") or {}
    dims = {}
    for key, score in (("fit", lead.fit_score), ("need", lead.need_score), ("signal", lead.signal_score),
                       ("ability_to_pay", lead.ability_to_pay_score), ("contactability", lead.contactability_score)):
        dims[key] = {"score": score, "level": levels.get(key, "UNKNOWN")}
    sigs = (signals_by_company or {}).get(lead.company_id) or []
    top = rank_signals(sigs)[:1]
    p = lead.person
    return {
        "id": lead.id, "status": lead.status, "stage": lead.status, "stage_label": STAGE_LABELS.get(lead.status, lead.status),
        "company": company_brief(lead.company),
        "person": ({"id": p.id, "full_name": p.full_name, "title": p.title, "email": p.email,
                    "decision_maker_level": p.decision_maker_level} if p else None),
        "campaign": ({"id": lead.campaign.id, "name": lead.campaign.name} if lead.campaign else None),
        "dimensions": dims, "overall_priority": lead.overall_priority, "opportunity_score": lead.opportunity_score,
        "potential_mrr": lead.potential_mrr or 0.0, "potential_project_value": lead.potential_project_value or 0.0,
        "actual_mrr": lead.actual_mrr, "recommended_service": lead.recommended_service,
        "recommended_service_id": lead.recommended_service_id, "detected_problem": lead.detected_problem,
        "primary_signal": catalog_entry(top[0].signal_type)["label"] if top else None,
        "primary_signal_type": lead.primary_signal_type,
        "next_action": lead.next_action, "next_action_date": lead.next_action_date.isoformat() if lead.next_action_date else None,
        "last_interaction_at": lead.last_interaction_at.isoformat() if lead.last_interaction_at else None,
        "qualified_at": lead.qualified_at.isoformat() if lead.qualified_at else None,
        "created_at": lead.created_at.isoformat() if lead.created_at else None,
        "suggested_stage": q.get("suggested_stage"), "lost_reason": lead.lost_reason, "notes": lead.notes,
        "is_demo": lead.is_demo,
    }


def message_dict(m: OutreachMessage) -> dict:
    d = m.as_dict()
    d["company"] = m.lead.company.name if m.lead else None
    return d


def interaction_dict(i: Interaction) -> dict:
    d = i.as_dict()
    return d
