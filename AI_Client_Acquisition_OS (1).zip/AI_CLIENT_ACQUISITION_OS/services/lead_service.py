"""Leads: creation, editing, filtering and ingestion of LeadRecords from any source (with deduplication)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Optional

from sqlalchemy import case, or_
from sqlalchemy.orm import Session

from core import audit
from core.constants import ALL_STAGES
from core.errors import AppError, NotFound, ValidationProblem
from core.utils import (normalize_domain, normalize_email, normalize_linkedin, normalize_company_name, parse_date,
                        parse_number, sanitize_text, utcnow)
from database.models import (Campaign, Company, Interaction, Lead, OutreachMessage, Person, Service, Signal, StageHistory,
                             Task)
from engines.offer_engine import estimate_mrr
from engines.signal_engine import add_signal, serialize_signal
from services import company_service, serializers, task_service


def create_lead(db: Session, *, company_id: int, campaign_id: Optional[int] = None, person_id: Optional[int] = None,
                actor: str = "user", is_demo: Optional[bool] = None, log: bool = True,
                created_at: Optional[datetime] = None) -> tuple[Lead, bool]:
    company = company_service.get_company(db, company_id)
    if campaign_id is not None and not db.get(Campaign, campaign_id):
        raise NotFound("Campaign", campaign_id)
    if person_id is not None:
        person = db.get(Person, person_id)
        if not person or person.company_id != company_id:
            raise ValidationProblem("The selected contact does not belong to this company", operation="create lead")
    existing = db.query(Lead).filter(Lead.company_id == company_id,
                                     Lead.campaign_id.is_(None) if campaign_id is None else Lead.campaign_id == campaign_id).first()
    if existing:
        if person_id and not existing.person_id:
            existing.person_id = person_id
        return existing, False
    now = created_at or utcnow()
    lead = Lead(company_id=company_id, campaign_id=campaign_id, person_id=person_id, status="NEW",
                is_demo=company.is_demo if is_demo is None else is_demo, created_at=now)
    db.add(lead)
    db.flush()
    db.add(StageHistory(lead_id=lead.id, from_stage=None, to_stage="NEW", changed_at=now, actor=actor, note="Lead created"))
    db.flush()
    db.refresh(lead)
    task_service.generate_tasks_for_lead(db, lead)
    if log:
        audit.log(db, "lead_created", f"Lead created: {company.name}", entity_type="lead", entity_id=lead.id, actor=actor,
                  details={"campaign_id": campaign_id})
    return lead, True


def get_lead(db: Session, lead_id: int) -> Lead:
    lead = db.get(Lead, lead_id)
    if not lead:
        raise NotFound("Lead", lead_id)
    return lead


def update_lead(db: Session, lead_id: int, data: dict[str, Any], *, actor: str = "user") -> Lead:
    lead = get_lead(db, lead_id)
    changes: dict[str, Any] = {}
    if "person_id" in data:
        pid = data["person_id"]
        if pid is not None:
            p = db.get(Person, pid)
            if not p or p.company_id != lead.company_id:
                raise ValidationProblem("The selected contact does not belong to this company", operation="update lead")
        if lead.person_id != pid:
            changes["person_id"] = {"from": lead.person_id, "to": pid}
            lead.person_id = pid
    if "campaign_id" in data and data["campaign_id"] != lead.campaign_id:
        cid = data["campaign_id"]
        if cid is not None and not db.get(Campaign, cid):
            raise NotFound("Campaign", cid)
        clash = db.query(Lead).filter(Lead.company_id == lead.company_id, Lead.campaign_id == cid, Lead.id != lead.id).first()
        if clash:
            raise AppError("This company already has a lead in that campaign", operation="update lead", status_code=409,
                           suggestion="Open the existing lead instead.")
        changes["campaign_id"] = {"from": lead.campaign_id, "to": cid}
        lead.campaign_id = cid
    for k in ("next_action", "notes", "detected_problem"):
        if k in data and data[k] != getattr(lead, k):
            new = sanitize_text(data[k], 4000 if k != "next_action" else 255) or None
            changes[k] = {"from": getattr(lead, k), "to": new}
            setattr(lead, k, new)
    if "next_action_date" in data:
        d = parse_date(data["next_action_date"])
        if d != lead.next_action_date:
            changes["next_action_date"] = {"from": str(lead.next_action_date), "to": str(d)}
            lead.next_action_date = d
    if "potential_mrr" in data:
        v = parse_number(data["potential_mrr"])
        if v is not None and v < 0:
            raise ValidationProblem("MRR cannot be negative", operation="update lead")
        if v != lead.potential_mrr:
            changes["potential_mrr"] = {"from": lead.potential_mrr, "to": v}
            lead.potential_mrr = v
    if "recommended_service_id" in data and data["recommended_service_id"] != lead.recommended_service_id:
        sid = data["recommended_service_id"]
        svc = db.get(Service, sid) if sid else None
        if sid and not svc:
            raise NotFound("Service", sid)
        old = lead.recommended_service
        lead.recommended_service_id, lead.recommended_service = (svc.id, svc.name) if svc else (None, None)
        if svc and "potential_mrr" not in data:
            lead.potential_mrr = estimate_mrr(svc, ((lead.qualification or {}).get("levels") or {}).get("ability_to_pay"))
        changes["recommended_service"] = {"from": old, "to": lead.recommended_service}
        lead.offer = None            # a stored AI offer no longer matches the user's choice
    if changes:
        audit.log(db, "lead_updated", f"Lead edited: {lead.company.name} ({', '.join(changes)})", entity_type="lead",
                  entity_id=lead.id, actor=actor, details={"changes": changes})
    db.flush()
    return lead


def delete_lead(db: Session, lead_id: int, actor: str = "user") -> None:
    lead = get_lead(db, lead_id)
    audit.log(db, "lead_deleted", f"Lead deleted: {lead.company.name}", entity_type="lead", entity_id=lead.id, actor=actor,
              details={"snapshot": lead.as_dict()})
    db.delete(lead)


# ------------------------------------------------------------------ listing
_PRIORITY_RANK = case((Lead.overall_priority == "HIGH", 3), (Lead.overall_priority == "MEDIUM", 2),
                      (Lead.overall_priority == "LOW", 1), else_=0)
_SORTS = {"company": Company.name, "priority": _PRIORITY_RANK, "mrr": Lead.potential_mrr, "stage": Lead.status,
          "created": Lead.created_at, "updated": Lead.updated_at, "next_action_date": Lead.next_action_date,
          "fit": Lead.fit_score, "need": Lead.need_score, "signal": Lead.signal_score, "pay": Lead.ability_to_pay_score,
          "contact": Lead.contactability_score, "country": Company.country, "industry": Company.industry,
          "service": Lead.recommended_service}


def signals_by_company(db: Session, company_ids) -> dict[int, list[Signal]]:
    out: dict[int, list[Signal]] = {}
    ids = list(company_ids)
    if ids:
        for s in db.query(Signal).filter(Signal.company_id.in_(ids)).all():
            out.setdefault(s.company_id, []).append(s)
    return out


def list_leads(db: Session, *, q: Optional[str] = None, country: Optional[str] = None, industry: Optional[str] = None,
               campaign_id: Optional[int] = None, priority: Optional[str] = None, stage: Optional[str] = None,
               min_mrr: Optional[float] = None, max_mrr: Optional[float] = None, signal: Optional[str] = None,
               service: Optional[str] = None, date_from: Optional[str] = None, date_to: Optional[str] = None,
               sort: str = "priority", direction: str = "desc", limit: int = 300, offset: int = 0) -> dict:
    qry = (db.query(Lead).join(Company, Lead.company_id == Company.id)
           .outerjoin(Person, Lead.person_id == Person.id).filter(Company.archived.is_(False)))
    if q:
        like = f"%{q.strip()}%"
        qry = qry.filter(or_(Company.name.ilike(like), Person.full_name.ilike(like), Person.email.ilike(like),
                             Lead.recommended_service.ilike(like)))
    if country:
        qry = qry.filter(Company.country == country)
    if industry:
        qry = qry.filter(Company.industry.ilike(f"%{industry}%"))
    if campaign_id:
        qry = qry.filter(Lead.campaign_id == campaign_id)
    if priority:
        qry = qry.filter(Lead.overall_priority == priority.upper())
    if stage:
        qry = qry.filter(Lead.status == stage.upper())
    if min_mrr is not None:
        qry = qry.filter(Lead.potential_mrr >= min_mrr)
    if max_mrr is not None:
        qry = qry.filter(Lead.potential_mrr <= max_mrr)
    if signal:
        qry = qry.filter(Lead.company_id.in_(db.query(Signal.company_id).filter(Signal.signal_type == signal)))
    if service:
        qry = qry.filter(Lead.recommended_service.ilike(f"%{service}%"))
    d1, d2 = parse_date(date_from), parse_date(date_to)
    if d1:
        qry = qry.filter(Lead.created_at >= datetime.combine(d1, datetime.min.time()))
    if d2:
        qry = qry.filter(Lead.created_at < datetime.combine(d2 + timedelta(days=1), datetime.min.time()))
    total = qry.count()
    col = _SORTS.get(sort, _PRIORITY_RANK)
    qry = qry.order_by(col.desc() if direction == "desc" else col.asc(), Lead.id)
    rows = qry.offset(offset).limit(limit).all()
    sigs = signals_by_company(db, {l.company_id for l in rows})
    return {"items": [serializers.lead_dict(l, sigs) for l in rows], "total": total}


def lead_detail(db: Session, lead_id: int) -> dict:
    lead = get_lead(db, lead_id)
    sigs = signals_by_company(db, [lead.company_id])
    d = serializers.lead_dict(lead, sigs)
    d["qualification"] = lead.qualification
    d["offer"] = lead.offer
    d["signals"] = [serialize_signal(s) for s in sorted(sigs.get(lead.company_id, []), key=lambda s: s.date_detected or s.created_at, reverse=True)]
    d["messages"] = [serializers.message_dict(m) for m in sorted(lead.messages, key=lambda m: (m.sequence_step, m.id))]
    d["tasks"] = [task_service.serialize_task(t) for t in sorted(lead.tasks, key=lambda t: (t.status != "open", t.due_date or datetime.max.date()))]
    d["interactions"] = [serializers.interaction_dict(i) for i in
                         db.query(Interaction).filter(Interaction.lead_id == lead.id).order_by(Interaction.occurred_at.desc()).all()]
    d["history"] = [{"from": h.from_stage, "to": h.to_stage, "at": h.changed_at.isoformat(), "actor": h.actor, "note": h.note}
                    for h in lead.history]
    d["contacts"] = [p.as_dict() for p in lead.company.people]
    d["company_full"] = {k: getattr(lead.company, k) for k in ("id", "name", "website", "country", "state", "city", "industry",
                         "subindustry", "employees", "accounting_software", "technology_stack", "growth_status", "description")}
    return d


# ---------------------------------------------------------------- ingestion
@dataclass
class IngestReport:
    created_companies: int = 0
    matched_companies: int = 0
    created_people: int = 0
    created_leads: int = 0
    existing_leads: int = 0
    signals_added: int = 0
    flagged_duplicates: list[dict] = field(default_factory=list)
    skipped: int = 0
    errors: list[dict] = field(default_factory=list)
    company_ids: list[int] = field(default_factory=list)
    lead_ids: list[int] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}

    def merge(self, other: "IngestReport") -> None:
        for k in ("created_companies", "matched_companies", "created_people", "created_leads", "existing_leads", "signals_added"):
            setattr(self, k, getattr(self, k) + getattr(other, k))
        for k in ("flagged_duplicates", "company_ids", "lead_ids"):
            getattr(self, k).extend(getattr(other, k))


def _find_existing_company(db: Session, clean: dict[str, Any]) -> Optional[Company]:
    dom = normalize_domain(clean.get("website"))
    if dom:
        c = db.query(Company).filter(Company.domain == dom, Company.archived.is_(False)).first()
        if c:
            return c
    nn = normalize_company_name(clean.get("name"))
    if nn and clean.get("country") and clean.get("city"):
        return (db.query(Company).filter(Company.normalized_name == nn, Company.country == clean["country"],
                                         Company.city == clean["city"], Company.archived.is_(False)).first())
    return None


def _fill_empty(c: Company, clean: dict[str, Any]) -> None:
    for k, v in clean.items():
        if v not in (None, "", []) and getattr(c, k) in (None, "", []):
            setattr(c, k, v)
        elif k == "technology_stack" and v:
            c.technology_stack = list(dict.fromkeys((c.technology_stack or []) + v))
    c.domain = normalize_domain(c.website) or c.domain


def _resolve_person(db: Session, company: Company, pdata: dict[str, Any], report: IngestReport) -> Optional[Person]:
    if not pdata:
        return None
    clean = company_service.clean_person(pdata)
    if not (clean.get("full_name") or clean.get("first_name") or clean.get("last_name") or clean.get("email")):
        return None
    email, li = normalize_email(clean.get("email")), normalize_linkedin(clean.get("linkedin_url"))
    name = (clean.get("full_name") or " ".join(x for x in [clean.get("first_name"), clean.get("last_name")] if x)).strip().lower()
    for p in company.people:
        if (email and normalize_email(p.email) == email) or (li and normalize_linkedin(p.linkedin_url) == li) or \
           (name and (p.full_name or "").strip().lower() == name):
            for k, v in clean.items():
                if v not in (None, "") and getattr(p, k) in (None, ""):
                    setattr(p, k, v)
            return p
    p = company_service.create_person(db, company.id, clean, actor="system", log=False)
    report.created_people += 1
    return p


def ingest_records(db: Session, records, *, campaign_id: Optional[int] = None, source_label: str = "import",
                   create_leads: bool = True, actor: str = "user", is_demo: bool = False) -> IngestReport:
    """Turn LeadRecords into companies/contacts/leads. Never merges uncertain companies: exact domain (or exact
    name + country + city) reuses a record; anything merely similar is created separately and flagged."""
    rep = IngestReport()
    if campaign_id is not None and not db.get(Campaign, campaign_id):
        raise NotFound("Campaign", campaign_id)
    campaign_names = {c.name.lower(): c.id for c in db.query(Campaign).all()}
    for rec in records:
        row = rec.row
        if rec.errors:
            rep.errors.append({"row": row, "message": "; ".join(rec.errors)}); rep.skipped += 1
            continue
        row_rep = IngestReport()
        try:
            with db.begin_nested():
                lead_meta = rec.company.pop("_lead", {}) if isinstance(rec.company, dict) else {}
                clean = company_service.clean_company(rec.company)
                if not clean.get("name"):
                    raise ValidationProblem("Company name is missing")
                clean.setdefault("source", rec.source)
                company = _find_existing_company(db, clean)
                if company:
                    _fill_empty(company, clean)
                    row_rep.matched_companies += 1
                else:
                    matches = company_service.find_matches_for(db, clean)
                    company = company_service.create_company(db, clean, source=rec.source, actor=actor, is_demo=is_demo, log=False)
                    row_rep.created_companies += 1
                    for m in matches:
                        row_rep.flagged_duplicates.append({"row": row, "new_company_id": company.id, "new_name": company.name,
                                                       "existing_company_id": m["company_id"], "existing_name": m["name"],
                                                       "score": m["score"], "reasons": m["reasons"]})
                row_rep.company_ids.append(company.id)
                person = _resolve_person(db, company, rec.person, row_rep)
                for s in rec.signals:
                    _, created = add_signal(db, company.id, s["type"], s["evidence_text"], s.get("source") or rec.source,
                                            source_url=s.get("source_url"), confidence=s.get("confidence", 0.6), kind=s.get("kind"),
                                            origin=s.get("origin", "import"), verified=bool(s.get("verified")), is_demo=is_demo, actor=actor)
                    row_rep.signals_added += int(created)
                cid = campaign_names.get((lead_meta.get("campaign") or "").lower(), campaign_id) if lead_meta else campaign_id
                if create_leads and (cid is not None or campaign_id is None):
                    lead, created = create_lead(db, company_id=company.id, campaign_id=cid, person_id=person.id if person else None,
                                                actor=actor, is_demo=is_demo, log=False)
                    row_rep.lead_ids.append(lead.id)
                    row_rep.created_leads += int(created)
                    row_rep.existing_leads += int(not created)
                    st = (lead_meta.get("stage") or "").upper().replace(" ", "_")
                    if created and st in ALL_STAGES and st not in ("NEW", "WON", "LOST"):
                        lead.status = st
                        db.add(StageHistory(lead_id=lead.id, from_stage="NEW", to_stage=st, actor="import", note="Stage imported"))
                    mrr = parse_number(lead_meta.get("potential_mrr")) if lead_meta else None
                    if created and mrr:
                        lead.potential_mrr = mrr
            rep.merge(row_rep)
        except (AppError, ValueError) as exc:
            rep.errors.append({"row": row, "message": str(exc)}); rep.skipped += 1
    audit.log(db, "import", f"Imported from {source_label}: {rep.created_companies} new companies, {rep.matched_companies} matched, "
                            f"{rep.created_leads} new leads, {len(rep.errors)} errors", actor=actor,
              details={k: v for k, v in rep.as_dict().items() if k not in ("company_ids", "lead_ids", "flagged_duplicates", "errors")}
                      | {"flagged_duplicates": len(rep.flagged_duplicates), "errors": rep.errors[:20]})
    return rep
