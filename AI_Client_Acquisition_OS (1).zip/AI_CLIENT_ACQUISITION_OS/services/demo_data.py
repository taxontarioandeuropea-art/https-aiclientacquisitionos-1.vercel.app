"""Demo mode. Every record is FICTIONAL, flagged is_demo=True and can be removed in one click without touching
real data. Company names use reserved '.example' domains. Scores, service matches, messages and tasks are produced
by the real engines from the demo signals — nothing about qualification or offers is hardcoded here."""
from __future__ import annotations

from datetime import date, datetime, time, timedelta
from typing import Any, Optional

from sqlalchemy.orm import Session

from core import audit
from core.errors import InsufficientEvidence
from core.utils import today
from database.models import (Campaign, Company, Interaction, Lead, OutreachMessage, Person, Service, Signal, StageHistory, Task)
from engines import followup_engine
from engines.message_engine import generate_messages
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from engines.signal_engine import add_signal
from services import campaign_service, company_service, crm_service, lead_service, task_service

SRC = "DEMO DATA (fictional example — safe to delete)"

SERVICES = [
    dict(name="Accounting", description="Ongoing bookkeeping and accounting for owner-managed businesses.", pricing_model="monthly",
         minimum_price=600, target_mrr=1000, target_employees_min=5, target_employees_max=80,
         deliverables=["Weekly bookkeeping", "Bank and card reconciliations", "Monthly financial statements"],
         required_signals=["hiring_bookkeeper", "hiring_accountant", "accounting_vacancy", "new_contracts"],
         typical_problems=["Bookkeeping backlog", "Owner doing the books"], preferred_decision_makers=["Owner", "President"],
         message_template=None),
    dict(name="QBO Cleanup", description="One-off clean-up of a disorganised QuickBooks Online file.", pricing_model="project",
         minimum_price=2500, target_mrr=None, target_employees_min=5, target_employees_max=120, target_technology=["QuickBooks"],
         deliverables=["Complete historical cleanup and reconciliation", "Chart of accounts clean-up", "Reporting set-up"],
         required_signals=["searching_qbo_support", "public_accounting_problem", "financial_reporting_need"],
         typical_problems=["Books are disorganised", "Reports cannot be trusted"], preferred_decision_makers=["Owner", "CFO", "Controller"],
         follow_on="Controller Support"),
    dict(name="Month-End Close", description="Reliable monthly close with reconciliations and a standard reporting pack.", pricing_model="monthly",
         minimum_price=800, target_mrr=1200, target_employees_min=10, target_employees_max=150,
         deliverables=["Month-end close in a fixed number of days", "Reconciliations", "Standard reporting pack"],
         required_signals=["hiring_accountant", "accounting_vacancy", "expansion", "new_location", "rapid_growth"],
         typical_problems=["Late or inconsistent close"], preferred_decision_makers=["Owner", "CFO", "Controller"]),
    dict(name="Controller Support", description="Part-time controller: close ownership, reporting and internal controls.", pricing_model="monthly",
         minimum_price=1200, target_mrr=1800, target_employees_min=15, target_employees_max=250,
         deliverables=["Monthly close and reconciliations", "Management reporting", "Internal controls and KPI review"],
         required_signals=["hiring_controller", "hiring_finance_manager", "controller_cfo_need", "financial_reporting_vacancy",
                           "acquisition", "multiple_entities", "new_entity"],
         typical_problems=["No finance leader", "Reporting is weak for a growing company"],
         preferred_decision_makers=["Owner", "CFO", "Finance Director", "Managing Director"]),
    dict(name="CFO Support", description="Fractional CFO: forecasting, funding readiness and finance strategy.", pricing_model="monthly",
         minimum_price=2500, target_mrr=3500, target_employees_min=30, target_employees_max=400,
         deliverables=["Cash-flow forecasting", "Board and lender reporting", "Finance roadmap"],
         required_signals=["funding", "controller_cfo_need", "erp_migration", "acquisition"],
         typical_problems=["Growth needs finance leadership"], preferred_decision_makers=["CEO", "Owner", "Managing Director"]),
    dict(name="Financial Reporting", description="Management reporting packs and KPI dashboards.", pricing_model="monthly",
         minimum_price=700, target_mrr=1000, target_employees_min=10, target_employees_max=300,
         deliverables=["Monthly management report", "KPI dashboard", "Budget vs actual"],
         required_signals=["financial_reporting_need", "financial_reporting_vacancy", "funding"],
         typical_problems=["No reliable management reporting"], preferred_decision_makers=["CFO", "Finance Director", "Owner"]),
    dict(name="Accounting Automation", description="Automate invoice capture, approvals and reconciliations.", pricing_model="project",
         minimum_price=3000, target_mrr=None, target_employees_min=20, target_employees_max=400,
         deliverables=["Invoice and payables automation", "Automated bank reconciliation", "Workflow and approval set-up"],
         required_signals=["automation_need", "technology_migration", "accounting_software_implementation"],
         typical_problems=["Manual data entry across entities"], preferred_decision_makers=["CFO", "Controller", "VP Finance"],
         follow_on="Financial Reporting"),
    dict(name="Tax Support", description="Multi-entity and multi-state/country tax compliance support.", pricing_model="monthly",
         minimum_price=500, target_mrr=700, target_employees_min=5, target_employees_max=300,
         deliverables=["Tax compliance calendar", "Return preparation support", "Entity and jurisdiction review"],
         required_signals=["new_entity", "new_location", "multiple_entities"], typical_problems=["Compliance gaps as footprint grows"],
         preferred_decision_makers=["Owner", "CFO", "Managing Director"]),
    dict(name="Finance Systems Implementation", description="Selection and roll-out of ERP/accounting systems.", pricing_model="project",
         minimum_price=6000, target_mrr=None, target_employees_min=30, target_employees_max=500,
         deliverables=["Requirements and vendor selection", "Data migration and chart-of-accounts design", "Go-live support"],
         required_signals=["erp_migration", "accounting_software_implementation", "technology_migration"],
         typical_problems=["System change without finance ownership"], preferred_decision_makers=["CFO", "VP Finance", "Finance Director"],
         follow_on="Controller Support"),
    dict(name="Advisory", description="Ad-hoc finance advisory for growth events.", pricing_model="monthly", minimum_price=1000,
         target_mrr=1500, target_employees_min=10, target_employees_max=300,
         deliverables=["Decision support on growth events", "Financial modelling", "Monthly advisory call"],
         required_signals=["funding", "acquisition", "rapid_growth"], typical_problems=["Big decisions without finance input"],
         preferred_decision_makers=["Owner", "CEO", "CFO"]),
]

CAMPAIGNS = {
    "T": dict(name="USA — Trucking — Controller/QBO", country="USA", industry="Transportation / Trucking",
              icp_description="Privately owned US trucking and freight companies, ~5-100 trucks/employees, on QuickBooks.",
              target_employees_min=5, target_employees_max=100, target_technology=["QuickBooks"], target_ownership="Privately owned",
              minimum_mrr=1000, target_mrr=1500, preferred_decision_maker=["Owner", "CFO", "Controller", "Finance Manager"],
              outreach_strategy="Lead with the observed hiring/growth fact, connect to close and reporting pressure.",
              research_rules="Check careers page and news for finance hiring, fleet growth and new terminals.",
              services=["QBO Cleanup", "Month-End Close", "Controller Support", "Accounting"]),
    "P": dict(name="Poland — Foreign-Owned Companies — Finance/Accounting", country="Poland", industry=None,
              icp_description="Foreign-owned sp. z o.o. with English-speaking management, 10-200 employees.",
              target_employees_min=10, target_employees_max=200, target_ownership="Foreign-owned", minimum_mrr=700, target_mrr=1000,
              preferred_decision_maker=["CFO", "Finance Director", "Managing Director", "General Manager", "Finance Manager"], language="en",
              outreach_strategy="English-language outreach to management; emphasise reporting to the foreign parent.",
              services=["Accounting", "Controller Support", "Financial Reporting", "Tax Support", "Accounting Automation", "Finance Systems Implementation"]),
    "M": dict(name="USA — Maritime Logistics — Finance Automation", country="USA", industry="Maritime / Logistics, Freight forwarding",
              icp_description="US maritime and forwarding companies with multiple entities and manual finance processes.",
              target_employees_min=20, target_employees_max=300, minimum_mrr=1500, target_mrr=2500,
              preferred_decision_maker=["CFO", "VP Finance", "Controller"],
              outreach_strategy="Focus on automation and system change as the trigger.",
              services=["Accounting Automation", "Finance Systems Implementation", "Financial Reporting", "CFO Support", "Controller Support"]),
}

D = "DEMO example"
COMPANIES = [
    dict(key="prairie", name="Prairie Line Freight LLC", site="prairielinefreight", country="USA", state="TX", city="Dallas", industry="Transportation / Trucking",
         sub="Truckload", emp=42, rev=7_800_000, scale="61 power units", own="Privately owned", sw="QuickBooks Online", growth="Growing",
         desc="Regional truckload carrier serving the south-central US.", person=("Dana Whitfield", "Owner & President", "dana.whitfield"),
         signals=[("hiring_controller", "Controller: responsible for monthly close, financial reporting and QuickBooks oversight.", 8, 0.9, "Company careers page"),
                  ("expansion", "We added 14 tractors this year and opened a second yard in Fort Worth.", 40, 0.7, "Company news page")],
         lead=("T", ["RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED", "CALL", "PROPOSAL"], 40, 0)),
    dict(key="redwood", name="Redwood Haulers Inc.", site="redwoodhaulers", country="USA", state="CA", city="Fresno", industry="Transportation / Trucking",
         sub="Flatbed", emp=28, rev=4_100_000, scale="34 trucks", own="Privately owned", sw="QuickBooks Desktop", growth="Stable",
         desc="Flatbed carrier hauling building materials in the Central Valley.", person=("Marcus Ortega", "CFO", "marcus.ortega"),
         signals=[("searching_qbo_support", "Looking for a QuickBooks ProAdvisor to help clean up our books before year end.", 12, 0.85, "Public forum post")],
         lead=("T", ["RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED", "CALL"], 34, 1)),
    dict(key="bluegrass", name="Bluegrass Dispatch & Freight", site="bluegrassdispatch", country="USA", state="KY", city="Lexington", industry="Transportation / Freight brokerage",
         sub="Brokerage", emp=18, rev=3_200_000, scale=None, own="Privately owned", sw="QuickBooks Online", growth=None,
         desc="Freight brokerage and dispatch for regional shippers.", person=("Priya Nair", "Office Manager", "priya.nair"),
         signals=[("hiring_bookkeeper", "Part-time bookkeeper wanted to manage payables, receivables and driver settlements.", 20, 0.85, "Job board listing")],
         lead=("T", ["RESEARCHED", "QUALIFIED"], 8, 0)),
    dict(key="ironhorse", name="Ironhorse Carriers LLC", site="ironhorsecarriers", country="USA", state="MO", city="Kansas City", industry="Transportation / Trucking",
         sub="Dry van", emp=65, rev=11_500_000, scale="70 power units", own="Privately owned", sw="QuickBooks Online", growth="Growing",
         desc="Dry van carrier with terminals across the Midwest.", person=("Tom Brandt", "Owner", "tom.brandt"),
         signals=[("new_location", "Grand opening of our new Memphis terminal this spring.", 30, 0.8, "Company news page"),
                  ("expansion", "Fleet growing from 55 to 70 power units.", 30, 0.75, "Company news page")],
         lead=("T", ["RESEARCHED", "QUALIFIED", "CONTACTED"], 16, 2, 10)),
    dict(key="summit", name="Summit Ridge Transport", site="summitridgetransport", country="USA", state="CO", city="Denver", industry="Transportation / Trucking",
         sub=None, emp=12, rev=None, scale=None, own="Privately owned", sw=None, growth=None, desc=None, person=None, signals=[],
         lead=("T", [], 3, 0)),
    dict(key="coastal", name="Coastal Cold Chain Logistics", site="coastalcoldchain", country="USA", state="GA", city="Savannah", industry="Transportation / Trucking",
         sub="Refrigerated", emp=85, rev=16_000_000, scale="96 reefers", own="Privately owned", sw="QuickBooks Online", growth="Growing",
         desc="Refrigerated carrier serving grocery distribution.", person=("Elena Ruiz", "Finance Manager", "elena.ruiz"),
         signals=[("acquisition", "Coastal Cold Chain has acquired Low Country Reefer, adding two terminals.", 25, 0.85, "Press release"),
                  ("multiple_entities", "Operating through Coastal Cold Chain and its subsidiary Low Country Reefer.", 25, 0.7, "Company about page"),
                  ("hiring_finance_manager", "Seeking a Finance Manager to lead reporting across both entities.", 10, 0.85, "Company careers page")],
         lead=("T", ["RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED"], 22, 2)),
    dict(key="lonestar", name="Lone Star Tankers", site="lonestartankers", country="USA", state="TX", city="Houston", industry="Transportation / Trucking",
         sub="Tank truck", emp=110, rev=19_000_000, scale=None, own="Privately owned", sw="QuickBooks Enterprise", growth=None,
         desc="Bulk liquid hauler.", person=("Wade Harlan", "CEO", "wade.harlan"), signals=[], lead=("T", ["RESEARCHED"], 12, 0)),
    dict(key="northwind", name="Northwind Trucking Co.", site="northwindtrucking", country="USA", state="MN", city="Minneapolis", industry="Transportation / Trucking",
         sub="Truckload", emp=22, rev=3_900_000, scale="27 trucks", own="Privately owned", sw="QuickBooks Online", growth="Stable",
         desc="Family-owned truckload carrier.", person=("Sarah Lindqvist", "Owner", "sarah.lindqvist"),
         signals=[("hiring_accountant", "Accountant needed to own month-end close and reconciliations.", 70, 0.85, "Job board listing")],
         lead=("T", ["RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED", "CALL", "PROPOSAL", "NEGOTIATION", "WON"], 75, 0, None, 1500)),
    dict(key="copperline", name="Copperline Logistics LLC", site="copperlinelogistics", country="USA", state="AZ", city="Phoenix", industry="Transportation / Trucking",
         sub="LTL", emp=35, rev=6_000_000, scale="40 trucks", own="Privately owned", sw="QuickBooks Online", growth="Growing",
         desc="LTL carrier in the Southwest.", person=("Jordan Pike", "Owner", "jordan.pike"),
         signals=[("hiring_accountant", "We are hiring a Staff Accountant to support month-end close.", 55, 0.85, "Company careers page")],
         lead=("T", ["RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED", "CALL", "LOST"], 60, 1, None, None, "Hired an in-house controller")),
    dict(key="greatplains", name="Great Plains Carriers", site="greatplainscarriers", country="USA", state="NE", city="Omaha", industry="Transportation / Trucking",
         sub=None, emp=30, rev=None, scale=None, own="Privately owned", sw=None, growth=None, desc=None, person=("Alex Morgan", "Operations Manager", None),
         signals=[], lead=("T", [], 1, 0)),
    dict(key="ozark", name="Ozark Express Lines", site="ozarkexpress", country="USA", state="AR", city="Little Rock", industry="Transportation / Trucking",
         sub="Truckload", emp=48, rev=8_200_000, scale="55 trucks", own="Privately owned", sw="QuickBooks Online", growth="Growing",
         desc="Truckload carrier hauling poultry feed and grain.", person=("Luke Harmon", "Owner", "luke.harmon"),
         signals=[("hiring_bookkeeper", "Now hiring: Bookkeeper (QuickBooks Online) — accounts payable and driver pay.", 5, 0.9, "Company careers page"),
                  ("uses_quickbooks", "Bookkeeper (QuickBooks Online) — accounts payable and driver pay.", 5, 0.55, "Company careers page")],
         lead=("T", ["RESEARCHED"], 5, 0)),
    dict(key="vistula", name="Vistula Components Sp. z o.o.", site="vistulacomponents", country="Poland", state="Dolnośląskie", city="Wrocław", industry="Manufacturing",
         sub="Automotive components", emp=120, rev=22_000_000, scale=None, own="Foreign-owned", sw="Comarch ERP", growth="Growing",
         desc="Automotive component manufacturer, subsidiary of a German group.", person=("Katarzyna Zielińska", "Finance Director", "katarzyna.zielinska"),
         signals=[("erp_migration", "Project: migration from legacy ERP to a new ERP platform in Q4.", 15, 0.8, "Company news page")],
         lead=("P", ["RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED", "CALL", "PROPOSAL", "NEGOTIATION"], 50, 0)),
    dict(key="baltic_sw", name="Baltic Harbor Software Sp. z o.o.", site="balticharborsoft", country="Poland", state="Pomorskie", city="Gdańsk", industry="IT / Software",
         sub="SaaS", emp=45, rev=None, scale=None, own="Foreign-owned", sw="Symfonia", growth="Growing", desc="Software development studio owned by a US parent.",
         person=("James Whitaker", "Managing Director", "james.whitaker"),
         signals=[("hiring_accountant", "Poszukujemy księgowego / księgowej do zespołu finansowego w Gdańsku.", 6, 0.85, "Company careers page")],
         lead=("P", ["RESEARCHED", "QUALIFIED"], 6, 0)),
    dict(key="nordic", name="Nordic Print Polska Sp. z o.o.", site="nordicprintpolska", country="Poland", state="Wielkopolskie", city="Poznań", industry="Manufacturing",
         sub="Printing and packaging", emp=70, rev=9_500_000, scale=None, own="Foreign-owned", sw="enova", growth="Stable",
         desc="Packaging printer owned by a Swedish group.", person=("Anna Kowalczyk", "Finance Manager", "anna.kowalczyk"),
         signals=[("new_entity", "Formed a new company to run our second production site.", 60, 0.8, "Company news page"),
                  ("hiring_accountant", "Szukamy księgowego do wsparcia zamknięcia miesiąca.", 65, 0.8, "Company careers page")],
         lead=("P", ["RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED", "CALL", "PROPOSAL", "WON"], 65, 2, None, 900)),
    dict(key="silesia", name="Silesia Auto Parts Sp. z o.o.", site="silesiaautoparts", country="Poland", state="Śląskie", city="Katowice", industry="Manufacturing",
         sub="Automotive", emp=200, rev=None, scale=None, own="Foreign-owned", sw=None, growth=None, desc=None,
         person=("Marco Bellini", "General Manager", "marco.bellini"), signals=[], lead=("P", [], 2, 0)),
    dict(key="oder", name="Oder Valley Logistics Sp. z o.o.", site="odervalleylogistics", country="Poland", state="Zachodniopomorskie", city="Szczecin", industry="Logistics",
         sub="Freight", emp=55, rev=6_000_000, scale=None, own="Polish-owned", sw=None, growth=None, desc=None,
         person=("Piotr Nowak", "Prezes", "piotr.nowak"), signals=[], lead=("P", ["RESEARCHED", "NOT_A_FIT"], 20, 0)),
    dict(key="harborline", name="Harborline Marine Services LLC", site="harborlinemarine", country="USA", state="VA", city="Norfolk", industry="Maritime / Logistics",
         sub="Marine services", emp=140, rev=31_000_000, scale=None, own="Privately owned", sw="Sage Intacct", growth="Growing",
         desc="Marine services and port logistics provider.", person=("Grace Donovan", "VP Finance", "grace.donovan"),
         signals=[("accounting_software_implementation", "Finance transformation: implementing a new accounting platform across all entities.", 14, 0.85, "Company news page"),
                  ("multiple_entities", "Harborline operates four subsidiaries across the Mid-Atlantic.", 14, 0.75, "Company about page")],
         lead=("M", ["RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED", "CALL"], 28, 0)),
    dict(key="tidewater", name="Tidewater Freight Forwarders Inc.", site="tidewaterfreight", country="USA", state="CA", city="Long Beach", industry="Freight forwarding / Maritime",
         sub="Ocean freight", emp=60, rev=12_000_000, scale=None, own="Privately owned", sw="QuickBooks Desktop", growth="Growing",
         desc="Ocean freight forwarder with three operating entities.", person=("Victor Chen", "CFO", "victor.chen"),
         signals=[("automation_need", "Carrier invoices are keyed in manually across our three entities.", 20, 0.6, "Public case-study interview"),
                  ("multiple_entities", "Tidewater operates through three entities: Forwarding, Customs and Warehousing.", 20, 0.75, "Company about page")],
         lead=("M", ["RESEARCHED", "QUALIFIED", "CONTACTED"], 14, 1, 5)),
    dict(key="gulf", name="Gulf Stream Port Services", site="gulfstreamports", country="USA", state="AL", city="Mobile", industry="Maritime / Logistics",
         sub="Port services", emp=210, rev=44_000_000, scale=None, own="Privately owned", sw=None, growth=None, desc="Stevedoring and port services.",
         person=("Renee Baptiste", "Controller", "renee.baptiste"),
         signals=[("funding", "Secured a new credit facility to fund terminal equipment.", 35, 0.8, "Press release")],
         lead=("M", ["RESEARCHED"], 9, 0)),
    dict(key="baltic_marine", name="Baltic Marine Services Inc.", site="balticmarineservices", country="USA", state="WA", city="Seattle", industry="Maritime / Logistics",
         sub="Ship agency", emp=75, rev=14_000_000, scale=None, own="Privately owned", sw="QuickBooks Desktop", growth="Growing", desc="Ship agency and marine logistics.",
         person=None, signals=[("hiring_finance_manager", "Now hiring: Finance Manager to own reporting and controls.", 4, 0.9, "Company careers page")],
         lead=("M", ["RESEARCHED"], 4, 0)),
]
# Tidewater also appears in the trucking campaign to show cross-campaign leads and a weaker industry fit.
EXTRA_LEADS = [("tidewater", "T", ["RESEARCHED"], 6)]

REPLIES = ["[DEMO] Thanks for reaching out — this is timely. Can we talk next week?",
           "[DEMO] Interesting. Send over a bit more detail on how you'd approach it.",
           "[DEMO] Happy to have a call. Tuesday afternoon works."]


def _dt(d: date, hour: int = 10) -> datetime:
    return datetime.combine(d, time(hour, 0))


def demo_counts(db: Session) -> dict:
    return {"companies": db.query(Company).filter(Company.is_demo.is_(True)).count(),
            "leads": db.query(Lead).filter(Lead.is_demo.is_(True)).count(),
            "campaigns": db.query(Campaign).filter(Campaign.is_demo.is_(True)).count(),
            "services": db.query(Service).filter(Service.is_demo.is_(True)).count(),
            "signals": db.query(Signal).filter(Signal.is_demo.is_(True)).count(),
            "people": db.query(Person).filter(Person.is_demo.is_(True)).count()}


def remove_demo(db: Session) -> dict:
    before = demo_counts(db)
    demo_lead_ids = [i for i, in db.query(Lead.id).filter(Lead.is_demo.is_(True)).all()]
    if demo_lead_ids:
        db.query(StageHistory).filter(StageHistory.lead_id.in_(demo_lead_ids)).delete(synchronize_session=False)
    for model in (OutreachMessage, Interaction, Task, Signal, Lead, Person, Company, Campaign, Service):
        db.query(model).filter(model.is_demo.is_(True)).delete(synchronize_session=False)
    db.flush()
    audit.log(db, "demo_removed", f"Demo data removed ({before['companies']} companies, {before['leads']} leads)", details=before)
    return before


def load_demo(db: Session) -> dict:
    if db.query(Company).filter(Company.is_demo.is_(True)).count():
        return {"loaded": False, "reason": "Demo data is already loaded."}
    t = today()
    svc: dict[str, Service] = {}
    for s in SERVICES:
        spec = dict(s)
        spec.pop("follow_on", None)
        svc[s["name"]] = campaign_service.create_service(db, spec, actor="system", is_demo=True)
    for s in SERVICES:
        if s.get("follow_on"):
            svc[s["name"]].follow_on_service_id = svc[s["follow_on"]].id
    camps: dict[str, Campaign] = {}
    for key, spec in CAMPAIGNS.items():
        spec = dict(spec)
        names = spec.pop("services")
        camps[key] = campaign_service.create_campaign(db, spec, service_ids=[svc[n].id for n in names], actor="system", is_demo=True)
    companies: dict[str, Company] = {}
    people: dict[str, Optional[Person]] = {}
    for c in COMPANIES:
        comp = company_service.create_company(db, {
            "name": c["name"], "website": f"https://{c['site']}.example", "country": c["country"], "state": c["state"], "city": c["city"],
            "industry": c["industry"], "subindustry": c["sub"], "employees": c["emp"], "estimated_revenue": c["rev"],
            "estimated_scale": c["scale"], "ownership_type": c["own"], "accounting_software": c["sw"], "growth_status": c["growth"],
            "description": c["desc"], "source": SRC, "phone": None}, actor="system", is_demo=True, log=False)
        companies[c["key"]] = comp
        p = None
        if c["person"]:
            name, title, local = c["person"]
            p = company_service.create_person(db, comp.id, {"full_name": name, "title": title, "source": SRC,
                                                            "email": f"{local}@{c['site']}.example" if local else None,
                                                            "linkedin_url": f"https://www.linkedin.com/in/{local.replace('.', '-')}-demo" if local and c["key"] in ("prairie", "vistula", "harborline") else None},
                                              actor="system", is_demo=True, log=False)
        people[c["key"]] = p
        for typ, evidence, days, conf, source in c["signals"]:
            add_signal(db, comp.id, typ, evidence, f"{source} ({D})", confidence=conf, origin="demo",
                       date_detected=t - timedelta(days=days), is_demo=True, actor="system")
    leads_out = 0
    specs = [(c["key"], *c["lead"]) for c in COMPANIES] + [(k, camp, path, age, 0) for k, camp, path, age in EXTRA_LEADS]
    for i, spec in enumerate(specs):
        key, camp_key, path, age, variant, *rest = spec
        sent_ago = rest[0] if len(rest) > 0 else None
        won_mrr = rest[1] if len(rest) > 1 else None
        lost_reason = rest[2] if len(rest) > 2 else None
        comp, person = companies[key], people[key]
        created = _dt(t - timedelta(days=age), 9)
        lead, _ = lead_service.create_lead(db, company_id=comp.id, campaign_id=camps[camp_key].id, person_id=person.id if person else None,
                                           actor="system", is_demo=True, log=False, created_at=created)
        qualify_lead(db, lead, actor="ai")
        generate_offer(db, lead, actor="ai")
        step = max(1, age // (len(path) + 1)) if path else 1
        stage_dates: dict[str, datetime] = {}
        prev = "NEW"
        for n, stage in enumerate(path, start=1):
            at = _dt(t - timedelta(days=max(0, age - step * n)), 10)
            if stage == "CONTACTED" and sent_ago is not None:
                at = _dt(t - timedelta(days=sent_ago), 10)
            stage_dates[stage] = at
            db.add(StageHistory(lead_id=lead.id, from_stage=prev, to_stage=stage, changed_at=at, actor="user", note="Demo history"))
            prev = stage
        lead.status = path[-1] if path else "NEW"
        if lead.status == "WON":
            lead.actual_mrr, lead.won_at = float(won_mrr or 0), stage_dates["WON"]
        if lead.status == "LOST":
            lead.lost_reason = lost_reason
        db.flush()
        db.refresh(lead)
        main = [s for s in path if s in ("QUALIFIED", "CONTACTED", "REPLIED", "CALL", "PROPOSAL", "NEGOTIATION", "WON", "LOST")]
        try:
            drafts = generate_messages(db, lead.id) if ("CONTACTED" in path or lead.status == "QUALIFIED") else []
        except InsufficientEvidence:
            drafts = []
        if "CONTACTED" in path and drafts:
            chosen = drafts[variant % len(drafts)]
            for d in drafts:
                if d.id != chosen.id:
                    d.status = "rejected"
            followup_engine.mark_sent(db, chosen.id, sent_at=stage_dates["CONTACTED"], actor="system")
            if "REPLIED" in path:
                crm_service.log_interaction(db, lead_id=lead.id, type="email", direction="inbound", subject="Re: " + (chosen.subject or ""),
                                            body=REPLIES[i % len(REPLIES)], occurred_at=stage_dates["REPLIED"] + timedelta(hours=3), actor="system")
            if "CALL" in path:
                crm_service.log_interaction(db, lead_id=lead.id, type="call", direction="outbound", subject="Discovery call",
                                            body="[DEMO] Walked through current close process and reporting gaps.", outcome="Positive",
                                            occurred_at=stage_dates["CALL"], actor="system")
            if "PROPOSAL" in path:
                crm_service.log_interaction(db, lead_id=lead.id, type="note", direction="internal", subject="Proposal sent",
                                            body="[DEMO] Proposal sent for the recommended service.", occurred_at=stage_dates["PROPOSAL"], actor="system")
        lead.updated_at = _dt(t, 9) if lead.status not in ("WON", "LOST") else stage_dates.get(lead.status, _dt(t))
        if lead.status in ("WON", "LOST", "NOT_A_FIT"):
            task_service.cancel_stale_stage_tasks(db, lead, None, include_followups=True)
            lead.next_action, lead.next_action_date = None, None
        else:
            task_service.cancel_stale_stage_tasks(db, lead, lead.status)
            task_service.generate_tasks_for_lead(db, lead)
        leads_out += 1
    task_service.create_task(db, "Review pricing assumptions in Settings → Pricing", due_date=t + timedelta(days=2), task_type="other",
                             priority="LOW", is_demo=True, actor="system")
    db.flush()
    audit.log(db, "demo_loaded", f"Demo data loaded ({len(companies)} companies, {leads_out} leads)", actor="system", details=demo_counts(db))
    return {"loaded": True, **demo_counts(db)}
