"""Campaigns (independent ICP + outreach configurations) and the service catalog."""
from __future__ import annotations

from typing import Any, Optional

from sqlalchemy import func
from sqlalchemy.orm import Session

from core import audit
from core.constants import CAMPAIGN_STATUSES, CHANNELS
from core.errors import NotFound, ValidationProblem
from core.utils import norm_country, parse_int, parse_number, sanitize_text, split_list
from database.models import Campaign, Lead, Service
from engines import analytics_engine
from engines.offer_engine import generate_offer
from engines.qualification_engine import qualify_lead
from services import task_service

FOLLOWUP_TYPES = {"bump", "value", "final", "custom"}


def _sequence(value: Any) -> list[dict]:
    out = []
    for s in (value or []):
        try:
            day = int(s["day"])
        except (KeyError, TypeError, ValueError):
            raise ValidationProblem("Each follow-up needs a numeric 'day'", operation="save campaign")
        if day < 1 or day > 365:
            raise ValidationProblem("Follow-up day must be between 1 and 365", operation="save campaign")
        t, ch = s.get("type", "bump"), s.get("channel") or "email"
        out.append({"day": day, "type": t if t in FOLLOWUP_TYPES else "bump", "channel": ch if ch in CHANNELS else "email"})
    return sorted(out, key=lambda x: x["day"])


def _clean_rules(qr: Any) -> dict:
    """Optional per-campaign overrides of the qualification rules: dimension weights and level thresholds."""
    if not isinstance(qr, dict):
        raise ValidationProblem("Qualification rules must be an object", operation="save campaign")
    out: dict[str, Any] = {}
    for k, v in qr.items():
        if k == "weights":
            if not isinstance(v, dict):
                raise ValidationProblem("Weights must be an object", operation="save campaign")
            w = {}
            for dim, val in v.items():
                if dim not in ("fit", "need", "signal", "ability_to_pay", "contactability"):
                    raise ValidationProblem(f"Unknown weight '{dim}'", operation="save campaign")
                n = parse_number(val)
                if n is None or n < 0 or n > 1:
                    raise ValidationProblem(f"Weight for {dim} must be between 0 and 1", operation="save campaign")
                w[dim] = n
            if w:
                out["weights"] = w
        elif k in ("high_threshold", "medium_threshold", "priority_high_composite", "priority_low_composite"):
            n = parse_number(v)
            if n is None or not 0 <= n <= 100:
                raise ValidationProblem(f"{k.replace('_', ' ').capitalize()} must be between 0 and 100", operation="save campaign")
            out[k] = n
        else:
            raise ValidationProblem(f"Unknown qualification rule '{k}'", operation="save campaign")
    if "high_threshold" in out and "medium_threshold" in out and out["medium_threshold"] >= out["high_threshold"]:
        raise ValidationProblem("The Medium threshold must be lower than the High threshold", operation="save campaign")
    return out


def clean_campaign(data: dict[str, Any]) -> dict[str, Any]:
    o: dict[str, Any] = {}
    txt = {"name": 200, "industry": 120, "subindustry": 120, "icp_description": 4000, "target_ownership": 120,
           "target_geography": 255, "research_rules": 4000, "outreach_strategy": 4000, "language": 10}
    for k, n in txt.items():
        if k in data:
            o[k] = sanitize_text(data[k], n) or None
    if "country" in data:
        o["country"] = norm_country(sanitize_text(data["country"], 80))
    for k in ("target_employees_min", "target_employees_max"):
        if k in data:
            o[k] = parse_int(data[k])
    for k in ("target_revenue_min", "target_revenue_max", "minimum_mrr", "target_mrr"):
        if k in data:
            o[k] = parse_number(data[k])
    for k in ("target_technology", "preferred_decision_maker"):
        if k in data:
            o[k] = split_list(data[k])
    if "campaign_status" in data:
        if data["campaign_status"] not in CAMPAIGN_STATUSES:
            raise ValidationProblem("Unknown campaign status", operation="save campaign", suggestion=f"Use: {', '.join(CAMPAIGN_STATUSES)}")
        o["campaign_status"] = data["campaign_status"]
    if "qualification_rules" in data:
        qr = data["qualification_rules"] or {}
        o["qualification_rules"] = _clean_rules(qr)
    if "followup_sequence" in data:
        o["followup_sequence"] = _sequence(data["followup_sequence"])
    lo, hi = o.get("target_employees_min"), o.get("target_employees_max")
    if lo is not None and hi is not None and lo > hi:
        raise ValidationProblem("Minimum employees cannot exceed maximum", operation="save campaign")
    return o


def _set_services(db: Session, c: Campaign, ids: Optional[list[int]]) -> None:
    if ids is None:
        return
    svcs = db.query(Service).filter(Service.id.in_(ids)).all() if ids else []
    if len(svcs) != len(set(ids)):
        raise ValidationProblem("One or more selected services do not exist", operation="save campaign")
    c.services = svcs


def get_campaign(db: Session, cid: int) -> Campaign:
    c = db.get(Campaign, cid)
    if not c:
        raise NotFound("Campaign", cid)
    return c


def create_campaign(db: Session, data: dict[str, Any], *, service_ids: Optional[list[int]] = None, actor: str = "user",
                    is_demo: bool = False) -> Campaign:
    clean = clean_campaign(data)
    if not clean.get("name"):
        raise ValidationProblem("Campaign name is required", operation="create campaign")
    if db.query(Campaign).filter(func.lower(Campaign.name) == clean["name"].lower()).first():
        raise ValidationProblem(f"A campaign named '{clean['name']}' already exists", operation="create campaign",
                                suggestion="Choose a different name.")
    c = Campaign(**clean, is_demo=is_demo)
    db.add(c)
    _set_services(db, c, service_ids)
    db.flush()
    audit.log(db, "campaign_created", f"Campaign created: {c.name}", entity_type="campaign", entity_id=c.id, actor=actor)
    return c


def update_campaign(db: Session, cid: int, data: dict[str, Any], *, service_ids: Optional[list[int]] = None, actor: str = "user") -> Campaign:
    c = get_campaign(db, cid)
    clean = clean_campaign(data)
    if "name" in clean:
        if not clean["name"]:
            raise ValidationProblem("Campaign name cannot be empty", operation="update campaign")
        dup = db.query(Campaign).filter(func.lower(Campaign.name) == clean["name"].lower(), Campaign.id != cid).first()
        if dup:
            raise ValidationProblem(f"A campaign named '{clean['name']}' already exists", operation="update campaign")
    for k, v in clean.items():
        setattr(c, k, v)
    _set_services(db, c, service_ids)
    audit.log(db, "campaign_updated", f"Campaign edited: {c.name}", entity_type="campaign", entity_id=c.id, actor=actor,
              details={"fields": list(clean)})
    db.flush()
    return c


def delete_campaign(db: Session, cid: int, actor: str = "user") -> None:
    c = get_campaign(db, cid)
    n = db.query(Lead).filter(Lead.campaign_id == cid).count()
    audit.log(db, "campaign_deleted", f"Campaign deleted: {c.name} ({n} leads kept without a campaign)", entity_type="campaign",
              entity_id=c.id, actor=actor, details={"snapshot": c.as_dict()})
    db.delete(c)


def campaign_dict(c: Campaign, stats: Optional[dict] = None) -> dict:
    d = c.as_dict()
    d["service_ids"] = [s.id for s in c.services]
    d["services"] = [s.name for s in c.services]
    if stats is not None:
        d["stats"] = stats
    return d


def campaign_stats(db: Session, cid: int) -> dict:
    f = analytics_engine.funnel(db, campaign_id=cid)
    prio = dict(db.query(Lead.overall_priority, func.count(Lead.id)).filter(Lead.campaign_id == cid).group_by(Lead.overall_priority).all())
    return {"counts": f["counts"], "mrr": f["mrr"], "pipeline_value": f["pipeline_value"], "rates": f["rates"],
            "avg_mrr": f["avg_mrr"], "priority": {k or "UNQUALIFIED": v for k, v in prio.items()}}


def list_campaigns(db: Session) -> list[dict]:
    return [campaign_dict(c, campaign_stats(db, c.id)) for c in db.query(Campaign).order_by(Campaign.name).all()]


def qualify_all(db: Session, campaign_id: Optional[int] = None, actor: str = "ai") -> dict:
    q = db.query(Lead).filter(~Lead.status.in_(["WON", "LOST"]))
    if campaign_id:
        q = q.filter(Lead.campaign_id == campaign_id)
    by_pr: dict[str, int] = {}
    no_offer = 0
    leads = q.all()
    for lead in leads:
        res = qualify_lead(db, lead, actor=actor)
        by_pr[res["overall"]["priority"]] = by_pr.get(res["overall"]["priority"], 0) + 1
        if not generate_offer(db, lead, actor=actor).get("recommended"):
            no_offer += 1
        task_service.generate_tasks_for_lead(db, lead)
    audit.log(db, "qualify_all", f"Qualified {len(leads)} leads" + (f" in campaign {campaign_id}" if campaign_id else ""),
              entity_type="campaign", entity_id=campaign_id, actor=actor, details={"by_priority": by_pr, "no_service_match": no_offer})
    return {"processed": len(leads), "by_priority": by_pr, "no_service_match": no_offer}


# ------------------------------------------------------------ service catalog
def clean_service(data: dict[str, Any]) -> dict[str, Any]:
    o: dict[str, Any] = {}
    for k, n in (("name", 160), ("description", 4000), ("message_template", 4000)):
        if k in data:
            o[k] = sanitize_text(data[k], n) or None
    for k in ("target_industries", "typical_problems", "deliverables", "required_signals", "preferred_decision_makers", "target_technology"):
        if k in data:
            o[k] = split_list(data[k]) if k != "required_signals" else [s.lower().replace(" ", "_") for s in split_list(data[k])]
    for k in ("target_employees_min", "target_employees_max"):
        if k in data:
            o[k] = parse_int(data[k])
    for k in ("minimum_price", "target_mrr"):
        if k in data:
            o[k] = parse_number(data[k])
    if "pricing_model" in data:
        if data["pricing_model"] not in ("monthly", "project"):
            raise ValidationProblem("Pricing model must be 'monthly' or 'project'", operation="save service")
        o["pricing_model"] = data["pricing_model"]
    if "is_active" in data:
        o["is_active"] = bool(data["is_active"])
    if "follow_on_service_id" in data:
        o["follow_on_service_id"] = data["follow_on_service_id"] or None
    return o


def service_dict(s: Service) -> dict:
    return s.as_dict()


def create_service(db: Session, data: dict[str, Any], *, actor: str = "user", is_demo: bool = False) -> Service:
    clean = clean_service(data)
    if not clean.get("name"):
        raise ValidationProblem("Service name is required", operation="create service")
    if db.query(Service).filter(func.lower(Service.name) == clean["name"].lower()).first():
        raise ValidationProblem(f"A service named '{clean['name']}' already exists", operation="create service")
    s = Service(**clean, is_demo=is_demo)
    db.add(s)
    db.flush()
    audit.log(db, "service_created", f"Service added: {s.name}", entity_type="service", entity_id=s.id, actor=actor)
    return s


def update_service(db: Session, sid: int, data: dict[str, Any], *, actor: str = "user") -> Service:
    s = db.get(Service, sid)
    if not s:
        raise NotFound("Service", sid)
    clean = clean_service(data)
    if "name" in clean:
        dup = db.query(Service).filter(func.lower(Service.name) == (clean["name"] or "").lower(), Service.id != sid).first()
        if not clean["name"] or dup:
            raise ValidationProblem("Service name is empty or already used", operation="update service")
    if clean.get("follow_on_service_id") == sid:
        raise ValidationProblem("A service cannot follow itself", operation="update service")
    for k, v in clean.items():
        setattr(s, k, v)
    audit.log(db, "service_updated", f"Service edited: {s.name}", entity_type="service", entity_id=s.id, actor=actor,
              details={"fields": list(clean)})
    db.flush()
    return s


def delete_service(db: Session, sid: int, actor: str = "user") -> None:
    s = db.get(Service, sid)
    if not s:
        raise NotFound("Service", sid)
    audit.log(db, "service_deleted", f"Service deleted: {s.name}", entity_type="service", entity_id=s.id, actor=actor,
              details={"snapshot": s.as_dict()})
    db.delete(s)
