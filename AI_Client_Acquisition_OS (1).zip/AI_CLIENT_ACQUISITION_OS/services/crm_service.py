"""CRM: stage transitions, interactions, pipeline board and 'what should I do today'."""
from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any, Optional

from sqlalchemy.orm import Session

from core import audit
from core.constants import (ACTIVE_STAGES, ALL_STAGES, DISQUALIFY_REASONS, PIPELINE_STAGES, PIPELINE_VALUE_STAGES,
                            STAGE_LABELS, LEVEL_RANK, OFFPATH_STAGES, INTERACTION_TYPES, DIRECTIONS)
from core.errors import AppError, NotFound, ValidationProblem
from core.settings_store import get_settings
from core.utils import sanitize_text, today as _today, utcnow
from database.models import Company, Interaction, Lead, Signal, StageHistory, Task
from engines.signal_engine import catalog_entry, rank_signals
from services import task_service

CLOSING_STAGES = {"WON", "LOST", "NOT_A_FIT"}


def move_stage(db: Session, lead_id: int, to_stage: str, *, actor: str = "user", note: Optional[str] = None,
               actual_mrr: Optional[float] = None, lost_reason: Optional[str] = None,
               disqualify_reason: Optional[str] = None, at: Optional[datetime] = None) -> Lead:
    lead = db.get(Lead, lead_id)
    if not lead:
        raise NotFound("Lead", lead_id)
    to_stage = (to_stage or "").upper()
    if to_stage not in ALL_STAGES:
        raise ValidationProblem(f"Unknown stage '{to_stage}'", operation="move stage",
                                suggestion=f"Use one of: {', '.join(ALL_STAGES)}")
    if actor != "user" and to_stage in CLOSING_STAGES:
        raise AppError("Automations may not close opportunities", operation="move stage",
                       cause=f"Moving a lead to {STAGE_LABELS[to_stage]} must be a user decision.",
                       suggestion="Move the lead manually from the pipeline.", status_code=403)
    if to_stage == "WON":
        if actual_mrr is None or actual_mrr < 0:
            raise ValidationProblem("Enter the contracted MRR to mark this lead as won", operation="mark lead won",
                                    cause="Won clients must carry the actual monthly recurring revenue agreed with the client.",
                                    suggestion="Provide the agreed MRR (use 0 for a project-only sale).")
    if to_stage == "LOST" and not (lost_reason or "").strip():
        raise ValidationProblem("Enter a reason for losing this lead", operation="mark lead lost",
                                suggestion="A short reason makes the analytics useful (e.g. 'chose in-house hire').")
    if to_stage == "NOT_A_FIT":
        if disqualify_reason not in DISQUALIFY_REASONS:
            raise ValidationProblem("Choose why this lead is not a fit", operation="mark lead not a fit",
                                    cause="A structured reason is required so the feedback engine can learn which sources, "
                                         "industries and signals tend to produce bad-fit leads (master prompt §27).",
                                    suggestion=f"Use one of: {', '.join(DISQUALIFY_REASONS)}")
    old = lead.status
    if old == to_stage:
        return lead
    lead.status = to_stage
    now = at or utcnow()
    if to_stage == "WON":
        lead.actual_mrr, lead.won_at = float(actual_mrr), now
    elif old == "WON":
        lead.actual_mrr, lead.won_at = None, None
    lead.lost_reason = sanitize_text(lost_reason, 255) if to_stage == "LOST" else None
    lead.disqualify_reason = disqualify_reason if to_stage == "NOT_A_FIT" else None
    db.add(StageHistory(lead_id=lead.id, from_stage=old, to_stage=to_stage, changed_at=now, actor=actor,
                        note=sanitize_text(note, 255)))
    audit.log(db, "stage_changed", f"{lead.company.name}: {STAGE_LABELS[old]} → {STAGE_LABELS[to_stage]}",
              entity_type="lead", entity_id=lead.id, actor=actor,
              details={"from": old, "to": to_stage, "note": note, "actual_mrr": actual_mrr, "lost_reason": lost_reason})
    db.flush()
    # tasks follow the stage
    if to_stage in CLOSING_STAGES:
        task_service.cancel_stale_stage_tasks(db, lead, None, include_followups=True)
        lead.next_action, lead.next_action_date = None, None
    else:
        task_service.cancel_stale_stage_tasks(db, lead, to_stage, include_followups=(to_stage == "NURTURE"))
        task_service.generate_tasks_for_lead(db, lead)
    return lead


def log_interaction(db: Session, *, lead_id: Optional[int] = None, company_id: Optional[int] = None,
                    type: str = "note", direction: str = "internal", subject: Optional[str] = None,
                    body: Optional[str] = None, outcome: Optional[str] = None, person_id: Optional[int] = None,
                    occurred_at: Optional[datetime] = None, message_id: Optional[int] = None,
                    is_demo: bool = False, actor: str = "user") -> Interaction:
    lead = db.get(Lead, lead_id) if lead_id else None
    if lead_id and not lead:
        raise NotFound("Lead", lead_id)
    company_id = company_id or (lead.company_id if lead else None)
    if not company_id or not db.get(Company, company_id):
        raise ValidationProblem("An interaction needs a company or lead", operation="log interaction")
    if type not in INTERACTION_TYPES or direction not in DIRECTIONS:
        raise ValidationProblem("Unknown interaction type or direction", operation="log interaction",
                                suggestion=f"Types: {', '.join(INTERACTION_TYPES)}; directions: {', '.join(DIRECTIONS)}")
    it = Interaction(company_id=company_id, lead_id=lead_id, person_id=person_id or (lead.person_id if lead else None),
                     type=type, direction=direction, subject=sanitize_text(subject, 300), body=sanitize_text(body, 5000),
                     outcome=sanitize_text(outcome, 200), occurred_at=occurred_at or utcnow(), message_id=message_id,
                     is_demo=is_demo or bool(lead and lead.is_demo))
    db.add(it)
    if lead:
        lead.last_interaction_at = it.occurred_at
    db.flush()
    audit.log(db, "interaction_logged", f"{type} ({direction}) logged" + (f": {subject}" if subject else ""),
              entity_type="interaction", entity_id=it.id, actor=actor, details={"lead_id": lead_id, "company_id": company_id})
    if lead and direction == "inbound" and type in ("email", "linkedin", "form", "call", "meeting", "other"):
        from engines.followup_engine import on_reply
        on_reply(db, lead, actor=actor)
    return it


def stage_estimates(db: Session) -> dict:
    return get_settings(db, "pipeline")["stage_estimates"]


def _compact(lead: Lead, est: dict) -> dict:
    p = lead.person
    return {"id": lead.id, "company_id": lead.company_id, "company": lead.company.name, "country": lead.company.country,
            "contact": p.full_name if p else None, "contact_title": p.title if p else None,
            "campaign_id": lead.campaign_id, "campaign": lead.campaign.name if lead.campaign else None,
            "service": lead.recommended_service, "potential_mrr": lead.potential_mrr or 0.0,
            "actual_mrr": lead.actual_mrr, "priority": lead.overall_priority, "status": lead.status,
            "next_action": lead.next_action, "next_action_date": lead.next_action_date.isoformat() if lead.next_action_date else None,
            "last_interaction_at": lead.last_interaction_at.isoformat() if lead.last_interaction_at else None,
            "estimate_pct": est.get(lead.status, 0.0), "is_demo": lead.is_demo,
            "suggested_stage": ((lead.qualification or {}).get("suggested_stage"))}


def pipeline_board(db: Session, *, campaign_id: Optional[int] = None, country: Optional[str] = None,
                   q: Optional[str] = None) -> dict:
    est = stage_estimates(db)
    query = db.query(Lead).join(Company, Lead.company_id == Company.id).filter(Company.archived.is_(False))
    if campaign_id:
        query = query.filter(Lead.campaign_id == campaign_id)
    if country:
        query = query.filter(Company.country == country)
    if q:
        query = query.filter(Company.name.ilike(f"%{q}%"))
    leads = query.order_by(Lead.updated_at.desc()).all()
    cols = {s: [] for s in ALL_STAGES}
    for l in leads:
        cols[l.status if l.status in cols else "NEW"].append(_compact(l, est))
    def col(stage):
        items = sorted(cols[stage], key=lambda x: (-LEVEL_RANK.get(x["priority"] or "UNKNOWN", 0), -x["potential_mrr"]))
        total = sum((i["actual_mrr"] if stage == "WON" and i["actual_mrr"] is not None else i["potential_mrr"]) for i in items)
        return {"stage": stage, "label": STAGE_LABELS[stage], "count": len(items), "total_mrr": total,
                "weighted_mrr": round(total * est.get(stage, 0.0), 2) if stage in PIPELINE_VALUE_STAGES else None,
                "estimate_pct": est.get(stage, 0.0), "leads": items}
    return {"stages": [col(s) for s in PIPELINE_STAGES], "offpath": [col(s) for s in OFFPATH_STAGES],
            "note": "Stage percentages are your own internal sales estimates (editable in Settings → Pipeline), "
                    "not a forecast produced by the application."}


def todays_priorities(db: Session, limit: int = 8, on: Optional[date] = None) -> list[dict]:
    on = on or _today()
    leads = (db.query(Lead).join(Company, Lead.company_id == Company.id)
             .filter(Lead.status.in_(ACTIVE_STAGES), Company.archived.is_(False)).all())
    if not leads:
        return []
    open_tasks = db.query(Task).filter(Task.status == "open", Task.lead_id.in_([l.id for l in leads])).all()
    by_lead: dict[int, list[Task]] = {}
    for t in open_tasks:
        by_lead.setdefault(t.lead_id, []).append(t)
    sigs: dict[int, list[Signal]] = {}
    for s in db.query(Signal).filter(Signal.company_id.in_({l.company_id for l in leads})).all():
        sigs.setdefault(s.company_id, []).append(s)
    out = []
    for lead in leads:
        tasks = sorted([t for t in by_lead.get(lead.id, []) if t.due_date and t.due_date <= on], key=lambda t: t.due_date)
        action = due = urgency = None
        if tasks:
            action, due = tasks[0].title, tasks[0].due_date
            urgency = "overdue" if due < on else "today"
        elif lead.next_action and lead.next_action_date and lead.next_action_date <= on:
            action, due = lead.next_action, lead.next_action_date
            urgency = "overdue" if due < on else "today"
        elif lead.status in ("NEW", "RESEARCHED", "QUALIFIED") and lead.overall_priority in ("HIGH", "MEDIUM"):
            action, urgency = lead.next_action or "Review lead", "ready"
        if not action:
            continue
        top = rank_signals(sigs.get(lead.company_id, []), on)
        prio = lead.overall_priority or "LOW"
        score = {"overdue": 300, "today": 200, "ready": 100}[urgency] + {"HIGH": 30, "MEDIUM": 20}.get(prio, 5) \
            + min((lead.potential_mrr or 0) / 100.0, 30)
        out.append({"lead_id": lead.id, "company_id": lead.company_id, "company": lead.company.name,
                    "signal": catalog_entry(top[0].signal_type)["label"] if top else None,
                    "mrr": lead.potential_mrr or 0.0, "action": action, "due": due.isoformat() if due else None,
                    "urgency": urgency, "priority": prio, "status": lead.status,
                    "campaign": lead.campaign.name if lead.campaign else None, "_score": score})
    out.sort(key=lambda x: -x["_score"])
    for o in out:
        o.pop("_score")
    return out[:limit]
