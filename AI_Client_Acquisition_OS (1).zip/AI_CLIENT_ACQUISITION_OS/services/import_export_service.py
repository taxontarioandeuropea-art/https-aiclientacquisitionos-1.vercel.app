"""CSV / XLSX import (with preview + auto column mapping) and export of leads, CRM, pipeline, campaign results,
company research and sales reports."""
from __future__ import annotations

import csv
import io
import re
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from sqlalchemy.orm import Session

from adapters.base import SourceError
from adapters.csv_adapter import CSVLeadSource
from adapters.excel_adapter import ExcelLeadSource
from adapters.mapping import (KIND_FIELDS, KINDS, apply_mapping, auto_map, available_targets, norm_header, required_targets)
from config import config
from core import audit
from core.constants import PIPELINE_STAGES, STAGE_LABELS
from core.errors import AppError, ValidationProblem
from core.utils import normalize_company_name, parse_date, sanitize_text
from database.models import (Campaign, Company, Interaction, Lead, Person, Service, Signal, Task)
from engines import analytics_engine
from engines.lead_hunter import run_source
from services import campaign_service, company_service, crm_service, lead_service

ALLOWED_EXT = {".csv": CSVLeadSource, ".xlsx": ExcelLeadSource}


def _source_for(filename: str):
    ext = Path(filename or "").suffix.lower()
    if ext not in ALLOWED_EXT:
        raise ValidationProblem("Unsupported file type", operation="import file",
                                cause=f"'{ext or 'no extension'}' is not allowed.", suggestion="Upload a .csv or .xlsx file.")
    return ALLOWED_EXT[ext]()


def _safe_name(filename: str) -> str:
    base = Path(filename or "upload").name
    return re.sub(r"[^A-Za-z0-9._-]", "_", base)[:80] or "upload"


def preview(kind: str, filename: str, content: bytes) -> dict:
    if kind not in KINDS:
        raise ValidationProblem(f"Unknown import type '{kind}'", operation="import preview", suggestion=f"Use one of: {', '.join(KINDS)}")
    try:
        headers, rows = _source_for(filename).read_table(content)
    except SourceError as exc:
        raise AppError(str(exc), operation="read import file", cause=exc.cause or None, suggestion=exc.suggestion or None)
    mapping = auto_map(headers, kind)
    mapped_targets = set(mapping.values())
    return {"kind": kind, "filename": _safe_name(filename), "headers": headers, "row_count": len(rows),
            "mapping": mapping, "sample": [{h: str(r.get(h, ""))[:80] for h in headers} for r in rows[:5]],
            "available_targets": available_targets(kind), "required": required_targets(kind),
            "missing_required": [t for t in required_targets(kind) if t not in mapped_targets]}


def commit(db: Session, kind: str, filename: str, content: bytes, *, mapping: Optional[dict[str, str]] = None,
           campaign_id: Optional[int] = None, actor: str = "user") -> dict:
    src = _source_for(filename)
    try:
        headers, rows = src.read_table(content)
    except SourceError as exc:
        raise AppError(str(exc), operation="read import file", cause=exc.cause or None, suggestion=exc.suggestion or None)
    mapping = {h: t for h, t in (mapping or auto_map(headers, kind)).items() if h in headers and t in set(available_targets(kind))}
    missing = [t for t in required_targets(kind) if t not in set(mapping.values())]
    if missing:
        raise ValidationProblem("Required column not found", operation=f"import {kind}",
                                cause=f"No column is mapped to: {', '.join(missing)}.",
                                suggestion="Adjust the column mapping in the preview step.")
    (config.import_dir / f"{datetime.now():%Y%m%d-%H%M%S}-{_safe_name(filename)}").write_bytes(content)
    label = _safe_name(filename)
    if kind in ("leads", "companies", "contacts"):
        if kind == "companies" and not campaign_id:          # plain company list: no leads are created
            return {"kind": kind, **_ingest_companies_only(db, src, content, mapping, label, actor)}
        res = run_source(db, src, campaign_id=campaign_id, label=label, qualify=True, actor=actor,
                         params={"content": content, "mapping": mapping, "kind": kind, "label": label})
        return {"kind": kind, **res}
    return {"kind": kind, **_import_other(db, kind, rows, mapping, label, actor)}


def _ingest_companies_only(db, src, content, mapping, label, actor) -> dict:
    recs = src.fetch(content=content, mapping=mapping, kind="companies", label=label)
    return lead_service.ingest_records(db, recs, campaign_id=None, source_label=label, create_leads=False, actor=actor).as_dict()


def _import_other(db: Session, kind: str, rows: list[dict], mapping: dict, label: str, actor: str) -> dict:
    created = skipped = 0
    errors: list[dict] = []
    for i, raw in enumerate(rows, start=2):
        parts = apply_mapping(raw, mapping)
        try:
            with db.begin_nested():
                if kind == "campaigns":
                    d = dict(parts.get("campaign", {}))
                    names = [s.strip() for s in str(d.pop("services", "")).replace(";", ",").split(",") if s.strip()]
                    ids = [s.id for s in db.query(Service).filter(Service.name.in_(names)).all()] if names else None
                    campaign_service.create_campaign(db, d, service_ids=ids, actor=actor)
                elif kind == "services":
                    campaign_service.create_service(db, dict(parts.get("service", {})), actor=actor)
                elif kind == "interactions":
                    d = parts.get("interaction", {})
                    nn = normalize_company_name(str(d.get("company", "")))
                    company = next((c for c in db.query(Company).filter(Company.normalized_name == nn, Company.archived.is_(False)).all()), None)
                    if not company:
                        raise ValidationProblem(f"Company '{d.get('company')}' was not found — import companies first")
                    lead = db.query(Lead).filter(Lead.company_id == company.id).order_by(Lead.id).first()
                    when = parse_date(d.get("occurred_at"))
                    crm_service.log_interaction(
                        db, lead_id=lead.id if lead else None, company_id=company.id,
                        type=str(d.get("type", "note")).lower() if str(d.get("type", "note")).lower() in
                        ("email", "linkedin", "call", "meeting", "note", "form", "other") else "note",
                        direction=str(d.get("direction", "internal")).lower() if str(d.get("direction", "internal")).lower() in
                        ("outbound", "inbound", "internal") else "internal",
                        subject=d.get("subject"), body=d.get("body"), outcome=d.get("outcome"),
                        occurred_at=datetime.combine(when, datetime.min.time()) if when else None, actor=actor)
            created += 1
        except (AppError, ValueError) as exc:
            errors.append({"row": i, "message": str(exc)}); skipped += 1
    audit.log(db, "import", f"Imported {created} {kind} from {label} ({skipped} skipped)", actor=actor,
              details={"kind": kind, "created": created, "skipped": skipped, "errors": errors[:20]})
    return {"created": created, "skipped": skipped, "errors": errors}


# ------------------------------------------------------------------ export
def safe_cell(v: Any) -> Any:
    """Neutralise spreadsheet formula injection."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return v


def _csv_bytes(columns: list[str], rows: list[dict]) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(columns)
    for r in rows:
        w.writerow([safe_cell(r.get(c, "")) for c in columns])
    return buf.getvalue().encode("utf-8-sig")


def _xlsx_bytes(sheets: dict[str, tuple[list[str], list[dict]]]) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    wb.remove(wb.active)
    for name, (cols, rows) in sheets.items():
        ws = wb.create_sheet(re.sub(r"[\[\]:*?/\\]", "-", name)[:31])
        ws.append(cols)
        for c in ws[1]:
            c.font = Font(bold=True)
        for r in rows:
            ws.append([safe_cell(r.get(c, "")) for c in cols])
        for i, c in enumerate(cols, start=1):
            ws.column_dimensions[ws.cell(1, i).column_letter].width = min(50, max(10, len(c) + 4))
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _leads_rows(db: Session, campaign_id: Optional[int] = None, stage_order: bool = False) -> list[dict]:
    items = lead_service.list_leads(db, campaign_id=campaign_id, limit=100000, sort="stage" if stage_order else "priority")["items"]
    est = crm_service.stage_estimates(db)
    out = []
    for l in items:
        p = l["person"] or {}
        out.append({"Lead ID": l["id"], "Company": l["company"]["name"], "Website": l["company"]["website"], "Country": l["company"]["country"],
                    "Industry": l["company"]["industry"], "Employees": l["company"]["employees"], "Contact": p.get("full_name"),
                    "Title": p.get("title"), "Email": p.get("email"), "Campaign": (l["campaign"] or {}).get("name"),
                    "Stage": STAGE_LABELS.get(l["status"], l["status"]), "Priority": l["overall_priority"],
                    "Fit": l["dimensions"]["fit"]["level"], "Need": l["dimensions"]["need"]["level"],
                    "Buying signal": l["dimensions"]["signal"]["level"], "Ability to pay": l["dimensions"]["ability_to_pay"]["level"],
                    "Contactability": l["dimensions"]["contactability"]["level"], "Primary signal": l["primary_signal"],
                    "Recommended service": l["recommended_service"], "Detected problem": l["detected_problem"],
                    "Potential MRR": l["potential_mrr"], "Actual MRR": l["actual_mrr"],
                    "Internal estimate %": round(est.get(l["status"], 0) * 100), "Next action": l["next_action"],
                    "Next action date": l["next_action_date"], "Created": l["created_at"]})
    return out


def _table(rows: list[dict]) -> tuple[list[str], list[dict]]:
    cols = list(rows[0].keys()) if rows else ["(no data)"]
    return cols, rows


def build_export(db: Session, kind: str, fmt: str = "xlsx", campaign_id: Optional[int] = None) -> tuple[str, bytes, str]:
    fmt = fmt.lower()
    if fmt not in ("csv", "xlsx"):
        raise ValidationProblem("Export format must be csv or xlsx", operation="export")
    sheets: dict[str, tuple[list[str], list[dict]]] = {}
    if kind == "leads":
        sheets["Leads"] = _table(_leads_rows(db, campaign_id))
    elif kind == "pipeline":
        rows = _leads_rows(db, campaign_id, stage_order=True)
        order = {STAGE_LABELS[s]: i for i, s in enumerate(PIPELINE_STAGES)}
        rows.sort(key=lambda r: (order.get(r["Stage"], 99), -(r["Potential MRR"] or 0)))
        sheets["Pipeline"] = _table(rows)
    elif kind == "crm":
        sheets["Companies"] = _table([{k: (", ".join(v) if isinstance(v, list) else v) for k, v in c.as_dict().items()
                                       if k not in ("research_report", "field_sources")} for c in db.query(Company).filter(Company.archived.is_(False)).all()])
        sheets["Contacts"] = _table([p.as_dict() for p in db.query(Person).all()])
        sheets["Leads"] = _table(_leads_rows(db, campaign_id))
        sheets["Interactions"] = _table([i.as_dict() for i in db.query(Interaction).order_by(Interaction.occurred_at).all()])
        sheets["Tasks"] = _table([t.as_dict() for t in db.query(Task).all()])
    elif kind == "campaign_results":
        rows = []
        for c in db.query(Campaign).order_by(Campaign.name).all():
            s = campaign_service.campaign_stats(db, c.id)
            r = {"Campaign": c.name, "Status": c.campaign_status, **{k.title(): v for k, v in s["counts"].items()},
                 "MRR": s["mrr"], "Pipeline value": s["pipeline_value"], "Avg MRR": s["avg_mrr"]}
            for k, v in s["rates"].items():
                r[k.replace("_", " ").title() + " %"] = v["value"]
            rows.append(r)
        sheets["Campaign results"] = _table(rows)
    elif kind == "company_research":
        rows = []
        for sg in db.query(Signal).join(Company).filter(Company.archived.is_(False)).order_by(Company.name).all():
            rows.append({"Company": sg.company.name, "Signal": sg.signal_type, "Description": sg.description, "Kind": sg.kind,
                         "Evidence": sg.evidence_text, "Source": sg.source, "Source URL": sg.source_url,
                         "Date detected": str(sg.date_detected), "Confidence": sg.confidence, "Verified": sg.verified, "Origin": sg.origin})
        sheets["Signals and evidence"] = _table(rows)
    elif kind == "sales_reports":
        f = analytics_engine.funnel(db, campaign_id=campaign_id)
        sheets["Funnel"] = _table([{"Stage": s["label"], "Count": s["count"], "% of leads": s["pct_of_leads"], "% of previous": s["pct_of_previous"]} for s in f["stages"]]
                                  + [{"Stage": "MRR (won)", "Count": f["mrr"]}, {"Stage": "Pipeline value (potential MRR)", "Count": f["pipeline_value"]}])
        for by in ("campaign", "industry", "country", "service", "signal", "template"):
            sheets[f"MRR by {by}"] = _table([{by.title(): r["key"], "Leads": r["leads"], "Contacted": r["contacted"], "Won": r["won"],
                                              "MRR": r["mrr"], "Pipeline MRR": r["pipeline_mrr"]} for r in analytics_engine.mrr_breakdown(db, by, campaign_id)])
    else:
        raise ValidationProblem(f"Unknown export '{kind}'", operation="export",
                                suggestion="Use: leads, crm, pipeline, campaign_results, company_research, sales_reports")
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    if fmt == "xlsx":
        data, name, mime = _xlsx_bytes(sheets), f"{kind}-{stamp}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    elif len(sheets) == 1:
        (cols, rows), = sheets.values()
        data, name, mime = _csv_bytes(cols, rows), f"{kind}-{stamp}.csv", "text/csv"
    else:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for sname, (cols, rows) in sheets.items():
                z.writestr(f"{re.sub(r'[^A-Za-z0-9]+', '_', sname).strip('_')}.csv", _csv_bytes(cols, rows))
        data, name, mime = buf.getvalue(), f"{kind}-{stamp}.zip", "application/zip"
    (config.export_dir / name).write_bytes(data)
    audit.log(db, "export", f"Exported {kind} as {fmt.upper()} ({sum(len(r) for _, r in sheets.values())} rows)", details={"file": name})
    return name, data, mime
