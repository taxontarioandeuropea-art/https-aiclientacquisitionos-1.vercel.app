"""Companies and contacts: validation, CRUD, duplicate detection and (user-confirmed) merging."""
from __future__ import annotations

import re
from typing import Any, Optional

from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from core import audit
from core.constants import PIPELINE_STAGES
from core.errors import AppError, NotFound, ValidationProblem
from core.utils import (classify_title, first_last, name_similarity, norm_country, normalize_company_name,
                        normalize_domain, normalize_email, normalize_linkedin, normalize_phone, parse_int,
                        parse_number, sanitize_text, sanitize_url, split_list)
from database.models import (Company, DuplicateDismissal, Interaction, Lead, OutreachMessage, Person, Signal,
                             StageHistory, Task)

COMPANY_FIELDS = ["name", "legal_name", "website", "country", "state", "city", "address", "industry", "subindustry",
                  "employees", "estimated_revenue", "estimated_scale", "ownership_type", "technology_stack",
                  "accounting_software", "growth_status", "description", "email", "phone", "notes", "source", "source_url",
                  "nip", "regon", "krs_number", "legal_form"]
PERSON_FIELDS = ["first_name", "last_name", "full_name", "title", "department", "email", "phone", "linkedin_url",
                 "decision_maker_level", "source", "source_url", "confidence", "notes"]
_LEN = {"name": 255, "legal_name": 255, "website": 500, "country": 80, "state": 80, "city": 120, "address": 300,
        "industry": 120, "subindustry": 120, "estimated_scale": 120, "ownership_type": 120, "accounting_software": 120,
        "growth_status": 120, "description": 4000, "email": 255, "phone": 60, "notes": 4000, "source": 255, "source_url": 500,
        "legal_form": 120}


def clean_company(data: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k in COMPANY_FIELDS:
        if k not in data:
            continue
        v = data[k]
        if k == "employees":
            out[k] = parse_int(v)
        elif k == "estimated_revenue":
            out[k] = parse_number(v)
        elif k == "technology_stack":
            out[k] = split_list(v)
        elif k in ("website", "source_url"):
            out[k] = sanitize_url(v)
        elif k == "country":
            out[k] = norm_country(sanitize_text(v, 80))
        elif k == "email":
            out[k] = normalize_email(sanitize_text(v, 255)) or None
        elif k in ("nip", "regon", "krs_number"):
            digits = re.sub(r"\D", "", str(v or ""))
            out[k] = digits or None
        else:
            out[k] = sanitize_text(v, _LEN.get(k)) or None
    if out.get("employees") is not None and out["employees"] < 0:
        raise ValidationProblem("Employees cannot be negative", operation="save company")
    if out.get("email") and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", out["email"]):
        raise ValidationProblem(f"'{out['email']}' is not a valid email address", operation="save company",
                                suggestion="Fix the address or leave it empty — never guess an address.")
    if out.get("nip") and len(out["nip"]) != 10:
        raise ValidationProblem(f"'{out['nip']}' is not a valid NIP (must be 10 digits)", operation="save company")
    if out.get("regon") and len(out["regon"]) not in (9, 14):
        raise ValidationProblem(f"'{out['regon']}' is not a valid REGON (must be 9 or 14 digits)", operation="save company")
    if out.get("krs_number"):
        out["krs_number"] = out["krs_number"].zfill(10)
        if len(out["krs_number"]) != 10:
            raise ValidationProblem(f"'{v}' is not a valid KRS number (must be at most 10 digits)", operation="save company")
    return out


def _apply_derived(c: Company) -> None:
    c.domain = normalize_domain(c.website) or None
    c.normalized_name = normalize_company_name(c.name) or None


def get_company(db: Session, company_id: int) -> Company:
    c = db.get(Company, company_id)
    if not c:
        raise NotFound("Company", company_id)
    return c


def create_company(db: Session, data: dict[str, Any], *, source: Optional[str] = None, actor: str = "user",
                   is_demo: bool = False, log: bool = True) -> Company:
    clean = clean_company(data)
    if not clean.get("name"):
        raise ValidationProblem("Company name is required", operation="create company",
                                suggestion="Enter the company's trading name.")
    clean.setdefault("technology_stack", [])
    c = Company(**clean, is_demo=is_demo)
    if not c.source:
        c.source = source or "Manual entry"
    _apply_derived(c)
    db.add(c)
    db.flush()
    if log:
        audit.log(db, "company_created", f"Company created: {c.name}", entity_type="company", entity_id=c.id,
                  actor=actor, details={"source": c.source})
    return c


def update_company(db: Session, company_id: int, data: dict[str, Any], *, actor: str = "user") -> Company:
    c = get_company(db, company_id)
    clean = clean_company(data)
    if "name" in clean and not clean["name"]:
        raise ValidationProblem("Company name cannot be empty", operation="update company")
    changes = {}
    for k, v in clean.items():
        old = getattr(c, k)
        if old != v:
            changes[k] = {"from": old, "to": v}
            setattr(c, k, v)
    _apply_derived(c)
    if changes:
        audit.log(db, "company_updated", f"Company edited: {c.name} ({', '.join(changes)})", entity_type="company",
                  entity_id=c.id, actor=actor, details={"changes": changes})
    db.flush()
    return c


def delete_company(db: Session, company_id: int, actor: str = "user") -> None:
    c = get_company(db, company_id)
    audit.log(db, "company_deleted", f"Company deleted: {c.name} (with {len(c.leads)} leads, {len(c.people)} contacts)",
              entity_type="company", entity_id=c.id, actor=actor,
              details={"snapshot": c.as_dict(), "leads": len(c.leads), "people": len(c.people)})
    db.delete(c)


# ------------------------------------------------------------------ people
def clean_person(data: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k in PERSON_FIELDS:
        if k not in data:
            continue
        v = data[k]
        if k == "email":
            out[k] = normalize_email(sanitize_text(v, 255)) or None
        elif k == "linkedin_url":
            out[k] = sanitize_url(v)
        elif k == "source_url":
            out[k] = sanitize_url(v)
        elif k == "confidence":
            try:
                out[k] = max(0.0, min(1.0, float(v)))
            except (TypeError, ValueError):
                out[k] = None
        else:
            out[k] = sanitize_text(v, 4000 if k == "notes" else 255) or None
    if out.get("email") and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", out["email"]):
        raise ValidationProblem(f"'{out['email']}' is not a valid email address", operation="save contact",
                                suggestion="Fix the address or leave it empty — never guess an address.")
    return out


def _finish_person(p: Person) -> None:
    if not p.full_name:
        p.full_name = " ".join(x for x in [p.first_name, p.last_name] if x) or None
    if p.full_name and not (p.first_name or p.last_name):
        p.first_name, p.last_name = first_last(p.full_name)
    if not p.decision_maker_level or p.decision_maker_level == "unknown":
        p.decision_maker_level = classify_title(p.title)


def create_person(db: Session, company_id: int, data: dict[str, Any], *, actor: str = "user", is_demo: bool = False,
                  log: bool = True) -> Person:
    get_company(db, company_id)
    clean = clean_person(data)
    if not (clean.get("full_name") or clean.get("first_name") or clean.get("last_name") or clean.get("email")):
        raise ValidationProblem("A contact needs at least a name or an email", operation="create contact")
    p = Person(company_id=company_id, is_demo=is_demo, **clean)
    if p.confidence is None:
        p.confidence = 0.8
    if not p.source:
        p.source = "Manual entry"
    _finish_person(p)
    db.add(p)
    db.flush()
    if log:
        audit.log(db, "person_created", f"Contact added: {p.full_name or p.email}", entity_type="person", entity_id=p.id, actor=actor)
    return p


def update_person(db: Session, person_id: int, data: dict[str, Any], *, actor: str = "user") -> Person:
    p = db.get(Person, person_id)
    if not p:
        raise NotFound("Contact", person_id)
    clean = clean_person(data)
    for k, v in clean.items():
        setattr(p, k, v)
    if "title" in clean and "decision_maker_level" not in clean:
        p.decision_maker_level = classify_title(p.title)
    _finish_person(p)
    audit.log(db, "person_updated", f"Contact edited: {p.full_name}", entity_type="person", entity_id=p.id, actor=actor,
              details={"fields": list(clean)})
    db.flush()
    return p


def delete_person(db: Session, person_id: int, actor: str = "user") -> None:
    p = db.get(Person, person_id)
    if not p:
        raise NotFound("Contact", person_id)
    audit.log(db, "person_deleted", f"Contact deleted: {p.full_name}", entity_type="person", entity_id=p.id, actor=actor,
              details={"snapshot": p.as_dict()})
    db.delete(p)


# ------------------------------------------------------------------ listing
_SORTS = {"name": Company.name, "country": Company.country, "industry": Company.industry,
          "employees": Company.employees, "created": Company.created_at, "updated": Company.updated_at}


def list_companies(db: Session, *, q: Optional[str] = None, country: Optional[str] = None, industry: Optional[str] = None,
                   campaign_id: Optional[int] = None, min_employees: Optional[int] = None, max_employees: Optional[int] = None,
                   signal: Optional[str] = None, sort: str = "name", direction: str = "asc",
                   limit: int = 300, offset: int = 0, include_archived: bool = False) -> dict:
    qry = db.query(Company)
    if not include_archived:
        qry = qry.filter(Company.archived.is_(False))
    if q:
        like = f"%{q.strip()}%"
        qry = qry.filter(or_(Company.name.ilike(like), Company.domain.ilike(like), Company.city.ilike(like),
                             Company.industry.ilike(like)))
    if country:
        qry = qry.filter(Company.country == country)
    if industry:
        qry = qry.filter(Company.industry.ilike(f"%{industry}%"))
    if min_employees is not None:
        qry = qry.filter(Company.employees >= min_employees)
    if max_employees is not None:
        qry = qry.filter(Company.employees <= max_employees)
    if campaign_id:
        qry = qry.filter(Company.id.in_(db.query(Lead.company_id).filter(Lead.campaign_id == campaign_id)))
    if signal:
        qry = qry.filter(Company.id.in_(db.query(Signal.company_id).filter(Signal.signal_type == signal)))
    total = qry.count()
    col = _SORTS.get(sort, Company.name)
    qry = qry.order_by(col.desc() if direction == "desc" else col.asc(), Company.id)
    rows = qry.offset(offset).limit(limit).all()
    ids = [c.id for c in rows]
    lead_counts = dict(db.query(Lead.company_id, func.count(Lead.id)).filter(Lead.company_id.in_(ids)).group_by(Lead.company_id).all()) if ids else {}
    sig_counts = dict(db.query(Signal.company_id, func.count(Signal.id)).filter(Signal.company_id.in_(ids)).group_by(Signal.company_id).all()) if ids else {}
    best = {}
    if ids:
        for cid, pr in db.query(Lead.company_id, Lead.overall_priority).filter(Lead.company_id.in_(ids)).all():
            rank = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}.get(pr or "", 0)
            if rank > best.get(cid, (0, None))[0]:
                best[cid] = (rank, pr)
    items = []
    for c in rows:
        items.append({**{k: getattr(c, k) for k in ("id", "name", "website", "country", "state", "city", "industry", "subindustry",
                                                     "employees", "accounting_software", "growth_status", "source", "is_demo")},
                      "leads": lead_counts.get(c.id, 0), "signals": sig_counts.get(c.id, 0),
                      "best_priority": best.get(c.id, (0, None))[1],
                      "last_researched_at": c.last_researched_at.isoformat() if c.last_researched_at else None})
    return {"items": items, "total": total}


# ------------------------------------------------------------- duplicates
def _phone_key(c: Company) -> str:
    return normalize_phone(c.phone)


def score_pair(a: Company, b: Company, extra_reasons: Optional[list[tuple[float, str]]] = None) -> tuple[float, list[str]]:
    parts: list[tuple[float, str]] = list(extra_reasons or [])
    if a.domain and a.domain == b.domain:
        parts.append((0.95, f"Same website domain ({a.domain})"))
    if a.normalized_name and a.normalized_name == b.normalized_name:
        bonus = 0.1 if (a.country and a.country == b.country) else 0.0
        parts.append((0.75 + bonus, "Same name once legal suffixes (LLC, Inc., Sp. z o.o.) are removed"))
    elif a.normalized_name and b.normalized_name:
        sim = name_similarity(a.normalized_name, b.normalized_name)
        if sim >= 0.9:
            parts.append((0.6, f"Very similar names ({sim:.0%})"))
        elif sim >= 0.82:
            parts.append((0.45, f"Similar names ({sim:.0%})"))
    pa, pb = _phone_key(a), _phone_key(b)
    if pa and pa == pb:
        parts.append((0.7, "Same phone number"))
    if not parts:
        return 0.0, []
    p = 1.0
    for s, _ in parts:
        p *= (1 - s)
    score = min(0.99, 1 - p)
    if a.country and b.country and a.country != b.country and not (a.domain and a.domain == b.domain):
        score *= 0.6
        parts.append((0, f"Different countries ({a.country} / {b.country}) — confidence reduced"))
    return round(score, 2), [r for _, r in parts]


def confidence_label(score: float) -> str:
    return "Very likely" if score >= 0.85 else "Probable" if score >= 0.65 else "Possible"


def find_duplicates(db: Session, *, min_score: float = 0.45, include_dismissed: bool = False) -> list[dict]:
    companies = db.query(Company).filter(Company.archived.is_(False)).all()
    by_id = {c.id: c for c in companies}
    blocks: dict[str, set[int]] = {}

    def block(key: str, cid: int):
        if key:
            blocks.setdefault(key, set()).add(cid)

    for c in companies:
        block("d:" + (c.domain or ""), c.id) if c.domain else None
        if c.normalized_name:
            block("n:" + c.normalized_name, c.id)
            block("t:" + c.normalized_name.split()[0], c.id) if len(c.normalized_name.split()[0]) >= 3 else None
        if _phone_key(c):
            block("p:" + _phone_key(c), c.id)
    person_reasons: dict[tuple[int, int], list[tuple[float, str]]] = {}
    seen_email: dict[str, int] = {}
    seen_li: dict[str, int] = {}
    for p in db.query(Person).filter(Person.company_id.isnot(None)).all():
        if p.company_id not in by_id:
            continue
        for key, table, label in ((normalize_email(p.email), seen_email, "Same contact email"),
                                  (normalize_linkedin(p.linkedin_url), seen_li, "Same contact LinkedIn profile")):
            if not key:
                continue
            other = table.get(key)
            if other and other != p.company_id:
                pair = tuple(sorted((other, p.company_id)))
                person_reasons.setdefault(pair, []).append((0.85, f"{label} ({key})"))
                block("x:" + key, other); block("x:" + key, p.company_id)
            table.setdefault(key, p.company_id)
    pairs: set[tuple[int, int]] = set()
    for ids in blocks.values():
        ids = sorted(ids)
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                pairs.add((ids[i], ids[j]))
    dismissed = set()
    if not include_dismissed:
        dismissed = {(d.id_a, d.id_b) for d in db.query(DuplicateDismissal).filter_by(entity_type="company").all()}
    out = []
    for a_id, b_id in pairs:
        if (a_id, b_id) in dismissed:
            continue
        a, b = by_id[a_id], by_id[b_id]
        score, reasons = score_pair(a, b, person_reasons.get((a_id, b_id)))
        if score >= min_score:
            out.append({"score": score, "label": confidence_label(score), "reasons": reasons,
                        "a": _dup_side(db, a), "b": _dup_side(db, b)})
    out.sort(key=lambda x: -x["score"])
    return out


def _dup_side(db: Session, c: Company) -> dict:
    return {"id": c.id, "name": c.name, "website": c.website, "country": c.country, "city": c.city, "industry": c.industry,
            "employees": c.employees, "phone": c.phone, "source": c.source, "is_demo": c.is_demo,
            "leads": db.query(Lead).filter_by(company_id=c.id).count(),
            "contacts": db.query(Person).filter_by(company_id=c.id).count(),
            "signals": db.query(Signal).filter_by(company_id=c.id).count()}


def find_matches_for(db: Session, data: dict[str, Any], *, min_score: float = 0.45, exclude_id: Optional[int] = None) -> list[dict]:
    """Existing companies that may be the same as a company about to be created."""
    probe = Company(name=data.get("name") or "", website=data.get("website"), country=norm_country(data.get("country")),
                    phone=data.get("phone"))
    _apply_derived(probe)
    cand = db.query(Company).filter(Company.archived.is_(False))
    filters = []
    if probe.domain:
        filters.append(Company.domain == probe.domain)
    if probe.normalized_name:
        tok = probe.normalized_name.split()[0]
        filters.append(Company.normalized_name.like(f"{tok}%"))
    if not filters:
        return []
    out = []
    for c in cand.filter(or_(*filters)).all():
        if c.id == exclude_id:
            continue
        s, r = score_pair(probe, c)
        if s >= min_score:
            out.append({"company_id": c.id, "name": c.name, "score": s, "label": confidence_label(s), "reasons": r})
    return sorted(out, key=lambda x: -x["score"])


def dismiss_duplicate(db: Session, a_id: int, b_id: int) -> None:
    a, b = sorted((a_id, b_id))
    if not db.query(DuplicateDismissal).filter_by(entity_type="company", id_a=a, id_b=b).first():
        db.add(DuplicateDismissal(entity_type="company", id_a=a, id_b=b))
        audit.log(db, "duplicate_dismissed", f"Marked companies {a} and {b} as not duplicates", entity_type="company", entity_id=a)
        db.flush()


_STAGE_IDX = {s: i for i, s in enumerate(PIPELINE_STAGES)}


def merge_companies(db: Session, primary_id: int, secondary_id: int, field_choices: Optional[dict[str, str]] = None,
                    actor: str = "user") -> dict:
    """Explicit, user-confirmed merge. The secondary record is archived (kept, marked merged_into) — never silently deleted."""
    if primary_id == secondary_id:
        raise ValidationProblem("Choose two different companies to merge", operation="merge companies")
    p, s = get_company(db, primary_id), get_company(db, secondary_id)
    if s.archived or p.archived:
        raise AppError("One of these companies was already merged or archived", operation="merge companies",
                       suggestion="Refresh the duplicate list.", status_code=409)
    snapshot = s.as_dict()
    field_choices = field_choices or {}
    changed = []
    for k in COMPANY_FIELDS:
        pv, sv = getattr(p, k), getattr(s, k)
        if k == "technology_stack":
            merged = list(dict.fromkeys((pv or []) + (sv or [])))
            if merged != (pv or []):
                p.technology_stack = merged; changed.append(k)
        elif sv not in (None, "", []) and (pv in (None, "", []) or field_choices.get(k) == "secondary"):
            if pv != sv:
                setattr(p, k, sv); changed.append(k)
    p.field_sources = {**(s.field_sources or {}), **(p.field_sources or {})}
    _apply_derived(p)
    moved = {"contacts": 0, "leads": 0, "merged_leads": 0, "signals": 0, "interactions": 0, "tasks": 0}
    for person in list(s.people):
        person.company_id = p.id; moved["contacts"] += 1
    p_leads = {l.campaign_id: l for l in p.leads}
    for lead in list(s.leads):
        target = p_leads.get(lead.campaign_id) if lead.campaign_id is not None else None
        if target:                     # same campaign on both sides: fold the secondary lead into the primary lead
            for m in list(lead.messages): m.lead_id = target.id
            for t in list(lead.tasks): t.lead_id = target.id
            for h in list(lead.history): h.lead_id = target.id
            for i in db.query(Interaction).filter(Interaction.lead_id == lead.id).all(): i.lead_id = target.id
            if _STAGE_IDX.get(lead.status, -1) > _STAGE_IDX.get(target.status, -1) and target.status in _STAGE_IDX:
                target.status = lead.status
            if not target.person_id and lead.person_id:
                target.person_id = lead.person_id
            db.flush()
            db.delete(lead)
            moved["merged_leads"] += 1
        else:
            lead.company_id = p.id; moved["leads"] += 1
    for sig in list(s.signals):
        sig.company_id = p.id; moved["signals"] += 1
    for it in list(s.interactions):
        it.company_id = p.id; moved["interactions"] += 1
    for t in db.query(Task).filter(Task.company_id == s.id).all():
        t.company_id = p.id; moved["tasks"] += 1
    s.archived, s.merged_into_id = True, p.id
    db.flush()
    db.expire_all()
    audit.log(db, "companies_merged", f"Merged '{s.name}' into '{p.name}'", entity_type="company", entity_id=p.id, actor=actor,
              details={"secondary_snapshot": snapshot, "moved": moved, "fields_changed": changed})
    return {"primary_id": p.id, "moved": moved, "fields_changed": changed,
            "lead_ids": [l.id for l in db.query(Lead).filter_by(company_id=p.id).all()]}


def find_person_duplicates(db: Session) -> list[dict]:
    out, seen = [], {}
    for p in db.query(Person).all():
        for key in (("e", normalize_email(p.email)), ("l", normalize_linkedin(p.linkedin_url)),
                    ("n", f"{p.company_id}:{(p.full_name or '').strip().lower()}" if p.full_name and p.company_id else "")):
            if not key[1]:
                continue
            other = seen.get(key)
            if other and other.id != p.id:
                out.append({"a": other.as_dict(), "b": p.as_dict(),
                            "reason": {"e": "Same email", "l": "Same LinkedIn", "n": "Same name at the same company"}[key[0]]})
            else:
                seen[key] = p
    return out


def merge_people(db: Session, primary_id: int, secondary_id: int, actor: str = "user") -> Person:
    p, s = db.get(Person, primary_id), db.get(Person, secondary_id)
    if not p or not s or p.id == s.id:
        raise ValidationProblem("Choose two different existing contacts", operation="merge contacts")
    for k in PERSON_FIELDS:
        if getattr(p, k) in (None, "") and getattr(s, k) not in (None, ""):
            setattr(p, k, getattr(s, k))
    db.query(Lead).filter(Lead.person_id == s.id).update({"person_id": p.id})
    db.query(Interaction).filter(Interaction.person_id == s.id).update({"person_id": p.id})
    db.query(OutreachMessage).filter(OutreachMessage.person_id == s.id).update({"person_id": p.id})
    audit.log(db, "people_merged", f"Merged contact '{s.full_name}' into '{p.full_name}'", entity_type="person", entity_id=p.id,
              actor=actor, details={"secondary_snapshot": s.as_dict()})
    db.delete(s)
    db.flush()
    return p
