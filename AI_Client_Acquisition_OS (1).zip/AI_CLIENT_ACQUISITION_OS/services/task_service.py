"""Tasks: manual and automatically generated (idempotent via dedupe_key)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Optional

from sqlalchemy.orm import Session

from core import audit
from core.constants import TASK_TYPES
from core.errors import NotFound, ValidationProblem
from core.utils import parse_date, sanitize_text, today as _today, utcnow
from database.models import Company, Lead, Task


def create_task(db: Session, title: str, *, due_date: Optional[date] = None, task_type: str = "other",
                description: Optional[str] = None, priority: str = "MEDIUM", lead_id: Optional[int] = None,
                company_id: Optional[int] = None, auto_generated: bool = False, dedupe_key: Optional[str] = None,
                is_demo: bool = False, actor: str = "user") -> Task:
    title = sanitize_text(title, 300) or ""
    if not title:
        raise ValidationProblem("Task title is required", operation="create task")
    if task_type not in TASK_TYPES:
        raise ValidationProblem(f"Unknown task type '{task_type}'", operation="create task",
                                suggestion=f"Use one of: {', '.join(TASK_TYPES)}")
    if dedupe_key:
        existing = db.query(Task).filter(Task.dedupe_key == dedupe_key, Task.status == "open").first()
        if existing:
            return existing
    if lead_id and not company_id:
        lead = db.get(Lead, lead_id)
        company_id = lead.company_id if lead else None
    t = Task(title=title, description=sanitize_text(description, 2000), task_type=task_type,
             priority=priority if priority in ("HIGH", "MEDIUM", "LOW") else "MEDIUM", due_date=due_date,
             lead_id=lead_id, company_id=company_id, auto_generated=auto_generated, dedupe_key=dedupe_key,
             is_demo=is_demo)
    db.add(t)
    db.flush()
    if not auto_generated:
        audit.log(db, "task_created", f"Task created: {title}", entity_type="task", entity_id=t.id, actor=actor)
    return t


def update_task(db: Session, task_id: int, data: dict[str, Any]) -> Task:
    t = db.get(Task, task_id)
    if not t:
        raise NotFound("Task", task_id)
    for k in ("title", "description", "priority", "task_type", "status"):
        if k in data and data[k] is not None:
            setattr(t, k, sanitize_text(data[k], 300 if k == "title" else 2000))
    if "due_date" in data:
        t.due_date = parse_date(data["due_date"])
    if t.status == "done" and not t.completed_at:
        t.completed_at = utcnow()
    db.flush()
    return t


def complete_task(db: Session, task_id: int, actor: str = "user") -> Task:
    t = db.get(Task, task_id)
    if not t:
        raise NotFound("Task", task_id)
    t.status, t.completed_at = "done", utcnow()
    if t.lead_id:
        lead = db.get(Lead, t.lead_id)
        if lead:
            sync_next_action(db, lead)
    audit.log(db, "task_completed", f"Task completed: {t.title}", entity_type="task", entity_id=t.id, actor=actor)
    db.flush()
    return t


def delete_task(db: Session, task_id: int) -> None:
    t = db.get(Task, task_id)
    if not t:
        raise NotFound("Task", task_id)
    audit.log(db, "task_deleted", f"Task deleted: {t.title}", entity_type="task", entity_id=t.id, details=t.as_dict())
    db.delete(t)


def serialize_task(t: Task, on: Optional[date] = None) -> dict:
    on = on or _today()
    d = t.as_dict()
    d["company_name"] = t.lead.company.name if t.lead else None
    if not d["company_name"] and t.company_id:
        d["company_name"] = None
    d["lead_status"] = t.lead.status if t.lead else None
    d["overdue"] = bool(t.status == "open" and t.due_date and t.due_date < on)
    return d


def list_tasks(db: Session, *, on: Optional[date] = None, lead_id: Optional[int] = None,
               company_id: Optional[int] = None, upcoming_days: int = 14) -> dict:
    on = on or _today()
    q = db.query(Task)
    if lead_id:
        q = q.filter(Task.lead_id == lead_id)
    if company_id:
        q = q.filter(Task.company_id == company_id)
    tasks = q.order_by(Task.due_date.is_(None), Task.due_date, Task.id).all()
    names = {c.id: c.name for c in db.query(Company.id, Company.name).all()}
    groups: dict[str, list] = {"overdue": [], "today": [], "upcoming": [], "later": [], "no_date": [], "done": []}
    for t in tasks:
        d = serialize_task(t, on)
        d["company_name"] = names.get(t.company_id) or d["company_name"]
        if t.status == "done":
            groups["done"].append(d)
        elif t.status != "open":
            continue
        elif not t.due_date:
            groups["no_date"].append(d)
        elif t.due_date < on:
            groups["overdue"].append(d)
        elif t.due_date == on:
            groups["today"].append(d)
        elif t.due_date <= on + timedelta(days=upcoming_days):
            groups["upcoming"].append(d)
        else:
            groups["later"].append(d)
    groups["done"] = sorted(groups["done"], key=lambda x: x.get("completed_at") or "", reverse=True)[:25]
    groups["counts"] = {k: len(v) for k, v in groups.items() if isinstance(v, list)}
    return groups


def sync_next_action(db: Session, lead: Lead) -> None:
    """Lead's next action mirrors its earliest open task."""
    t = (db.query(Task).filter(Task.lead_id == lead.id, Task.status == "open")
         .order_by(Task.due_date.is_(None), Task.due_date, Task.id).first())
    if t:
        lead.next_action, lead.next_action_date = t.title[:255], t.due_date


# -------------------------------------------------- automatic task generation
def _stage_task_specs(lead: Lead, on: date) -> list[tuple[str, str, int, str]]:
    company, person = lead.company, lead.person
    name = company.name
    contact = (person.full_name if person and person.full_name else name)
    prio = lead.overall_priority or "MEDIUM"
    s = lead.status
    if s == "NEW":
        return [("research_company", f"Research {name}", 0, prio)]
    if s == "RESEARCHED":
        if not person or not (person.email or person.linkedin_url or person.phone):
            return [("find_decision_maker", f"Find decision maker at {name}", 1, prio)]
        return [("update_crm", f"Review {name}: qualify or mark not a fit", 1, prio)]
    if s == "QUALIFIED":
        return [("send_message", f"Send personalized message to {contact} ({name})", 0, prio)]
    if s == "REPLIED":
        return [("call", f"Reply to {contact} and schedule a call", 0, "HIGH")]
    if s == "CALL":
        return [("prepare_proposal", f"Prepare proposal for {name}", 2, "HIGH")]
    if s == "PROPOSAL":
        return [("follow_up", f"Follow up on proposal: {name}", 3, "HIGH")]
    if s == "NEGOTIATION":
        return [("update_crm", f"Update CRM and agree next step with {name}", 2, "HIGH")]
    if s == "NURTURE":
        return [("follow_up", f"Nurture check-in: {name}", 60, "LOW")]
    return []


def cancel_stale_stage_tasks(db: Session, lead: Lead, keep_stage: Optional[str], include_followups: bool = False) -> int:
    n = 0
    for t in db.query(Task).filter(Task.lead_id == lead.id, Task.status == "open", Task.auto_generated.is_(True)).all():
        parts = (t.dedupe_key or "").split(":")
        stage_part = parts[2] if len(parts) > 2 else ""
        if stage_part == "followup":
            if include_followups:
                t.status = "cancelled"; n += 1
        elif stage_part != keep_stage:
            t.status = "cancelled"; n += 1
    return n


def generate_tasks_for_lead(db: Session, lead: Lead, on: Optional[date] = None) -> list[Task]:
    on = on or _today()
    created = []
    for ttype, title, offset, prio in _stage_task_specs(lead, on):
        key = f"lead:{lead.id}:{lead.status}:{ttype}"
        before = db.query(Task).filter(Task.dedupe_key == key, Task.status == "open").first()
        t = create_task(db, title, due_date=on + timedelta(days=offset), task_type=ttype, priority=prio,
                        lead_id=lead.id, auto_generated=True, dedupe_key=key, is_demo=lead.is_demo)
        if not before:
            created.append(t)
    sync_next_action(db, lead)
    return created


def generate_all(db: Session, campaign_id: Optional[int] = None) -> int:
    q = db.query(Lead).filter(~Lead.status.in_(["WON", "LOST", "NOT_A_FIT"]))
    if campaign_id:
        q = q.filter(Lead.campaign_id == campaign_id)
    n = 0
    for lead in q.all():
        cancel_stale_stage_tasks(db, lead, lead.status)
        n += len(generate_tasks_for_lead(db, lead))
    audit.log(db, "tasks_generated", f"Generated {n} tasks from pipeline state", actor="system")
    return n
