"""SOURCE_REGISTRY (master prompt §5): one entry per external data source. Nothing about a
connector's identity, legal status or rate limit is hardcoded elsewhere — this is the single
place that answers "what sources exist, are they configured, and what are the rules for using them".
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SourceDef:
    source_id: str
    source_name: str
    source_type: str                 # "official_registry"
    base_url: str
    access_method: str                # "rest_jwt" | "rest_keyless" | "soap_session"
    legal_status: str                 # plain-language note on legal basis / ToS
    update_frequency: str
    rate_limit: str
    reliability_score: float          # 0-1, static editorial judgement until outcome data exists (§28)
    discovery_capable: bool           # can it find NEW businesses matching criteria, or only enrich a known one?
    requires_env: list[str] = field(default_factory=list)
    notes: str = ""

    def configured(self) -> bool:
        return all(os.getenv(k) for k in self.requires_env)


SOURCES: dict[str, SourceDef] = {
    "ceidg": SourceDef(
        source_id="ceidg", source_name="CEIDG (Centralna Ewidencja i Informacja o Działalności Gospodarczej)",
        source_type="official_registry", base_url="https://dane.biznes.gov.pl/api/ceidg/v3",
        access_method="rest_jwt",
        legal_status="Public register of sole traders (JDG) and civil partnerships, published by the Polish "
                     "Ministry of Development and Technology. Free for registered integrators; requires accepting "
                     "the published terms of the Hurtownia Danych CEIDG i Biznes.gov.pl API to obtain a JWT.",
        update_frequency="near real-time", rate_limit="50 requests / 3 min, and 1000 requests / 60 min (whichever binds first)",
        reliability_score=0.95, discovery_capable=True, requires_env=["CEIDG_API_TOKEN"],
        notes="Covers sole proprietorships only — not sp. z o.o./S.A. (see 'krs'). Supports search by PKD code, "
              "city/voivodeship, registration-date range and status, plus a /zmiana endpoint listing entity IDs "
              "changed in a date range — the basis for both 'new business' and 'changed business' discovery.",
    ),
    "krs": SourceDef(
        source_id="krs", source_name="KRS (Krajowy Rejestr Sądowy) — Ministry of Justice open API",
        source_type="official_registry", base_url="https://api-krs.ms.gov.pl/api/krs",
        access_method="rest_keyless",
        legal_status="Public register of companies, published by the Polish Ministry of Justice under the KRS Act. "
                     "Free, keyless, no registration required.",
        update_frequency="daily", rate_limit="~2 requests / second (unofficial, be polite)",
        reliability_score=0.97, discovery_capable=False, requires_env=[],
        notes="Lookup is by KRS number ONLY — there is no verified search-by-name/NIP/PKD endpoint, so this "
              "connector enriches an entity you already have a KRS number for (from CEIDG's 'spolki' field, "
              "a company's own website, or a supplied list); it is not a discovery source by itself. "
              "Board-member personal names are masked by law since the 2023 RODO amendment.",
    ),
    "gus_regon": SourceDef(
        source_id="gus_regon", source_name="GUS REGON — Baza Internetowa REGON (BIR1.1)",
        source_type="official_registry", base_url="https://wyszukiwarkaregon.stat.gov.pl",
        access_method="soap_session",
        legal_status="Public statistical register, Polish Central Statistical Office (GUS). Requires a free "
                     "registered API key and a stateful SOAP 1.2 session (login → search → logout).",
        update_frequency="daily", rate_limit="not publicly documented",
        reliability_score=0.0, discovery_capable=False, requires_env=["GUS_REGON_API_KEY"],
        notes="NOT YET CONNECTED. Lookup-by-identifier only (REGON/NIP/KRS), like KRS — not a discovery source. "
              "Deferred: SOAP/WSDL integration is materially more work than the two REST connectors above for "
              "overlapping enrichment value (KRS already covers companies; CEIDG already covers sole traders). "
              "Worth adding if cross-checking REGON's employee-count bracket becomes valuable.",
    ),
}


def list_sources() -> list[dict]:
    return [
        {"source_id": s.source_id, "source_name": s.source_name, "source_type": s.source_type,
         "access_method": s.access_method, "legal_status": s.legal_status, "update_frequency": s.update_frequency,
         "rate_limit": s.rate_limit, "reliability_score": s.reliability_score, "discovery_capable": s.discovery_capable,
         "configured": s.configured(), "requires_env": s.requires_env, "notes": s.notes}
        for s in SOURCES.values()
    ]


def get_source(source_id: str) -> SourceDef:
    if source_id not in SOURCES:
        raise KeyError(f"Unknown source '{source_id}'")
    return SOURCES[source_id]
