"""Change detection (master prompt §25-26): diff a freshly-fetched canonical snapshot against the
previous raw record for the same external id. A detected change becomes a BusinessEvent, and
certain event types are also written into the existing Signal engine so qualification picks them
up automatically — reusing the evidence/FACT-INFERENCE machinery instead of duplicating it."""
from __future__ import annotations

from datetime import date as date_
from typing import Optional

from sqlalchemy.orm import Session

from database.models import BusinessEvent, Company, RawRecord
from engines.signal_engine import add_signal
from poland import raw_store

# event_type -> (signal_type, confidence) for events worth feeding into qualification.
# Everything else is still recorded as a BusinessEvent (full audit trail) but doesn't spawn a Signal.
_SIGNAL_MAP = {
    "status_changed_to_active": ("new_location", 0.5),   # reactivation/resumption is a mild growth signal
    "new_pkd_added": ("expansion", 0.55),
    "deregistered": None,
    "new_business": None,          # the business's EXISTENCE isn't a buying signal by itself
}


def _diff(old: dict, new: dict) -> list[tuple[str, str, Optional[str], Optional[str]]]:
    """Returns [(event_type, description, old_value, new_value), ...] for a canonical-field diff."""
    events = []
    if old.get("registry_status") != new.get("registry_status") and new.get("registry_status"):
        active = new["registry_status"] in ("AKTYWNY",)
        events.append((("status_changed_to_active" if active else "status_changed"),
                       f"Registry status changed from {old.get('registry_status')!r} to {new['registry_status']!r}",
                       old.get("registry_status"), new.get("registry_status")))
    old_pkd = {p["code"] for p in (old.get("pkd_codes") or [])}
    new_pkd = {p["code"] for p in (new.get("pkd_codes") or [])}
    added = new_pkd - old_pkd
    if added and old_pkd:   # only meaningful once there was a prior state to compare against
        events.append(("new_pkd_added", f"New PKD code(s) registered: {', '.join(sorted(added))}", None, ", ".join(sorted(added))))
    if old.get("city") and new.get("city") and old["city"] != new["city"]:
        events.append(("address_changed", f"Registered city changed from {old['city']} to {new['city']}", old["city"], new["city"]))
    return events


def record_and_diff(db: Session, company: Company, source_id: str, canonical: dict, *, event_date: Optional[date_] = None,
                    actor: str = "system") -> list[BusinessEvent]:
    """Call AFTER raw_store.write_raw() + entity_resolution — compares this fetch to the one before it
    (if any) and writes BusinessEvent rows, promoting selected event types into Signals."""
    hist = raw_store.history(db, source_id=source_id, external_id=canonical.get("_external_id", ""))
    created: list[BusinessEvent] = []
    if len(hist) < 2:
        if len(hist) == 1:
            created.append(_write_event(db, company, "new_business", source_id,
                                        f"First seen in {source_id.upper()} registry", None, canonical.get("registry_status"), event_date))
        return created
    from poland.canonical import from_ceidg, from_krs
    mapper = {"ceidg": from_ceidg, "krs": from_krs}[source_id]
    old_canonical = mapper(hist[-2].raw_payload.get("firma", hist[-2].raw_payload) if source_id == "ceidg" else hist[-2].raw_payload)
    for event_type, desc, old_val, new_val in _diff(old_canonical, canonical):
        created.append(_write_event(db, company, event_type, source_id, desc, old_val, new_val, event_date))
    return created


def _write_event(db: Session, company: Company, event_type: str, source_id: str, description: str,
                 old_value: Optional[str], new_value: Optional[str], event_date: Optional[date_]) -> BusinessEvent:
    ev = BusinessEvent(company_id=company.id, event_type=event_type, event_date=event_date or date_.today(),
                       source_id=source_id, description=description, old_value=old_value, new_value=new_value)
    db.add(ev)
    db.flush()
    mapping = _SIGNAL_MAP.get(event_type)
    if mapping:
        signal_type, confidence = mapping
        sig, _ = add_signal(db, company.id, signal_type, description, f"{source_id.upper()} registry (official)",
                            confidence=confidence, kind="FACT", origin="poland_registry", verified=True,
                            is_demo=company.is_demo, actor="system")
        ev.signal_id = sig.id
    db.flush()
    return ev
