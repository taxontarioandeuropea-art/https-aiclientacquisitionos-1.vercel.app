from __future__ import annotations

from core.errors import AppError


class SourceNotConfigured(AppError):
    """Raised when a connector needs credentials that aren't present. Never silently falls back
    to fabricated data — the caller must configure the source or choose a different one."""
    def __init__(self, source_id: str, env_vars: list[str]):
        super().__init__(f"The '{source_id}' source is not configured", operation=f"use source {source_id}",
                         cause=f"Missing environment variable(s): {', '.join(env_vars)}.",
                         suggestion="Set them in .env and restart the application.", status_code=424)


class SourceRequestFailed(AppError):
    def __init__(self, source_id: str, detail: str, status_code: int = 502):
        super().__init__(f"The '{source_id}' source could not be reached", operation=f"query {source_id}",
                         cause=detail, suggestion="Try again shortly; if it persists the source may be down.",
                         status_code=status_code)
