"""Immutable raw layer (master prompt §6). write_raw() is the ONLY way raw payloads enter the
database, and it never updates a row — a re-fetch of the same content is deduplicated by hash,
a re-fetch of changed content is a new row. Nothing downstream may write to raw_records directly."""
from __future__ import annotations

import hashlib
import json

from sqlalchemy.orm import Session

from database.models import RawRecord


def _hash(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode("utf-8")).hexdigest()


def write_raw(db: Session, *, source_id: str, external_id: str | None, raw_payload: dict,
              source_url: str | None = None, parser_version: str = "1") -> tuple[RawRecord, bool]:
    """Append one raw record. Returns (record, created) — created=False means the content is
    unchanged since the LAST observation of this source+external_id (a no-op re-poll, not an
    error). Compares only against the most recent record, never an older one: a value that
    reverts to a prior state (A -> B -> A) is a real, newly-observed change and must still get
    its own row, or the change-detection timeline would silently lose that transition."""
    h = _hash(raw_payload)
    latest = (db.query(RawRecord).filter(RawRecord.source_id == source_id, RawRecord.external_id == external_id)
              .order_by(RawRecord.id.desc()).first())
    if latest and latest.record_hash == h:
        return latest, False
    rec = RawRecord(source_id=source_id, external_id=external_id, source_url=source_url, raw_payload=raw_payload,
                    parser_version=parser_version, record_hash=h)
    db.add(rec)
    db.flush()
    return rec, True


def latest_raw(db: Session, *, source_id: str, external_id: str) -> RawRecord | None:
    """Most recent raw record for this source+external_id — used by events.py to diff against."""
    return (db.query(RawRecord).filter(RawRecord.source_id == source_id, RawRecord.external_id == external_id)
            .order_by(RawRecord.id.desc()).first())


def history(db: Session, *, source_id: str, external_id: str) -> list[RawRecord]:
    return (db.query(RawRecord).filter(RawRecord.source_id == source_id, RawRecord.external_id == external_id)
            .order_by(RawRecord.id.asc()).all())
