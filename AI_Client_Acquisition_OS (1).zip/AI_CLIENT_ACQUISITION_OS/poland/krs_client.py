"""Real client for the Polish Ministry of Justice's open KRS API (api-krs.ms.gov.pl).

Free, public, keyless. Lookup is by KRS number ONLY — there is no verified search-by-criteria
endpoint, so this connector enriches a known entity rather than discovering new ones. Board-member
personal names are masked by law since the 2023 RODO amendment (returned as e.g. "L******").
"""
from __future__ import annotations

import re
import time
from typing import Optional

import httpx

from poland.errors import SourceRequestFailed

BASE_URL = "https://api-krs.ms.gov.pl/api/krs"


def normalize_krs(value: str) -> str:
    digits = re.sub(r"\D", "", value or "")
    if not digits or len(digits) > 10:
        raise ValueError(f"'{value}' is not a valid KRS number")
    return digits.zfill(10)


class KrsClient:
    def __init__(self, *, base_url: str = BASE_URL, client: Optional[httpx.Client] = None,
                 min_interval: float = 0.55, timeout: float = 20.0):
        self.base_url = base_url
        self._client = client
        self._own_client = client is None
        self.min_interval = min_interval     # paced to the documented ~2 req/s
        self.timeout = timeout
        self._last_call = 0.0

    def _pace(self) -> None:
        wait = self.min_interval - (time.monotonic() - self._last_call)
        if wait > 0:
            time.sleep(wait)
        self._last_call = time.monotonic()

    def _get(self, path: str, params: dict) -> Optional[dict]:
        client = self._client or httpx.Client(timeout=self.timeout)
        self._pace()
        try:
            r = client.get(f"{self.base_url}{path}", params=params)
        except httpx.HTTPError as exc:
            raise SourceRequestFailed("krs", str(exc)) from exc
        finally:
            if self._own_client:
                client.close()
        if r.status_code == 404:
            return None
        if r.status_code == 429:
            raise SourceRequestFailed("krs", "Rate limit exceeded (429).", 429)
        if r.status_code >= 400:
            raise SourceRequestFailed("krs", f"HTTP {r.status_code}: {r.text[:300]}", r.status_code)
        return r.json()

    def odpis_aktualny(self, krs_number: str, *, rejestr: str = "P") -> Optional[dict]:
        """Current-state extract. rejestr: 'P' (entrepreneurs) or 'S' (associations/foundations)."""
        return self._get(f"/OdpisAktualny/{normalize_krs(krs_number)}", {"rejestr": rejestr, "format": "json"})

    def odpis_pelny(self, krs_number: str, *, rejestr: str = "P") -> Optional[dict]:
        """Full extract including historical entries (name/address/board changes since registration)."""
        return self._get(f"/OdpisPelny/{normalize_krs(krs_number)}", {"rejestr": rejestr, "format": "json"})
