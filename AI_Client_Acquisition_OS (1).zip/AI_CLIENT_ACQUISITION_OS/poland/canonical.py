"""Maps raw CEIDG/KRS payloads to the canonical fields on the existing Company model
(master prompt §7). Pure functions — no DB access — so they're trivially unit-testable."""
from __future__ import annotations

from datetime import date
from typing import Any, Optional

_MONTHS = {}  # placeholder kept for parser_version bump points


def _parse_date(s: Optional[str]) -> Optional[date]:
    if not s:
        return None
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        return None


def from_ceidg(firma: dict[str, Any]) -> dict[str, Any]:
    """CEIDG 'firma'/'firmy[]' entry -> canonical business fields. Only maps what CEIDG actually
    returns; never invents a field CEIDG left out."""
    owner = firma.get("wlasciciel") or {}
    addr = firma.get("adresDzialalnosci") or {}
    pkd_list = firma.get("pkd") or []
    pkd_main = firma.get("pkdGlowny") or {}
    name = firma.get("nazwa") or " ".join(x for x in [owner.get("imie"), owner.get("nazwisko")] if x)
    city_parts = [addr.get("ulica"), addr.get("budynek")]
    street = " ".join(p for p in city_parts if p) or None
    out = {
        "legal_name": name or None,
        "name": name or None,
        "legal_form": "JDG",
        "nip": owner.get("nip"),
        "regon": owner.get("regon"),
        "city": addr.get("miasto"),
        "state": addr.get("wojewodztwo"),
        "address": street,
        "pkd_codes": [{"code": p.get("kod"), "name": p.get("nazwa")} for p in pkd_list if p.get("kod")],
        "pkd_main": pkd_main.get("kod"),
        "industry": pkd_main.get("nazwa"),
        "registry_status": firma.get("status"),
        "registration_date": _parse_date(firma.get("dataRozpoczecia")),
        "deregistration_date": _parse_date(firma.get("dataWykreslenia")),
        "phone": firma.get("telefon") or None,
        "email": firma.get("email") or None,
        "website": firma.get("www") or None,
        "country": "Poland",
        "registry_source": "ceidg",
        "source": "CEIDG (Polish sole-trader registry)",
        "source_url": firma.get("link"),
    }
    # Each sole trader may also run a civil partnership (spolka) — exposed as a candidate KRS-free NIP/REGON pair;
    # not a KRS number, so left for the caller to decide whether to track separately.
    return {k: v for k, v in out.items() if v not in (None, "", [])}


_KRS_STATUS_MAP = {True: "AKTYWNY", False: "WYKRESLONY"}


def from_krs(odpis: dict[str, Any]) -> dict[str, Any]:
    """KRS OdpisAktualny/OdpisPelny response -> canonical business fields.
    The real payload nests everything under odpis.dane.dzial1/dzial2/... ; we read defensively
    since not every section is present for every legal form."""
    root = (odpis or {}).get("odpis") or odpis or {}
    dane = root.get("dane") or {}
    naglowek = root.get("naglowekP") or root.get("naglowek") or {}
    d1 = dane.get("dzial1") or {}
    dane_pod = d1.get("danePodmiotu") or {}
    siedziba = (d1.get("siedzibaIAdres") or {}).get("siedziba") or {}
    adres = (d1.get("siedzibaIAdres") or {}).get("adres") or {}
    pkd_block = (dane.get("dzial3") or {}).get("przedmiotDzialalnosci") or {}
    pkd_entries = (pkd_block.get("przedmiotPrzewazajacejDzialalnosci") or []) + (pkd_block.get("przedmiotPozostalejDzialalnosci") or [])

    legal_form = dane_pod.get("nazwaFormyPrawnej") or dane_pod.get("formaPrawna")
    name = dane_pod.get("nazwa")
    out = {
        "legal_name": name,
        "name": name,
        "legal_form": legal_form,
        "nip": dane_pod.get("identyfikatorNip") or dane_pod.get("nip"),
        "regon": dane_pod.get("identyfikatorRegon") or dane_pod.get("regon"),
        "krs_number": naglowek.get("numerKRS") or root.get("numerKRS"),
        "city": siedziba.get("miejscowosc"),
        "state": siedziba.get("wojewodztwo"),
        "address": " ".join(x for x in [adres.get("ulica"), adres.get("nrDomu"), adres.get("nrLokalu")] if x) or None,
        "pkd_codes": [{"code": (p.get("kodPrzedmiotuDzialalnosci") or ""), "name": p.get("nazwaPrzedmiotuDzialalnosci")}
                      for p in pkd_entries if p.get("kodPrzedmiotuDzialalnosci")],
        "registry_status": naglowek.get("stanRekordu"),
        "registry_source": "krs",
        "source": "KRS (Polish National Court Register)",
        "source_url": f"https://wyszukiwarka-krs.ms.gov.pl/",
    }
    return {k: v for k, v in out.items() if v not in (None, "", [])}
