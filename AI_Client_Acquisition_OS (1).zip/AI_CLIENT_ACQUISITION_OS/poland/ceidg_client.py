"""Real client for the CEIDG v3 REST API (dane.biznes.gov.pl) — Polish sole-trader (JDG) registry.

Verified against the official integrator documentation (Hurtownia Danych CEIDG i Biznes.gov.pl, API v3,
2024-10-21). Three operations are used:
  - search_firmy(): GET /firmy  — list companies matching criteria (name, NIP, PKD, city, voivodeship,
    registration-date range, status) — the discovery entry point.
  - get_firma():    GET /firma/{id} — full detail for one entry.
  - changes():       GET /zmiana — IDs of entries that changed in a date range (max recommended span: 5 days)
    — the event-driven "what changed" entry point.

Requires a free JWT obtained by registering at https://dane.biznes.gov.pl/pl/dane-po-api, supplied via the
CEIDG_API_TOKEN environment variable. Without it, every method raises SourceNotConfigured — never a guess.
"""
from __future__ import annotations

import os
import time
from typing import Any, Optional

import httpx

from poland.errors import SourceNotConfigured, SourceRequestFailed

BASE_URL = "https://dane.biznes.gov.pl/api/ceidg/v3"
VALID_STATUSES = {"AKTYWNY", "WYKRESLONY", "ZAWIESZONY", "OCZEKUJE_NA_ROZPOCZECIE_DZIALANOSCI", "WYLACZNIE_W_FORMIE_SPOLKI"}


class CeidgClient:
    def __init__(self, token: Optional[str] = None, *, base_url: str = BASE_URL, client: Optional[httpx.Client] = None,
                 min_interval: float = 3.6, timeout: float = 20.0):
        self._token = token if token is not None else os.getenv("CEIDG_API_TOKEN")
        self.base_url = base_url
        self._client = client
        self._own_client = client is None
        self.min_interval = min_interval        # paced to the documented 50-req/3-min limit
        self.timeout = timeout
        self._last_call = 0.0

    def _require_token(self) -> str:
        if not self._token:
            raise SourceNotConfigured("ceidg", ["CEIDG_API_TOKEN"])
        return self._token

    def _pace(self) -> None:
        wait = self.min_interval - (time.monotonic() - self._last_call)
        if wait > 0:
            time.sleep(wait)
        self._last_call = time.monotonic()

    def _get(self, path: str, params: dict[str, Any]) -> Optional[dict]:
        token = self._require_token()
        client = self._client or httpx.Client(timeout=self.timeout)
        self._pace()
        try:
            r = client.get(f"{self.base_url}{path}", params=params, headers={"Authorization": f"Bearer {token}"})
        except httpx.HTTPError as exc:
            raise SourceRequestFailed("ceidg", str(exc)) from exc
        finally:
            if self._own_client:
                client.close()
        if r.status_code == 204:
            return None
        if r.status_code == 401:
            raise SourceRequestFailed("ceidg", "Authorization rejected (401) — the CEIDG_API_TOKEN is invalid or expired.", 401)
        if r.status_code == 429:
            raise SourceRequestFailed("ceidg", "Rate limit exceeded (429): 50 requests/3 min or 1000/60 min.", 429)
        if r.status_code >= 400:
            raise SourceRequestFailed("ceidg", f"HTTP {r.status_code}: {r.text[:300]}", r.status_code)
        return r.json()

    def search_firmy(self, *, nazwa: Optional[list[str]] = None, nip: Optional[list[str]] = None,
                     pkd: Optional[list[str]] = None, miasto: Optional[list[str]] = None,
                     wojewodztwo: Optional[list[str]] = None, status: Optional[list[str]] = None,
                     dataod: Optional[str] = None, datado: Optional[str] = None,
                     page: int = 0, limit: int = 50) -> dict:
        """List entries matching criteria. dataod/datado filter on registration (dataRozpoczecia) date,
        format YYYY-MM-DD. status values: AKTYWNY, WYKRESLONY, ZAWIESZONY, OCZEKUJE_NA_ROZPOCZECIE_DZIALANOSCI,
        WYLACZNIE_W_FORMIE_SPOLKI. Returns {} (count 0) rather than raising when nothing matches."""
        if status:
            bad = set(status) - VALID_STATUSES
            if bad:
                raise ValueError(f"Invalid CEIDG status value(s): {bad}. Valid: {sorted(VALID_STATUSES)}")
        params: dict[str, Any] = {"page": page, "limit": min(limit, 50)}
        for key, val in (("nazwa", nazwa), ("nip", nip), ("pkd", pkd), ("miasto", miasto),
                         ("wojewodztwo", wojewodztwo), ("status", status)):
            if val:
                params[key] = val
        if dataod:
            params["dataod"] = dataod
        if datado:
            params["datado"] = datado
        data = self._get("/firmy", params)
        return data or {"firmy": [], "count": 0}

    def get_firma(self, entry_id: str) -> Optional[dict]:
        """Full detail for one CEIDG entry by its id (UUID)."""
        data = self._get(f"/firma/{entry_id}", {})
        if not data or not data.get("firma"):
            return None
        rows = data["firma"]
        return rows[0] if isinstance(rows, list) else rows

    def changes(self, *, dataod: str, datado: Optional[str] = None, page: int = 0, limit: int = 500) -> dict:
        """IDs of entries changed in [dataod, datado]. The API recommends spans of 5 days or less."""
        params: dict[str, Any] = {"dataod": dataod, "page": page, "limit": limit}
        if datado:
            params["datado"] = datado
        data = self._get("/zmiana", params)
        return data or {"identyfikatoryWpisow": [], "count": 0}
