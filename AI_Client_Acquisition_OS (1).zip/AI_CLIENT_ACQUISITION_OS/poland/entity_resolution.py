"""Entity resolution for Polish businesses (master prompt §8). Deterministic matching on official
identifiers always wins; falls back to the existing fuzzy name/domain matching in company_service
only when no identifier is present. Every match carries its reasons — nothing merges silently."""
from __future__ import annotations

from typing import Optional

from sqlalchemy.orm import Session

from database.models import Company
from services import company_service


def find_existing(db: Session, canonical: dict) -> Optional[Company]:
    """Deterministic match only: NIP > REGON > KRS number. Returns None if no identifier matches
    (the caller then falls back to company_service.find_matches_for for a flagged, non-silent
    fuzzy match, exactly like every other ingestion path in this app)."""
    for field, value in (("nip", canonical.get("nip")), ("regon", canonical.get("regon")),
                         ("krs_number", canonical.get("krs_number"))):
        if value:
            hit = db.query(Company).filter(getattr(Company, field) == value, Company.archived.is_(False)).first()
            if hit:
                return hit
    return None


def resolve_or_create(db: Session, canonical: dict, *, actor: str = "system") -> tuple[Company, bool, list[str]]:
    """Returns (company, created, match_reasons). Deterministic identifier match -> reuse & fill gaps.
    No identifier match -> check fuzzy duplicates (flagged, never auto-merged) -> create."""
    clean = company_service.clean_company({k: v for k, v in canonical.items() if k in company_service.COMPANY_FIELDS})
    existing = find_existing(db, canonical)
    if existing:
        reasons = [f"Matched by {f}" for f in ("nip", "regon", "krs_number") if canonical.get(f) and getattr(existing, f) == canonical.get(f)]
        _fill_identifiers(existing, canonical)
        for k, v in clean.items():
            if v not in (None, "", []) and getattr(existing, k) in (None, "", []):
                setattr(existing, k, v)
        db.flush()
        return existing, False, reasons
    company = company_service.create_company(db, clean, source=canonical.get("source", "Poland registry"), actor=actor, log=False)
    _fill_identifiers(company, canonical)
    db.flush()
    return company, True, ["No existing identifier match — created new company"]


def _fill_identifiers(company: Company, canonical: dict) -> None:
    for f in ("nip", "regon", "krs_number", "legal_form", "pkd_codes", "pkd_main", "registry_status",
             "registry_source", "registration_date", "deregistration_date"):
        v = canonical.get(f)
        if v not in (None, "", []):
            setattr(company, f, v)
