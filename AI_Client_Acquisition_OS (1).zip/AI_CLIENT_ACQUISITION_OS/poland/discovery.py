"""Orchestrates the full ELT flow for one connector call:
  EXTRACT (connector) -> LOAD (raw_store, immutable) -> TRANSFORM (canonical) ->
  entity resolution -> change detection (events/signals) -> SourceRun bookkeeping.

PolandRegistrySource implements adapters.base.BaseLeadSource so it plugs directly into the
existing lead_hunter/lead_service ingestion pipeline — qualification, offer-matching, dedup
flagging, audit logging and the CRM are reused as-is, exactly as adapters/future/README.md
anticipated ("public registries (KRS/CEIDG in Poland...)").
"""
from __future__ import annotations

from datetime import date as date_
from typing import Any, Optional

from sqlalchemy.orm import Session

from adapters.base import BaseLeadSource, LeadRecord, SourceError
from core.utils import utcnow
from database.models import Company, SourceRun
from poland import raw_store
from poland.canonical import from_ceidg, from_krs
from poland.ceidg_client import CeidgClient
from poland.entity_resolution import resolve_or_create
from poland.errors import SourceNotConfigured, SourceRequestFailed
from poland.events import record_and_diff
from poland.krs_client import KrsClient


def start_run(db: Session, source_id: str, operation: str, params: dict) -> SourceRun:
    run = SourceRun(source_id=source_id, operation=operation, params=params, status="RUNNING")
    db.add(run)
    db.flush()
    return run


def finish_run(db: Session, run: SourceRun, *, status: str, errors: Optional[list[str]] = None) -> None:
    from core.utils import utcnow
    run.status = status
    run.errors = errors or []
    run.finished_at = utcnow()
    db.flush()


def _ingest_one(db: Session, source_id: str, external_id: str, raw_payload: dict, source_url: Optional[str],
                canonical: dict, run: SourceRun) -> tuple[Company, bool]:
    raw_store.write_raw(db, source_id=source_id, external_id=external_id, raw_payload=raw_payload, source_url=source_url)
    canonical = dict(canonical)
    canonical["_external_id"] = external_id
    company, created, _reasons = resolve_or_create(db, canonical)
    company.last_registry_sync_at = utcnow()
    events = record_and_diff(db, company, source_id, canonical, actor="system")
    run.fetched += 1
    run.created_businesses += int(created)
    run.updated_businesses += int(not created)
    run.events_created += len(events)
    return company, created


def ceidg_search(db: Session, *, client: Optional[CeidgClient] = None, campaign_id: Optional[int] = None,
                 fetch_detail: bool = True, max_results: int = 100, **criteria: Any) -> dict:
    """Discovery: search CEIDG by criteria (pkd, miasto, wojewodztwo, dataod/datado, status, nazwa, nip),
    fetch full detail for each hit, resolve/create companies, detect changes, optionally create leads."""
    c = client or CeidgClient()
    run = start_run(db, "ceidg", "search", criteria)
    errors: list[str] = []
    companies: list[Company] = []
    try:
        page, fetched = 0, 0
        while fetched < max_results:
            res = c.search_firmy(page=page, limit=min(50, max_results - fetched), **criteria)
            rows = res.get("firmy", [])
            if not rows:
                break
            for row in rows:
                try:
                    detail = c.get_firma(row["id"]) if fetch_detail else row
                    if not detail:
                        continue
                    canonical = from_ceidg(detail)
                    company, _ = _ingest_one(db, "ceidg", row["id"], detail, detail.get("link"), canonical, run)
                    companies.append(company)
                except (SourceRequestFailed, ValueError) as exc:
                    errors.append(f"{row.get('id', '?')}: {exc}")
                fetched += 1
                if fetched >= max_results:
                    break
            if len(rows) < criteria.get("limit", 50):
                break
            page += 1
        status = "SUCCESS" if not errors else ("PARTIAL_SUCCESS" if companies else "FAILED")
    except SourceNotConfigured:
        finish_run(db, run, status="SKIPPED", errors=["CEIDG_API_TOKEN not configured"])
        raise
    except SourceRequestFailed as exc:
        finish_run(db, run, status="FAILED" if not companies else "PARTIAL_SUCCESS", errors=[str(exc)])
        raise
    finish_run(db, run, status=status, errors=errors)
    lead_ids = _maybe_create_leads(db, companies, campaign_id)
    return {"run_id": run.id, "status": status, "fetched": run.fetched, "created_businesses": run.created_businesses,
            "updated_businesses": run.updated_businesses, "events_created": run.events_created, "errors": errors,
            "company_ids": [c.id for c in companies], "lead_ids": lead_ids}


def ceidg_changes(db: Session, *, dataod: str, datado: Optional[str] = None, client: Optional[CeidgClient] = None,
                  campaign_id: Optional[int] = None, max_results: int = 200) -> dict:
    """Event-driven discovery: fetch IDs changed in [dataod, datado], resolve each, diff against its
    last known snapshot. This is what turns 'changed businesses' (§3B) into real signals, not just a re-import."""
    c = client or CeidgClient()
    run = start_run(db, "ceidg", "changes", {"dataod": dataod, "datado": datado})
    errors: list[str] = []
    companies: list[Company] = []
    try:
        res = c.changes(dataod=dataod, datado=datado, limit=min(500, max_results))
        ids = res.get("identyfikatoryWpisow", [])[:max_results]
        for entry_id in ids:
            try:
                detail = c.get_firma(entry_id)
                if not detail:
                    continue
                canonical = from_ceidg(detail)
                company, _ = _ingest_one(db, "ceidg", entry_id, detail, detail.get("link"), canonical, run)
                companies.append(company)
            except (SourceRequestFailed, ValueError) as exc:
                errors.append(f"{entry_id}: {exc}")
        status = "SUCCESS" if not errors else ("PARTIAL_SUCCESS" if companies else "FAILED")
    except SourceNotConfigured:
        finish_run(db, run, status="SKIPPED", errors=["CEIDG_API_TOKEN not configured"])
        raise
    finish_run(db, run, status=status, errors=errors)
    lead_ids = _maybe_create_leads(db, companies, campaign_id)
    return {"run_id": run.id, "status": status, "fetched": run.fetched, "created_businesses": run.created_businesses,
            "updated_businesses": run.updated_businesses, "events_created": run.events_created, "errors": errors,
            "company_ids": [c.id for c in companies], "lead_ids": lead_ids}


def krs_enrich(db: Session, krs_numbers: list[str], *, client: Optional[KrsClient] = None,
              campaign_id: Optional[int] = None, full: bool = False) -> dict:
    """Enrichment: fetch a known KRS number (e.g. one found via a company's own website, or
    cross-referenced from a CEIDG civil-partnership entry) and merge it into the matching company."""
    c = client or KrsClient()
    run = start_run(db, "krs", "enrich", {"krs_numbers": krs_numbers, "full": full})
    errors: list[str] = []
    companies: list[Company] = []
    for krs in krs_numbers:
        try:
            odpis = c.odpis_pelny(krs) if full else c.odpis_aktualny(krs)
            if not odpis:
                errors.append(f"{krs}: not found in KRS")
                continue
            canonical = from_krs(odpis)
            canonical.setdefault("krs_number", krs)
            company, _ = _ingest_one(db, "krs", krs, odpis, "https://wyszukiwarka-krs.ms.gov.pl/", canonical, run)
            companies.append(company)
        except (SourceRequestFailed, ValueError) as exc:
            errors.append(f"{krs}: {exc}")
    status = "SUCCESS" if not errors else ("PARTIAL_SUCCESS" if companies else "FAILED")
    finish_run(db, run, status=status, errors=errors)
    lead_ids = _maybe_create_leads(db, companies, campaign_id)
    return {"run_id": run.id, "status": status, "fetched": run.fetched, "created_businesses": run.created_businesses,
            "updated_businesses": run.updated_businesses, "events_created": run.events_created, "errors": errors,
            "company_ids": [c.id for c in companies], "lead_ids": lead_ids}


def _maybe_create_leads(db: Session, companies: list[Company], campaign_id: Optional[int]) -> list[int]:
    if not campaign_id or not companies:
        return []
    from engines.offer_engine import generate_offer
    from engines.qualification_engine import qualify_lead
    from services import lead_service
    lead_ids = []
    for company in companies:
        lead, _ = lead_service.create_lead(db, company_id=company.id, campaign_id=campaign_id, actor="system", log=False)
        qualify_lead(db, lead, actor="ai")
        generate_offer(db, lead, actor="ai")
        lead_ids.append(lead.id)
    return lead_ids


class PolandRegistrySource(BaseLeadSource):
    """BaseLeadSource wrapper so Poland registry discovery also works through the generic
    engines/lead_hunter.py entry point and the import/export 'sources' listing."""
    name = "poland_registry"
    description = "Discover and enrich Polish businesses via the official CEIDG and KRS registries."

    def fetch(self, *, db: Session, mode: str = "ceidg_search", **params: Any) -> list[LeadRecord]:
        try:
            if mode == "ceidg_search":
                res = ceidg_search(db, **params)
            elif mode == "ceidg_changes":
                res = ceidg_changes(db, **params)
            elif mode == "krs_enrich":
                res = krs_enrich(db, **params)
            else:
                raise ValueError(f"Unknown mode '{mode}'")
        except (SourceNotConfigured, SourceRequestFailed) as exc:
            raise SourceError(str(exc), cause=getattr(exc, "cause", ""), suggestion=getattr(exc, "suggestion", "")) from exc
        return []  # ingestion already happened inside ceidg_search/ceidg_changes/krs_enrich
