"""Central configuration.

Everything comes from environment variables / a local .env file.
Secrets (API keys) are read here or by the AI providers from the environment
and are never persisted in the database or exposed to the browser.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _num(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, "") or default)
    except ValueError:
        return default


@dataclass
class Config:
    app_name: str
    internal_name: str
    base_dir: Path
    database_url: str
    host: str
    port: int
    debug: bool
    max_upload_mb: int
    allow_private_urls: bool
    load_demo_on_first_run: bool
    http_timeout: float
    log_dir: Path
    import_dir: Path
    export_dir: Path
    user_agent: str = "AIClientAcquisitionOS/1.0 (+local research tool; respects robots.txt)"


def load_config() -> Config:
    db_url = (os.getenv("DATABASE_URL") or "").strip()
    if not db_url:
        db_url = f"sqlite:///{(BASE_DIR / 'database' / 'sales.db').as_posix()}"
    cfg = Config(
        app_name=os.getenv("APP_NAME", "AI Client Acquisition OS"),
        internal_name="AI Sales Machine",
        base_dir=BASE_DIR,
        database_url=db_url,
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(_num("PORT", 8000)),
        debug=_bool("DEBUG", False),
        max_upload_mb=int(_num("MAX_UPLOAD_MB", 10)),
        allow_private_urls=_bool("ALLOW_PRIVATE_URLS", False),
        load_demo_on_first_run=_bool("LOAD_DEMO_ON_FIRST_RUN", True),
        http_timeout=_num("HTTP_TIMEOUT_SECONDS", 12),
        log_dir=BASE_DIR / "logs",
        import_dir=BASE_DIR / "imports",
        export_dir=BASE_DIR / "exports",
    )
    for d in (cfg.log_dir, cfg.import_dir, cfg.export_dir):
        d.mkdir(parents=True, exist_ok=True)
    return cfg


config = load_config()
