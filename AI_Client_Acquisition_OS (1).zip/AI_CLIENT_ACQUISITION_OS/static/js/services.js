(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, post, patch, del, guard, ok, money, int, empty, errBox, opts, dialog, confirmDialog, formObj } = App;
  const root = $('#root'); let list = [], catalog = [];
  async function load() {
    try { [list, catalog] = await Promise.all([get('/api/services'), get('/api/signals/catalog')]); } catch (e) { mount(root, errBox(e)); return; }
    mount($('#page-actions'), html`<button class="btn btn-primary" id="new">Add service</button>`); $('#new').addEventListener('click', () => edit(null));
    const label = Object.fromEntries(catalog.map((c) => [c.type, c.label]));
    mount(root, list.length ? html`<section class="panel"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Service</th><th>Pricing</th><th class="num">Target MRR</th><th>Company size</th><th>Recommended when it sees</th><th class="num">Leads</th><th></th></tr></thead><tbody>
      ${list.map((s) => html`<tr><td><strong>${s.name}</strong>${s.is_active ? '' : html` <span class="chip">Inactive</span>`}${s.is_demo ? html` <span class="chip demo">Demo</span>` : ''}<span class="sub">${s.description || ''}</span></td>
        <td>${s.pricing_model === 'monthly' ? 'Monthly' : 'Project'}<span class="sub">from ${money(s.minimum_price)}</span></td><td class="num fig">${s.target_mrr ? money(s.target_mrr) : html`<span class="faint">Project</span>`}</td>
        <td>${s.target_employees_min || s.target_employees_max ? `${s.target_employees_min ?? 'any'} to ${s.target_employees_max ?? 'any'}` : 'Any'}</td>
        <td>${(s.required_signals || []).length ? s.required_signals.map((t) => html`<span class="chip" style="margin:0 4px 4px 0">${label[t] || t}</span>`) : html`<span class="attn">No signals: it will never be recommended</span>`}</td><td class="num">${s.lead_count}</td>
        <td class="nowrap right"><button class="btn btn-sm" data-edit="${s.id}">Edit</button> <button class="btn btn-sm btn-quiet" data-del="${s.id}">Delete</button></td></tr>`)}</tbody></table></div></section>
      <p class="muted small">A service is recommended only when a lead has evidence matching one of its signals. Unmatched leads get no recommendation rather than a generic one.</p>`
      : html`<div class="panel">${empty('No services yet', 'Add the services you sell. Each lists the signals that show it is needed.')}</div>`);
    $$('[data-edit]', root).forEach((b) => b.addEventListener('click', () => edit(list.find((s) => s.id === Number(b.dataset.edit)))));
    $$('[data-del]', root).forEach((b) => b.addEventListener('click', async () => { const s = list.find((x) => x.id === Number(b.dataset.del)); if (await confirmDialog({ title: `Delete ${s.name}?`, message: `${s.lead_count} lead(s) currently recommend it and will lose that recommendation until re-qualified.`, confirm: 'Delete service', danger: true })) guard(async () => { await del(`/api/services/${s.id}`); ok('Service deleted'); load(); }); }));
  }
  async function edit(s) {
    const sel = new Set(s ? s.required_signals : []); const lines = (a) => (a || []).join(', ');
    const r = await dialog({ title: s ? `Edit ${s.name}` : 'Add a service', wide: true, submit: s ? 'Save service' : 'Add service', onSubmit: (fd) => ({ f: formObj(fd), signals: fd.getAll('sig') }), body: html`<div class="stack"><div class="form-grid">
      <label class="f wide"><span>Name</span><input name="name" required maxlength="160" value="${s ? s.name : ''}"></label><label class="f wide"><span>What it is</span><textarea name="description">${s ? s.description || '' : ''}</textarea></label>
      <label class="f"><span>Pricing model</span><select name="pricing_model">${opts([['monthly', 'Monthly retainer'], ['project', 'One-off project']], s ? s.pricing_model : 'monthly')}</select></label><label class="f"><span>Minimum price (USD)</span><input name="minimum_price" type="number" min="0" value="${s ? s.minimum_price ?? '' : ''}"></label>
      <label class="f"><span>Target monthly revenue (USD)</span><input name="target_mrr" type="number" min="0" value="${s ? s.target_mrr ?? '' : ''}"><div class="hint">For projects, leave empty or use the retainer that follows.</div></label>
      <label class="f"><span>Minimum employees</span><input name="target_employees_min" type="number" min="0" value="${s ? s.target_employees_min ?? '' : ''}"></label><label class="f"><span>Maximum employees</span><input name="target_employees_max" type="number" min="0" value="${s ? s.target_employees_max ?? '' : ''}"></label>
      <label class="f"><span>Target industries (comma separated)</span><input name="target_industries" value="${lines(s && s.target_industries)}"></label><label class="f"><span>Target technology</span><input name="target_technology" value="${lines(s && s.target_technology)}"></label>
      <label class="f wide"><span>Deliverables (comma separated)</span><input name="deliverables" value="${lines(s && s.deliverables)}"></label><label class="f wide"><span>Typical problems it solves (comma separated)</span><input name="typical_problems" value="${lines(s && s.typical_problems)}"></label>
      <label class="f wide"><span>Preferred decision makers (comma separated)</span><input name="preferred_decision_makers" value="${lines(s && s.preferred_decision_makers)}"></label>
      <label class="f"><span>Follow-on service</span><select name="follow_on_service_id">${opts(list.filter((x) => !s || x.id !== s.id).map((x) => [x.id, x.name]), s ? s.follow_on_service_id : '', 'None')}</select><div class="hint">Offered after this one, for example cleanup then a retainer.</div></label>
      <label class="check" style="align-self:end"><input type="checkbox" name="is_active" value="1" ${!s || s.is_active ? raw('checked') : ''}><span>Active (can be recommended)</span></label></div>
      <fieldset style="border:1px solid var(--rule-soft);border-radius:var(--r-panel);padding:12px 14px"><legend class="muted small" style="padding:0 6px">Recommend it when the company shows evidence of</legend><div class="form-grid">${catalog.map((c) => html`<label class="check"><input type="checkbox" name="sig" value="${c.type}" ${sel.has(c.type) ? raw('checked') : ''}><span>${c.label}</span></label>`)}</div></fieldset></div>` });
    if (!r) return; const f = r.f; const num = ['minimum_price', 'target_mrr', 'target_employees_min', 'target_employees_max'];
    const body = { name: f.name, description: f.description || null, pricing_model: f.pricing_model, is_active: f.is_active === '1', required_signals: r.signals, follow_on_service_id: f.follow_on_service_id ? Number(f.follow_on_service_id) : null };
    num.forEach((k) => { body[k] = f[k] === '' ? null : Number(f[k]); }); ['target_industries', 'target_technology', 'deliverables', 'typical_problems', 'preferred_decision_makers'].forEach((k) => { body[k] = f[k]; });
    guard(async () => { s ? await patch(`/api/services/${s.id}`, body) : await post('/api/services', body); ok(s ? 'Service saved' : 'Service added'); load(); });
  }
  load();
})();
