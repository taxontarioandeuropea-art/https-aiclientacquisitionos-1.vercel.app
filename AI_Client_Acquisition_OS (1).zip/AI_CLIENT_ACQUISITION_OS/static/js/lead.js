/* Lead drawer: why this lead matters (five dimensions), evidence, recommended offer, message approval, activity. */
(function () {
  'use strict';
  const A = App;
  const { html, raw, $, $$, mount, get, post, patch, del, guard, ok, fail, money, fdate, ago, dueLabel, stageBadge, prio, kind, dims, DIMS,
    LEVEL_LABEL, STAGES, OFFPATH, STAGE_LABEL, dialog, confirmDialog, formObj, opts, errBox, loading, empty, demoChip } = A;

  let servicesCache = null, catalogCache = null;
  const services = async () => servicesCache || (servicesCache = await get('/api/services'));
  const catalog = async () => catalogCache || (catalogCache = await get('/api/signals/catalog'));
  const idx = (s) => STAGES.indexOf(s);

  function open(id, onChange) {
    const dr = A.openDrawer({ title: 'Loading…', body: loading() });
    let d = null, tab = 'overview';
    const changed = () => { if (onChange) onChange(d); };

    async function load() {
      try { d = await get(`/api/leads/${id}`); } catch (e) { mount(dr.body, errBox(e)); return; }
      draw();
    }
    const act = (fn, msg) => guard(async () => { const r = await fn(); if (msg) ok(msg); await load(); changed(); return r; });

    function draw() {
      dr.setTitle(d.company.name, html`${stageBadge(d.status)} ${d.campaign ? d.campaign.name : 'No campaign'}${demoChip(d.is_demo)}`);
      const tabs = [['overview', 'Overview'], ['evidence', `Evidence (${d.signals.length})`], ['messages', `Messages (${d.messages.length})`], ['activity', 'Activity']];
      mount(dr.body, html`
        <div class="row between" style="margin-bottom:12px">
          <div class="row">${prio(d.overall_priority)}${dims(d.dimensions)}<span class="fig" style="font-size:18px">${d.status === 'WON' ? money(d.actual_mrr) : money(d.potential_mrr)}</span><span class="muted small">${d.status === 'WON' ? 'monthly, won' : 'potential monthly'}</span></div>
          <a class="btn btn-sm" href="/companies/${d.company.id}">Open company profile</a>
        </div>
        <div class="tabs" role="tablist">${tabs.map(([k, l]) => html`<button role="tab" data-tab="${k}" aria-selected="${k === tab}">${l}</button>`)}</div>
        <div id="tab-body"></div>`);
      $$('[data-tab]', dr.body).forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; draw(); }));
      const body = $('#tab-body', dr.body);
      ({ overview: overview, evidence: evidence, messages: messages, activity: activity })[tab](body);
    }

    // ------------------------------------------------------------------ overview
    async function overview(el) {
      const q = d.qualification;
      const forward = d.suggested_stage && d.suggested_stage !== d.status && idx(d.suggested_stage) > idx(d.status) && !OFFPATH.includes(d.status) && d.status !== 'WON';
      const stageOptions = [...STAGES, ...OFFPATH].map((s) => [s, STAGE_LABEL[s]]);
      const svcList = await services();
      const off = d.offer && d.offer.service ? d.offer : null;
      mount(el, html`
        ${forward ? html`<div class="notice"><div class="row between"><span>The evidence supports moving this lead to <strong>${STAGE_LABEL[d.suggested_stage]}</strong>. This is a suggestion; nothing moves unless you do it.</span><button class="btn btn-sm btn-primary" data-move="${d.suggested_stage}">Move to ${STAGE_LABEL[d.suggested_stage]}</button></div></div>` : ''}
        <div class="panel"><div class="panel-body row between">
          <label class="f" style="min-width:200px"><span>Stage</span><select id="stage-sel">${opts(stageOptions, d.status)}</select></label>
          <div class="actions"><button class="btn" id="stage-go">Move stage</button><button class="btn" id="requal">Re-run qualification</button></div>
        </div></div>

        <div class="panel"><div class="panel-head"><h2>Why this priority</h2>${prio(d.overall_priority)}</div><div class="panel-body">
          ${q ? html`<p>${q.overall && q.overall.explanation}</p>
            <div class="dim-rows">${DIMS.map(([k, label]) => { const x = q.dimensions[k] || {}; const lv = x.level || 'UNKNOWN';
              return html`<div class="dim-row"><div><strong>${label}</strong></div><div class="lvl l-${lv.toLowerCase()}">${LEVEL_LABEL[lv]}</div>
                <ul class="reasons">${(x.reasons || []).map((r) => html`<li>${kind(r.kind)}${r.text}</li>`)}${(x.gaps || []).map((g) => html`<li class="faint">Missing: ${g}</li>`)}</ul></div>`; })}</div>
            ${(q.data_gaps || []).length ? html`<p class="muted small" style="margin-top:10px">Data gaps: ${q.data_gaps.join(', ')}.</p>` : ''}`
          : empty('Not qualified yet', 'Run qualification to score fit, need, buying signal, ability to pay and contactability from the evidence on file.')}
        </div></div>

        <div class="panel"><div class="panel-head"><h2>Recommended offer</h2>${off ? html`<span class="fig" style="font-size:18px">${money(off.potential_mrr)}<span class="muted small" style="font-family:var(--font-ui)"> potential monthly</span></span>` : ''}</div><div class="panel-body stack">
          ${off ? html`
            <div><strong>${off.service}</strong> <span class="muted">${off.pricing.display}</span></div>
            <div>${kind('INFERENCE')}${off.problem.text}.
              ${(off.problem.evidence || []).map((e) => html`<div class="evidence" style="margin-top:8px"><q>${e.evidence_text}</q><div class="meta">${e.label} from ${e.source}</div></div>`)}</div>
            <div>${kind('RECOMMENDATION')}${off.offer.text}</div>
            ${off.alternative ? html`<div class="muted">${kind('RECOMMENDATION')}${off.alternative.text}</div>` : ''}
            <ul class="reasons">${(off.reasons || []).map((r) => html`<li>${kind(r.kind)}${r.text}</li>`)}</ul>`
          : empty('No service recommended yet', 'A service is only recommended when there is evidence it addresses a need. Add or research evidence, then re-run qualification.')}
          <label class="f"><span>Use a different service</span><select id="svc-sel">${opts(svcList.map((s) => [s.id, `${s.name} (${s.pricing_model})`]), d.recommended_service_id, 'Choose a service')}</select></label>
        </div></div>

        <div class="panel"><div class="panel-head"><h2>Contact</h2><button class="btn btn-sm" id="add-contact">Add contact</button></div><div class="panel-body stack">
          ${d.person ? html`<div><strong>${d.person.full_name || 'Unnamed'}</strong> <span class="muted">${d.person.title || 'Title unknown'}</span><div>${d.person.email ? html`<a href="mailto:${d.person.email}">${d.person.email}</a>` : html`<span class="attn">No email on file. Find a verified address; do not guess.</span>`}</div></div>`
            : html`<div class="attn">No contact is attached to this lead. Identify a decision maker before outreach.</div>`}
          ${d.contacts.length ? html`<label class="f"><span>Contact for this lead</span><select id="person-sel">${opts(d.contacts.map((p) => [p.id, `${p.full_name || p.email}${p.title ? ' (' + p.title + ')' : ''}`]), d.person && d.person.id, 'None')}</select></label>` : ''}
        </div></div>

        <div class="panel"><div class="panel-head"><h2>Next action and notes</h2></div><div class="panel-body stack">
          <div class="form-grid"><label class="f wide"><span>Next action</span><input id="na-text" value="${d.next_action || ''}" maxlength="255"></label>
          <label class="f"><span>Due date</span><input id="na-date" type="date" value="${d.next_action_date || ''}"></label></div>
          <label class="f"><span>Notes</span><textarea id="notes" maxlength="4000">${d.notes || ''}</textarea></label>
          <div class="row between"><button class="btn btn-primary" id="save-na">Save changes</button><button class="btn btn-danger btn-sm" id="del-lead">Delete lead</button></div>
        </div></div>`);

      $$('[data-move]', el).forEach((b) => b.addEventListener('click', () => moveStage(b.dataset.move)));
      $('#stage-go', el).addEventListener('click', () => { const s = $('#stage-sel', el).value; if (s !== d.status) moveStage(s); });
      $('#requal', el).addEventListener('click', () => act(() => post(`/api/leads/${id}/qualify`), 'Qualification updated'));
      $('#svc-sel', el).addEventListener('change', (e) => e.target.value && act(() => patch(`/api/leads/${id}`, { recommended_service_id: Number(e.target.value) }), 'Service changed'));
      const ps = $('#person-sel', el); if (ps) ps.addEventListener('change', (e) => act(() => patch(`/api/leads/${id}`, { person_id: e.target.value ? Number(e.target.value) : null }), 'Contact updated'));
      $('#add-contact', el).addEventListener('click', addContact);
      $('#save-na', el).addEventListener('click', () => act(() => patch(`/api/leads/${id}`, { next_action: $('#na-text', el).value, next_action_date: $('#na-date', el).value || null, notes: $('#notes', el).value }), 'Saved'));
      $('#del-lead', el).addEventListener('click', async () => { if (await confirmDialog({ title: 'Delete this lead?', message: `The lead for ${d.company.name} and its messages, tasks and history will be deleted. The company and its contacts stay.`, confirm: 'Delete lead', danger: true })) guard(async () => { await del(`/api/leads/${id}`); ok('Lead deleted'); dr.close(); changed(); }); });
    }

    async function moveStage(to) {
      const payload = { stage: to };
      if (to === 'WON') {
        const r = await dialog({ title: 'Mark as won', submit: 'Mark as won', onSubmit: (fd) => formObj(fd), body: html`<div class="stack"><label class="f"><span>Actual monthly recurring revenue (USD)</span><input name="actual_mrr" type="number" min="0" step="50" required value="${d.potential_mrr || ''}"><div class="hint">The agreed monthly fee. Only you can close an opportunity.</div></label><label class="f"><span>Note</span><input name="note" maxlength="255"></label></div>` });
        if (!r) return; payload.actual_mrr = Number(r.actual_mrr); payload.note = r.note || null;
      } else if (to === 'LOST') {
        const r = await dialog({ title: 'Mark as lost', submit: 'Mark as lost', danger: true, onSubmit: (fd) => formObj(fd), body: html`<label class="f"><span>Why was it lost?</span><input name="lost_reason" required maxlength="255" placeholder="Hired in-house, no budget, chose competitor"><div class="hint">Lost reasons feed your analytics.</div></label>` });
        if (!r) return; payload.lost_reason = r.lost_reason;
      } else if (to === 'NOT_A_FIT') {
        const r = await dialog({ title: 'Mark as not a fit', submit: 'Mark as not a fit', danger: true, onSubmit: (fd) => formObj(fd), body: html`<label class="f"><span>Why isn't it a fit?</span><select name="disqualify_reason" required>${A.opts(A.DISQUALIFY_REASONS, '', 'Choose a reason')}</select><div class="hint">A structured reason feeds the Feedback tab in Analytics — which sources and industries are worth pursuing more of.</div></label>` });
        if (!r) return; payload.disqualify_reason = r.disqualify_reason;
      }
      act(() => post(`/api/leads/${id}/stage`, payload), `Moved to ${STAGE_LABEL[to]}`);
    }

    async function addContact() {
      const r = await dialog({ title: 'Add contact', submit: 'Add contact', onSubmit: (fd) => formObj(fd), body: html`<div class="form-grid">
        <label class="f"><span>Full name</span><input name="full_name" required></label><label class="f"><span>Title</span><input name="title"></label>
        <label class="f"><span>Email</span><input name="email" type="email"><div class="hint">Leave empty if unknown; do not guess.</div></label><label class="f"><span>LinkedIn URL</span><input name="linkedin_url"></label></div>` });
      if (!r) return;
      const body = Object.fromEntries(Object.entries(r).filter(([, v]) => v));
      act(async () => { const p = await post(`/api/companies/${d.company.id}/people`, body); await patch(`/api/leads/${id}`, { person_id: p.id }); }, 'Contact added');
    }

    // ------------------------------------------------------------------ evidence
    function evidence(el) {
      mount(el, html`
        <div class="notice">Every signal needs quoted evidence and a source. The app never invents evidence, so nothing is added without both.</div>
        <div class="row between" style="margin-bottom:12px"><h3>Signals on ${d.company.name}</h3><button class="btn btn-primary btn-sm" id="add-sig">Add signal</button></div>
        ${d.signals.length ? d.signals.map((s) => html`<div class="evidence"><div>${kind(s.kind)}<strong>${s.label}</strong></div><q>${s.evidence_text}</q>
          <div class="meta">${s.source}${s.source_url ? html` (<a href="${s.source_url}" target="_blank" rel="noopener noreferrer">open source</a>)` : ''}, detected ${fdate(s.date_detected)}, confidence ${Math.round(s.confidence * 100)}%, ${s.verified ? 'verified against the fetched page text' : 'entered manually or imported, not machine-verified'}
          <button class="btn btn-quiet btn-sm" data-del-sig="${s.id}">Delete</button></div></div>`)
          : empty('No evidence yet', 'Run web research on the company page, or add a signal you found yourself, with the exact wording and its source.')}`);
      $('#add-sig', el).addEventListener('click', () => addSignal(d.company.id, () => load().then(changed)));
      $$('[data-del-sig]', el).forEach((b) => b.addEventListener('click', async () => { if (await confirmDialog({ title: 'Delete this signal?', message: 'Qualification will be recalculated without it.', confirm: 'Delete signal', danger: true })) act(() => del(`/api/signals/${b.dataset.delSig}`), 'Signal deleted'); }));
    }

    // ------------------------------------------------------------------ messages
    function messages(el) {
      const fu = d.messages.filter((m) => ['sent', 'replied'].includes(m.status)).length;
      mount(el, html`
        <div class="notice good">This app never sends messages. You approve a draft, send it yourself from your own email or LinkedIn, then record it here.</div>
        <div class="row between" style="margin-bottom:12px"><div class="row"><button class="btn btn-primary btn-sm" id="gen">Draft messages</button>
          <button class="btn btn-sm" id="gen-fu" ${fu ? '' : raw('disabled title="Send the first message before drafting a follow-up"')}>Draft follow-up</button></div>
          <span class="muted small">Drafts use only the evidence on file.</span></div>
        <div class="stack">${d.messages.length ? d.messages.map(msgCard) : empty('No messages yet', 'Draft three variants from the evidence on this lead, choose one, edit it, then approve it.')}</div>`);
      $('#gen', el).addEventListener('click', () => act(() => post(`/api/leads/${id}/messages/generate`, {}), 'Drafts created'));
      $('#gen-fu', el).addEventListener('click', () => { const step = Math.max(1, ...d.messages.map((m) => m.sequence_step)) ; act(() => post(`/api/leads/${id}/messages/generate`, { followup_step: Math.min(step + 1, 10) }), 'Follow-up drafted'); });
      $$('[data-m]', el).forEach((b) => b.addEventListener('click', () => msgAction(b.dataset.m, Number(b.dataset.id))));
    }
    const msgCard = (m) => html`<div class="msg"><div class="row between"><div class="row"><span class="chip">${m.status}</span><span class="chip">${m.channel}</span>${m.sequence_step ? html`<span class="chip">Follow-up ${m.sequence_step}</span>` : ''}${m.ai_assisted ? html`<span class="chip">AI-polished</span>` : ''}</div><span class="muted small">${m.sent_at ? 'Sent ' + fdate(m.sent_at) : m.recipient ? 'To ' + m.recipient : ''}</span></div>
      ${m.subject ? html`<div style="margin-top:8px"><strong>${m.subject}</strong></div>` : ''}<pre>${m.body}</pre>
      ${(m.personalization_evidence || []).length ? html`<div class="muted small">Based on: ${m.personalization_evidence.map((e) => `${e.label} (${e.source})`).join('; ')}</div>` : ''}
      ${(m.warnings || []).length ? html`<ul class="warn-list">${m.warnings.map((w) => html`<li>${w}</li>`)}</ul>` : ''}
      <div class="row" style="margin-top:10px">
        <button class="btn btn-sm" data-m="copy" data-id="${m.id}">Copy text</button>
        ${m.status === 'draft' ? html`<button class="btn btn-sm" data-m="edit" data-id="${m.id}">Edit</button><button class="btn btn-sm btn-primary" data-m="approve" data-id="${m.id}">Approve</button><button class="btn btn-sm btn-quiet" data-m="reject" data-id="${m.id}">Reject</button><button class="btn btn-sm btn-quiet" data-m="delete" data-id="${m.id}">Delete</button>` : ''}
        ${m.status === 'approved' ? html`<button class="btn btn-sm" data-m="edit" data-id="${m.id}">Edit</button><button class="btn btn-sm btn-primary" data-m="send" data-id="${m.id}">Mark as sent</button>` : ''}
        ${m.status === 'sent' ? html`<button class="btn btn-sm btn-primary" data-m="reply" data-id="${m.id}">Mark as replied</button>` : ''}
      </div></div>`;
    async function msgAction(what, mid) {
      const m = d.messages.find((x) => x.id === mid);
      if (what === 'copy') { try { await navigator.clipboard.writeText((m.subject ? m.subject + '\n\n' : '') + m.body); ok('Copied to clipboard'); } catch { fail(new Error('Your browser blocked clipboard access. Select the text and copy it manually.')); } return; }
      if (what === 'edit') {
        const r = await dialog({ title: 'Edit message', wide: true, submit: 'Save message', onSubmit: (fd) => formObj(fd), body: html`<div class="stack"><label class="f"><span>Subject</span><input name="subject" value="${m.subject || ''}"></label><label class="f"><span>Message</span><textarea name="body" rows="12" required>${m.body}</textarea><div class="hint">Editing an approved message sends it back to draft so you can approve the final wording.</div></label></div>` });
        if (r) act(() => patch(`/api/messages/${mid}`, { subject: r.subject, body: r.body }), 'Message saved'); return;
      }
      if (what === 'approve') return act(() => post(`/api/messages/${mid}/approve`), 'Approved. Send it yourself, then mark it as sent.');
      if (what === 'reject') return act(() => post(`/api/messages/${mid}/reject`), 'Draft rejected');
      if (what === 'delete') return act(() => del(`/api/messages/${mid}`), 'Draft deleted');
      if (what === 'reply') return act(() => post(`/api/messages/${mid}/reply`), 'Marked as replied');
      if (what === 'send') {
        const r = await dialog({ title: 'Record that you sent it', submit: 'Mark as sent', onSubmit: (fd) => formObj(fd), body: html`<label class="f"><span>Date sent</span><input type="date" name="sent_at" value="${A.todayISO()}" max="${A.todayISO()}"><div class="hint">Follow-up tasks are scheduled from this date.</div></label>` });
        if (r) act(() => post(`/api/messages/${mid}/send`, { sent_at: r.sent_at }), 'Marked as sent. Follow-up scheduled.');
      }
    }

    // ------------------------------------------------------------------ activity
    function activity(el) {
      const open_ = d.tasks.filter((t) => t.status === 'open');
      mount(el, html`
        <div class="panel"><div class="panel-head"><h2>Log an interaction</h2></div><div class="panel-body"><form id="ix" class="form-grid">
          <label class="f"><span>Type</span><select name="type">${opts([['email', 'Email'], ['linkedin', 'LinkedIn'], ['call', 'Call'], ['meeting', 'Meeting'], ['note', 'Note'], ['form', 'Contact form'], ['other', 'Other']], 'note')}</select></label>
          <label class="f"><span>Direction</span><select name="direction">${opts([['internal', 'Internal note'], ['outbound', 'Outbound (from me)'], ['inbound', 'Inbound (from them)']], 'internal')}</select></label>
          <label class="f"><span>Date</span><input type="date" name="occurred_at" value="${A.todayISO()}" max="${A.todayISO()}"></label>
          <label class="f wide"><span>Subject</span><input name="subject" maxlength="300"></label>
          <label class="f wide"><span>What happened</span><textarea name="body" maxlength="5000"></textarea></label>
          <label class="f"><span>Outcome</span><input name="outcome" maxlength="200" placeholder="Positive, no answer, asked for proposal"></label>
          <div class="wide"><button class="btn btn-primary" type="submit">Log interaction</button><span class="muted small"> An inbound reply moves the lead to Replied and stops follow-ups.</span></div></form></div></div>
        <div class="panel"><div class="panel-head"><h2>Open tasks</h2><button class="btn btn-sm" id="add-task">Add task</button></div>
          ${open_.length ? html`<table class="tbl"><tbody>${open_.map((t) => html`<tr><td>${t.title}</td><td class="nowrap">${dueLabel(t.due_date)}</td><td class="right"><button class="btn btn-sm" data-done="${t.id}">Mark done</button></td></tr>`)}</tbody></table>` : html`<div class="panel-body muted">No open tasks.</div>`}</div>
        <div class="panel"><div class="panel-head"><h2>Timeline</h2></div><div class="panel-body">
          ${(() => { const items = [...d.interactions.map((i) => ({ at: i.occurred_at, t: html`<strong>${i.type}${i.direction !== 'internal' ? ', ' + i.direction : ''}</strong>${i.subject ? ': ' + i.subject : ''}${i.body ? html`<div class="muted">${i.body}</div>` : ''}${i.outcome ? html`<div class="small">Outcome: ${i.outcome}</div>` : ''}` })),
            ...d.history.map((h) => ({ at: h.at, t: html`Stage: ${h.from ? STAGE_LABEL[h.from] + ' to ' : ''}<strong>${STAGE_LABEL[h.to] || h.to}</strong>${h.note ? html`<span class="muted"> (${h.note})</span>` : ''}` }))].sort((a, b) => (b.at || '').localeCompare(a.at || ''));
            return items.length ? html`<ul class="timeline">${items.map((i) => html`<li><span class="muted small">${fdate(i.at)}</span><div>${i.t}</div></li>`)}</ul>` : empty('Nothing logged yet', 'Log calls, replies and notes so the history stays complete.'); })()}
        </div></div>`);
      $('#ix', el).addEventListener('submit', (e) => { e.preventDefault(); const f = formObj(new FormData(e.target)); const body = Object.fromEntries(Object.entries(f).filter(([, v]) => v)); act(() => post(`/api/leads/${id}/interactions`, body), 'Interaction logged'); });
      $$('[data-done]', el).forEach((b) => b.addEventListener('click', () => act(() => post(`/api/tasks/${b.dataset.done}/complete`), 'Task completed')));
      $('#add-task', el).addEventListener('click', async () => {
        const r = await dialog({ title: 'Add task', submit: 'Add task', onSubmit: (fd) => formObj(fd), body: html`<div class="stack"><label class="f"><span>Task</span><input name="title" required maxlength="300"></label><div class="form-grid"><label class="f"><span>Due date</span><input type="date" name="due_date" value="${A.todayISO()}"></label><label class="f"><span>Priority</span><select name="priority">${opts([['HIGH', 'High'], ['MEDIUM', 'Medium'], ['LOW', 'Low']], 'MEDIUM')}</select></label></div></div>` });
        if (r) act(() => post(`/api/leads/${id}/tasks`, Object.fromEntries(Object.entries(r).filter(([, v]) => v))), 'Task added');
      });
    }

    load();
    return dr;
  }

  async function addSignal(companyId, done) {
    const cat = await catalog();
    const r = await dialog({ title: 'Add a signal', submit: 'Add signal', wide: true, onSubmit: (fd) => formObj(fd), body: html`<div class="stack">
      <div class="form-grid"><label class="f"><span>What kind of signal is it?</span><select name="signal_type" required>${opts(cat.map((c) => [c.type, c.label]), '', 'Choose a signal type')}</select></label>
      <label class="f"><span>Confidence</span><select name="confidence">${opts([['0.9', 'High: stated plainly on the source'], ['0.7', 'Medium'], ['0.5', 'Low: indirect']], '0.7')}</select></label></div>
      <label class="f"><span>Evidence, in the source's own words</span><textarea name="evidence_text" required minlength="8" maxlength="2000" placeholder="Paste the exact sentence, for example: Controller wanted to own month-end close."></textarea><div class="hint">At least 8 characters. Paste the wording as published; do not paraphrase.</div></label>
      <div class="form-grid"><label class="f"><span>Where did you find it?</span><input name="source" required maxlength="255" placeholder="Careers page, press release, forum post"></label>
      <label class="f"><span>Link to the source</span><input name="source_url" type="url" maxlength="500" placeholder="https://"></label>
      <label class="f"><span>Date seen</span><input name="date_detected" type="date" value="${A.todayISO()}" max="${A.todayISO()}"></label></div></div>` });
    if (!r) return;
    const body = Object.fromEntries(Object.entries(r).filter(([, v]) => v)); body.confidence = Number(body.confidence); body.company_id = companyId;
    await guard(async () => { await post('/api/signals', body); ok('Signal added and lead re-qualified'); if (done) await done(); });
  }


  async function addLeadDialog(onDone, defaults = {}) {
    const campaigns = await get('/api/campaigns');
    const r = await dialog({ title: 'Add a lead', wide: true, submit: 'Add lead', onSubmit: (fd) => formObj(fd), body: html`<div class="stack">
      <div class="form-grid"><label class="f"><span>Company name</span><input name="name" required maxlength="255"></label>
      <label class="f"><span>Website</span><input name="website" placeholder="https://example.com"><div class="hint">A website lets the app spot duplicates and research the company.</div></label>
      <label class="f"><span>Campaign</span><select name="campaign_id">${opts(campaigns.map((c) => [c.id, c.name]), defaults.campaign_id, 'No campaign')}</select></label>
      <label class="f"><span>Country</span><input name="country" list="countries" placeholder="USA"><datalist id="countries"><option>USA</option><option>Poland</option></datalist></label>
      <label class="f"><span>City</span><input name="city"></label><label class="f"><span>Industry</span><input name="industry" placeholder="Transportation / Trucking"></label>
      <label class="f"><span>Employees</span><input name="employees" type="number" min="0"></label><label class="f"><span>Ownership</span><input name="ownership_type" placeholder="Privately owned, Foreign-owned"></label></div>
      <div class="form-grid"><label class="f"><span>Contact name</span><input name="p_full_name"></label><label class="f"><span>Contact title</span><input name="p_title"></label>
      <label class="f"><span>Contact email</span><input name="p_email" type="email"><div class="hint">Leave empty if unknown; never guess an address.</div></label></div></div>` });
    if (!r) return;
    const company = {}, person = {};
    Object.entries(r).forEach(([k, v]) => { if (!v || k === 'campaign_id') return; if (k.startsWith('p_')) person[k.slice(2)] = v; else company[k] = k === 'employees' ? Number(v) : v; });
    const body = { company, campaign_id: r.campaign_id ? Number(r.campaign_id) : null };
    if (Object.keys(person).length) body.person = person;
    await guard(async () => {
      const res = await post('/api/leads', body);
      const dup = res.possible_duplicates && res.possible_duplicates[0];
      if (dup) A.toast(`Added. Possible duplicate: ${dup.name} (${dup.label.toLowerCase()})`, { cause: dup.reasons.join('; '), suggestion: 'Review it under Companies to merge or dismiss.' }); else ok('Lead added');
      if (onDone) onDone(res.lead);
    });
  }

  window.Lead = { open, addSignal, addLeadDialog, services, catalog };
})();
