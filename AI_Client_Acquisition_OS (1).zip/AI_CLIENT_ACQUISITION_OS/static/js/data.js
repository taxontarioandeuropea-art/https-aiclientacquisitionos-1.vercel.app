(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, post, guard, ok, toast, int, empty, errBox, opts, formObj, confirmDialog, resultDialog, fail } = App;
  const root = $('#root'); const qp = new URLSearchParams(location.search);
  const KINDS = [['leads', 'Leads (company and contact per row)', 'One row per prospect. Company name is required; contact columns are optional.'], ['companies', 'Companies only', 'Adds companies without creating leads, unless you pick a campaign.'],
    ['contacts', 'Contacts', 'Adds people to their companies, creating the company if it is new.'], ['campaigns', 'Campaigns', 'Ideal customer profiles. Existing names are skipped.'], ['services', 'Services', 'Your service catalog. Existing names are skipped.'], ['interactions', 'Interactions', 'Past calls, emails and notes. Companies must already exist.']];
  const EXPORTS = [['leads', 'Leads', 'Every lead with its five dimensions, service, MRR and next action.'], ['crm', 'Full CRM', 'Companies, contacts, leads, interactions and tasks in separate sheets.'], ['pipeline', 'Pipeline', 'Leads ordered by stage with your stage estimates.'],
    ['campaign_results', 'Campaign results', 'Funnel counts, rates and MRR per campaign.'], ['company_research', 'Company research', 'Every signal with its evidence, source and date.'], ['sales_reports', 'Sales reports', 'Funnel and MRR by campaign, industry, country, service, signal and template.']];
  let file = null, prev = null, campaigns = [];
  async function init() {
    try { campaigns = await get('/api/campaigns'); } catch (e) { mount(root, errBox(e)); return; }
    const demo = await get('/api/demo').catch(() => ({ companies: 0 }));
    mount(root, html`<div class="cols-2"><section class="panel"><div class="panel-head"><h2>Import from CSV or Excel</h2></div><div class="panel-body stack" id="imp">
        <div class="form-grid"><label class="f"><span>What are you importing?</span><select id="kind">${opts(KINDS.map(([k, l]) => [k, l]), 'leads')}</select></label>
        <label class="f"><span>Add leads to campaign</span><select id="camp">${opts(campaigns.map((c) => [c.id, c.name]), qp.get('campaign_id') || '', 'No campaign')}</select></label>
        <label class="f wide"><span>File (.csv or .xlsx)</span><input type="file" id="file" accept=".csv,.xlsx"></label></div><p class="muted small" id="kind-note"></p><div><button class="btn btn-primary" id="preview">Preview import</button></div><div id="pv"></div></div></section>
      <div><section class="panel"><div class="panel-head"><h2>Export</h2></div><table class="tbl"><tbody>${EXPORTS.map(([k, l, d]) => html`<tr><td><strong>${l}</strong><span class="sub">${d}</span></td><td class="nowrap right"><a class="btn btn-sm" href="/api/export/${k}?format=xlsx">Excel</a> <a class="btn btn-sm" href="/api/export/${k}?format=csv">CSV</a></td></tr>`)}</tbody></table>
        <div class="panel-body muted small">Spreadsheet formulas in your data are neutralised so exported files are safe to open. Exports are also saved in the exports folder.</div></section>
      <section class="panel"><div class="panel-head"><h2>Demo data</h2></div><div class="panel-body stack"><p>${demo.companies ? `${demo.companies} fictional demo companies and ${demo.leads} leads are loaded.` : 'No demo data is loaded.'}</p>
        ${demo.companies ? html`<button class="btn btn-danger" id="rm">Remove demo data</button>` : html`<button class="btn" id="ld">Load demo data</button>`}</div></section></div></div>`);
    const note = () => { $('#kind-note').textContent = KINDS.find(([k]) => k === $('#kind').value)[2]; $('#camp').closest('label').style.opacity = ['leads', 'companies', 'contacts'].includes($('#kind').value) ? 1 : .4; };
    $('#kind').addEventListener('change', () => { note(); prev = null; mount($('#pv'), ''); }); note();
    $('#file').addEventListener('change', (e) => { file = e.target.files[0] || null; prev = null; mount($('#pv'), ''); });
    $('#preview').addEventListener('click', doPreview);
    const rm = $('#rm'); if (rm) rm.addEventListener('click', async () => { if (await confirmDialog({ title: 'Remove all demo data?', message: 'Deletes the fictional demo records and everything attached to them. Your own records are not touched.', confirm: 'Remove demo data', danger: true })) guard(async () => { await post('/api/demo/remove'); location.reload(); }); });
    const ld = $('#ld'); if (ld) ld.addEventListener('click', () => guard(async () => { await post('/api/demo/load'); location.reload(); }));
  }
  const form = () => { const fd = new FormData(); fd.append('kind', $('#kind').value); fd.append('file', file); return fd; };
  async function doPreview() {
    if (!file) { toast('Choose a CSV or Excel file first', { error: true }); return; }
    const btn = $('#preview'); btn.disabled = true;
    try { prev = await post('/api/import/preview', form()); } catch (e) { fail(e); btn.disabled = false; return; }
    btn.disabled = false; const targets = prev.available_targets;
    mount($('#pv'), html`<div class="stack" style="margin-top:14px"><div class="notice good">${int(prev.row_count)} row(s) found in ${prev.filename}. Check how each column is matched, then import.</div>
      ${prev.missing_required.length ? html`<div class="notice bad"><strong>A required column is not matched:</strong> ${prev.missing_required.join(', ')}. Choose it below.</div>` : ''}
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Column in your file</th><th>Example</th><th>Import it as</th></tr></thead><tbody>${prev.headers.filter(Boolean).map((h, i) => html`<tr><td>${h}</td><td class="muted">${(prev.sample.find((r) => r[h]) || {})[h] || ''}</td><td><select data-h="${h}">${opts(targets.map((t) => [t, t.replace('.', ': ').replace(/_/g, ' ')]), prev.mapping[h] || '', 'Ignore this column')}</select></td></tr>`)}</tbody></table></div>
      <div><button class="btn btn-primary" id="commit">Import ${int(prev.row_count)} row(s)</button></div></div>`);
    $('#commit').addEventListener('click', doCommit);
  }
  async function doCommit() {
    const mapping = {}; $$('[data-h]', $('#pv')).forEach((s) => { if (s.value) mapping[s.dataset.h] = s.value; });
    const fd = form(); fd.append('mapping', JSON.stringify(mapping)); const c = $('#camp').value; if (c) fd.append('campaign_id', c);
    const btn = $('#commit'); btn.disabled = true;
    try { const r = await post('/api/import/commit', fd); mount($('#pv'), ''); prev = null; await resultDialog('Import finished', r); }
    catch (e) { fail(e); } finally { btn.disabled = false; }
  }
  init();
})();
