(function () {
  'use strict';
  const { html, $, $$, mount, get, empty, errBox, opts, debounce } = App;
  const root = $('#root'); const st = { q: '', action: '', actor: '', entity_type: '', limit: 100 };
  async function init() {
    mount(root, html`<form class="filters" id="f"><label class="f"><span>Search</span><input name="q" placeholder="Words in the summary"></label><label class="f"><span>Action</span><select name="action" id="act"></select></label>
      <label class="f"><span>Who</span><select name="actor">${opts([['user', 'You'], ['ai', 'Automation (qualification, research)'], ['system', 'System']], '', 'Anyone')}</select></label>
      <label class="f"><span>Record type</span><select name="entity_type">${opts(['company', 'lead', 'person', 'campaign', 'service', 'signal', 'message', 'task'], '', 'Any')}</select></label></form>
      <section class="panel"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>What changed</th></tr></thead><tbody id="rows"></tbody></table></div><div class="panel-body row between" id="foot"></div></section>`);
    const onF = debounce(() => { $$('#f [name]').forEach((e) => { st[e.name] = e.value; }); st.limit = 100; refresh(); }, 220);
    $('#f').addEventListener('input', onF); $('#f').addEventListener('submit', (e) => e.preventDefault()); refresh(true);
  }
  async function refresh(first) {
    let d; try { d = await get('/api/audit', st); } catch (e) { mount($('#rows'), html`<tr><td colspan="4">${errBox(e)}</td></tr>`); return; }
    if (first) mount($('#act'), opts(d.actions.map((a) => [a, a.replace(/_/g, ' ')]), '', 'Any action'));
    mount($('#rows'), d.items.length ? d.items.map((a) => html`<tr><td class="nowrap">${new Date(a.timestamp).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</td><td>${{ user: 'You', ai: 'Automation', system: 'System' }[a.actor] || a.actor}</td><td>${a.action.replace(/_/g, ' ')}</td>
      <td>${a.summary}${a.details && Object.keys(a.details).length ? html`<details><summary class="muted small" style="cursor:pointer">Details</summary><pre class="small muted" style="white-space:pre-wrap;margin:6px 0">${JSON.stringify(a.details, null, 2)}</pre></details>` : ''}</td></tr>`)
      : html`<tr><td colspan="4">${empty('No matching entries', 'Change the filters to see more.')}</td></tr>`);
    mount($('#foot'), html`<span class="muted">Showing ${d.items.length} of ${d.total}</span>${d.total > d.items.length ? html`<button class="btn btn-sm" id="more">Show more</button>` : ''}`);
    const m = $('#more'); if (m) m.addEventListener('click', () => { st.limit += 100; refresh(); });
  }
  init();
})();
