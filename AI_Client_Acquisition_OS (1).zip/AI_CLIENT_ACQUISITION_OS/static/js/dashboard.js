(function () {
  'use strict';
  const { html, $, $$, mount, get, post, guard, ok, money, int, pct, fdate, dueLabel, stageBadge, prio, empty, errBox, opts, demoChip } = App;
  const root = $('#root');
  const shortAction = (a, c) => c ? String(a).replace(` — ${c}`, '').replace(` (${c})`, '') : a;

  async function load() {
    let d;
    try { d = await get('/api/dashboard'); } catch (e) { mount(root, errBox(e)); return; }
    const k = d.kpis;
    $('#page-actions').innerHTML = '';
    mount($('#page-actions'), html`<button class="btn btn-primary" id="add-lead">Add lead</button><a class="btn" href="/data">Import a list</a>`);
    $('#add-lead').addEventListener('click', () => Lead.addLeadDialog(load));
    if (!k.leads) { mount(root, html`<div class="panel">${empty('Nothing here yet', 'Add your first lead, import a list, or load demo data to see how the cockpit works.',
      html`<div class="row" style="justify-content:center;margin-top:12px"><button class="btn btn-primary" id="e-add">Add a lead</button><a class="btn" href="/data">Import a list</a><button class="btn" id="e-demo">Load demo data</button></div>`)}</div>`);
      $('#e-add').addEventListener('click', () => Lead.addLeadDialog(load));
      $('#e-demo').addEventListener('click', () => guard(async () => { await post('/api/demo/load'); location.reload(); })); return; }
    const cell = (label, value, note, cls = '') => html`<div><div class="k">${label}</div><div class="v ${cls}">${value}</div>${note ? html`<div class="n">${note}</div>` : ''}</div>`;
    mount(root, html`
      <section class="statement" aria-label="Key figures">
        ${cell('Qualified', int(k.qualified), `of ${int(k.leads)} leads`)}${cell('Contacted', int(k.contacted))}${cell('Replies', int(k.replies))}
        ${cell('Meetings', int(k.meetings))}${cell('Proposals', int(k.proposals))}${cell('Won clients', int(k.won))}
        ${cell('MRR', money(k.mrr), 'from won clients', 'money')}${cell('Pipeline', money(k.pipeline_value), `${money(k.weighted_pipeline)} by your stage estimates`)}
      </section>
      <div class="cols-2">
        <div>
          <section class="panel"><div class="panel-head"><h2>Top opportunities</h2><span class="muted small">If you have 30 minutes today</span></div>
            ${d.top_opportunities.length ? html`<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Company</th><th>Contact</th><th>Why</th><th>Offer</th><th class="num">Score</th></tr></thead><tbody>
              ${d.top_opportunities.map((o) => html`<tr class="clickable" data-lead="${o.lead_id}">
                <td><strong>${o.company}</strong><span class="sub">${stageBadge(o.stage)}</span></td>
                <td>${o.person ? html`${o.person.name || 'Unnamed'}<span class="sub">${o.person.title || ''}</span>` : html`<span class="attn">No contact</span>`}</td>
                <td class="small">${o.evidence.length ? o.evidence[0].signal : html`<span class="faint">No evidence yet</span>`}</td>
                <td>${o.recommended_offer ? html`${o.recommended_offer.service}<span class="sub">${money(o.recommended_offer.potential_mrr)}</span>` : html`<span class="faint">No match</span>`}</td>
                <td class="num fig" style="font-size:18px">${o.score}</td></tr>`)}
            </tbody></table></div>` : empty('No scored opportunities yet', 'Qualify some leads to see them ranked here by Opportunity Score.')}
          </section>
          <section class="panel"><div class="panel-head"><h2>What to do today</h2><a href="/leads?priority=HIGH" class="small">All high-priority leads</a></div>
            ${d.priorities.length ? html`<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Company</th><th>Evidence</th><th>Do this</th><th>Due</th><th class="num">Potential MRR</th></tr></thead><tbody>
              ${d.priorities.map((p) => html`<tr class="clickable" data-lead="${p.lead_id}"><td><strong>${p.company}</strong><span class="sub">${prio(p.priority)} ${stageBadge(p.status)}</span></td><td>${p.signal || html`<span class="faint">No signal yet</span>`}</td><td>${shortAction(p.action, p.company)}</td><td class="nowrap">${dueLabel(p.due)}</td><td class="num fig">${p.mrr ? money(p.mrr) : html`<span class="faint">No match</span>`}</td></tr>`)}
            </tbody></table></div>` : empty('Nothing urgent', 'No lead needs action today. Import more leads or run research to find evidence.')}
          </section>
          <section class="panel"><div class="panel-head"><h2>Tasks</h2><a href="/tasks" class="small">Open all tasks</a></div>
            ${(d.tasks.overdue.length + d.tasks.today.length) ? html`<table class="tbl"><tbody>${[...d.tasks.overdue, ...d.tasks.today].map((t) => html`<tr class="clickable" data-lead="${t.lead_id || ''}" data-company="${t.company_id || ''}"><td>${shortAction(t.title, t.company_name)}<span class="sub">${t.company_name || ''}</span></td><td class="nowrap right">${dueLabel(t.due_date)}</td></tr>`)}</tbody></table>`
            : html`<div class="panel-body muted">Nothing overdue or due today.</div>`}
            <div class="panel-body small muted">${d.tasks.counts.overdue} overdue, ${d.tasks.counts.today} due today, ${d.tasks.counts.upcoming} upcoming.</div>
          </section>
        </div>
        <div>
          <section class="panel"><div class="panel-head"><h2>Markets</h2></div><table class="tbl"><thead><tr><th>Market</th><th class="num">MRR</th><th class="num">Won</th><th class="num">Pipeline</th></tr></thead><tbody>
            ${d.markets.map((m) => html`<tr><td>${m.market}</td><td class="num fig">${money(m.mrr)}</td><td class="num">${m.won}</td><td class="num fig">${money(m.pipeline)}</td></tr>`)}</tbody>
            <tfoot><tr><td>Total</td><td class="num fig">${money(d.markets.reduce((a, m) => a + m.mrr, 0))}</td><td class="num">${d.markets.reduce((a, m) => a + m.won, 0)}</td><td class="num fig">${money(d.markets.reduce((a, m) => a + m.pipeline, 0))}</td></tr></tfoot></table></section>
          <section class="panel"><div class="panel-head"><h2>Funnel</h2></div><div class="panel-body">
            ${d.funnel.map((s, i) => html`<div class="bar-row"><span>${s.label}</span><div class="bar ${s.key === 'won' ? 'won' : ''}"><i style="width:${Math.max(s.pct_of_leads || 0, s.count ? 2 : 0)}%"></i></div><span class="num">${int(s.count)}</span></div>`)}
            <p class="muted small" style="margin-top:8px">${d.estimate_note}</p></div></section>
          <section class="panel"><div class="panel-head"><h2>Recent changes</h2><a href="/audit" class="small">Audit log</a></div><div class="panel-body">
            ${d.recent.length ? html`<ul class="timeline">${d.recent.map((a) => html`<li><span class="muted small">${fdate(a.timestamp)} by ${a.actor}</span><div>${a.summary}</div></li>`)}</ul>` : html`<span class="muted">No activity yet.</span>`}</div></section>
        </div>
      </div>`);
    $$('tr[data-lead]', root).forEach((tr) => tr.addEventListener('click', () => {
      if (tr.dataset.lead) Lead.open(Number(tr.dataset.lead), load); else if (tr.dataset.company) location.href = `/companies/${tr.dataset.company}`;
    }));
  }
  load();
})();
