(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, guard, money, fdate, dueLabel, stageBadge, prio, dims, empty, errBox, opts, debounce, demoChip, bindSort, th, STAGES, OFFPATH, STAGE_LABEL } = App;
  const root = $('#root');
  const params = new URLSearchParams(location.search);
  const state = { sort: 'priority', dir: 'desc', limit: 100, filters: Object.fromEntries(['q', 'campaign_id', 'stage', 'priority', 'country', 'signal', 'industry', 'service', 'min_mrr', 'max_mrr', 'date_from', 'date_to'].map((k) => [k, params.get(k) || ''])) };
  let campaigns = [], catalog = [];

  async function init() {
    try { [campaigns, catalog] = await Promise.all([get('/api/campaigns'), get('/api/signals/catalog')]); } catch (e) { mount(root, errBox(e)); return; }
    mount($('#page-actions'), html`<button class="btn btn-primary" id="add-lead">Add lead</button><a class="btn" href="/api/export/leads?format=xlsx">Export all leads (Excel)</a>`);
    $('#add-lead').addEventListener('click', () => Lead.addLeadDialog(refresh));
    const f = state.filters;
    const adv = ['industry', 'service', 'min_mrr', 'max_mrr', 'date_from', 'date_to'].some((k) => f[k]);
    mount(root, html`
      <form class="filters" id="filters" role="search" aria-label="Filter leads">
        <label class="f"><span>Search</span><input name="q" value="${f.q}" placeholder="Company, contact or service"></label>
        <label class="f"><span>Campaign</span><select name="campaign_id">${opts(campaigns.map((c) => [c.id, c.name]), f.campaign_id, 'All campaigns')}</select></label>
        <label class="f"><span>Stage</span><select name="stage">${opts([...STAGES, ...OFFPATH].map((s) => [s, STAGE_LABEL[s]]), f.stage, 'All stages')}</select></label>
        <label class="f"><span>Priority</span><select name="priority">${opts([['HIGH', 'High'], ['MEDIUM', 'Medium'], ['LOW', 'Low']], f.priority, 'Any priority')}</select></label>
        <label class="f"><span>Country</span><select name="country">${opts(['USA', 'Poland'], f.country, 'Any country')}</select></label>
        <label class="f"><span>Signal</span><select name="signal">${opts(catalog.map((c) => [c.type, c.label]), f.signal, 'Any signal')}</select></label>
      </form>
      <details ${adv ? raw('open') : ''} style="margin-bottom:14px"><summary class="muted" style="cursor:pointer">More filters</summary>
        <form class="filters" id="filters2" style="margin-top:10px">
          <label class="f"><span>Industry</span><input name="industry" value="${f.industry}"></label><label class="f"><span>Recommended service</span><input name="service" value="${f.service}"></label>
          <label class="f"><span>Min potential MRR</span><input name="min_mrr" type="number" min="0" value="${f.min_mrr}"></label><label class="f"><span>Max potential MRR</span><input name="max_mrr" type="number" min="0" value="${f.max_mrr}"></label>
          <label class="f"><span>Created from</span><input name="date_from" type="date" value="${f.date_from}"></label><label class="f"><span>Created to</span><input name="date_to" type="date" value="${f.date_to}"></label>
        </form></details>
      <section class="panel"><div class="tbl-wrap"><table class="tbl" id="tbl"><thead><tr>${th('company', 'Company')}<th>Campaign</th>${th('stage', 'Stage')}${th('priority', 'Priority', 'desc')}<th title="Fit, need, buying signal, ability to pay, contactability">Five dimensions</th><th>Top signal</th>${th('service', 'Service')}${th('mrr', 'Potential MRR', 'desc', 'num')}${th('next_action_date', 'Next action')}</tr></thead><tbody id="rows"></tbody></table></div><div class="panel-body row between" id="foot"></div></section>`);
    const onFilter = debounce(() => { $$('#filters [name], #filters2 [name]').forEach((el) => { state.filters[el.name] = el.value; }); state.limit = 100; refresh(); syncUrl(); }, 220);
    $$('#filters, #filters2').forEach((f_) => { f_.addEventListener('input', onFilter); f_.addEventListener('change', onFilter); f_.addEventListener('submit', (e) => e.preventDefault()); });
    bindSort($('#tbl'), state, refresh);
    refresh();
  }
  const syncUrl = () => { const q = new URLSearchParams(Object.entries(state.filters).filter(([, v]) => v)); history.replaceState(null, '', location.pathname + (q.toString() ? '?' + q : '')); };

  async function refresh() {
    const rows = $('#rows'); let d;
    try { d = await get('/api/leads', { ...state.filters, sort: state.sort, dir: state.dir, limit: state.limit }); } catch (e) { mount(rows, html`<tr><td colspan="9">${errBox(e)}</td></tr>`); return; }
    mount(rows, d.items.length ? d.items.map((l) => html`<tr class="clickable" data-id="${l.id}" tabindex="0">
      <td><strong>${l.company.name}</strong>${demoChip(l.is_demo)}<span class="sub">${l.person ? `${l.person.full_name || ''}${l.person.title ? ', ' + l.person.title : ''}` : 'No contact'}</span></td>
      <td class="muted">${l.campaign ? l.campaign.name : 'None'}</td><td>${stageBadge(l.status)}</td><td>${prio(l.overall_priority)}</td><td>${dims(l.dimensions)}</td>
      <td>${l.primary_signal || html`<span class="faint">None yet</span>`}</td><td>${l.recommended_service || html`<span class="faint">No match</span>`}</td>
      <td class="num fig">${l.potential_mrr ? money(l.potential_mrr) : html`<span class="faint">–</span>`}</td><td class="nowrap">${l.next_action_date ? dueLabel(l.next_action_date) : html`<span class="faint">None</span>`}</td></tr>`)
      : html`<tr><td colspan="9">${empty('No leads match these filters', 'Clear a filter, or add or import leads.')}</td></tr>`);
    $$('tr[data-id]', rows).forEach((tr) => { const go = () => Lead.open(Number(tr.dataset.id), refresh); tr.addEventListener('click', go); tr.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); }); });
    mount($('#foot'), html`<span class="muted">Showing ${d.items.length} of ${d.total} leads</span>${d.total > d.items.length ? html`<button class="btn btn-sm" id="more">Show more</button>` : ''}`);
    const more = $('#more'); if (more) more.addEventListener('click', () => { state.limit += 100; refresh(); });
  }
  init();
})();
