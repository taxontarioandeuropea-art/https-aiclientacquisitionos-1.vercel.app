/* Renders a research report. Every statement carries its Fact / Inference / Recommendation tag and source. */
(function () {
  'use strict';
  const { html, kind, fdate, empty } = App;
  const SECTIONS = [['executive_summary', 'Executive summary'], ['business_model', 'Business model'], ['industry', 'Industry'], ['size', 'Size'], ['technology', 'Technology'],
    ['growth', 'Growth'], ['buying_signals', 'Buying signals'], ['possible_finance_problems', 'Possible finance problems'], ['decision_makers', 'Decision makers'],
    ['recommended_service', 'Recommended service'], ['recommended_offer', 'Recommended offer'], ['outreach_angle', 'Outreach angle'], ['next_action', 'Next action']];
  const stmt = (s) => html`<div class="stmt">${kind(s.kind)}${s.text}${s.source ? html` <span class="muted small">Source: ${s.source}${s.source_url ? html` (<a href="${s.source_url}" target="_blank" rel="noopener noreferrer">open</a>)` : ''}${s.date ? ', ' + fdate(s.date) : ''}</span>` : ''}</div>`;
  function render(r) {
    if (!r) return empty('No report yet', 'Research the website to collect evidence, or build a report from the data already recorded.');
    const s = r.sections, p = s.company_profile, c = s.confidence;
    return html`
      <div class="notice">${kind('FACT')}read from a recorded source. ${kind('INFERENCE')}reasoning from facts. ${kind('RECOMMENDATION')}a suggested action. Generated ${fdate(r.generated_at)}.</div>
      ${r.ai_summary ? html`<div class="panel" style="margin-bottom:14px"><div class="panel-head"><h2>AI summary</h2></div><div class="panel-body">${r.ai_summary.text ? html`<p>${r.ai_summary.text}</p>` : ''}<p class="muted small">${r.ai_summary.note}</p></div></div>` : ''}
      <div class="panel" style="margin-bottom:14px"><div class="panel-head"><h2>Company profile</h2><span>Confidence: <strong class="${c.level === 'HIGH' ? 'pos' : c.level === 'LOW' ? 'neg' : 'attn'}">${c.level.charAt(0) + c.level.slice(1).toLowerCase()}</strong></span></div>
        <div class="panel-body"><dl class="kv">${Object.entries(p).map(([k, v]) => html`<dt>${k.replace(/_/g, ' ').replace(/^./, (m) => m.toUpperCase())}</dt><dd>${Array.isArray(v) ? (v.join(', ') || 'None') : (v === null ? 'Not determined' : k === 'potential_mrr' ? App.money(v) : v)}</dd>`)}</dl>
        <p class="muted small" style="margin-top:10px">Why this confidence: ${c.reasons.join('; ')}.</p></div></div>
      ${SECTIONS.map(([k, label]) => (s[k] || []).length ? html`<div class="panel" style="margin-bottom:14px"><div class="panel-head"><h2>${label}</h2></div><div class="panel-body">${s[k].map(stmt)}</div></div>` : '')}
      <div class="panel" style="margin-bottom:14px"><div class="panel-head"><h2>Evidence</h2></div><div class="panel-body">
        ${s.evidence.length ? s.evidence.map((e) => html`<div class="evidence"><div>${kind(e.kind)}<strong>${e.signal}</strong></div><q>${e.evidence_text}</q><div class="meta">${e.source}${e.source_url ? html` (<a href="${e.source_url}" target="_blank" rel="noopener noreferrer">open</a>)` : ''}, ${fdate(e.date_detected)}, ${e.verified ? 'verified against the fetched page text' : 'not machine-verified'}</div></div>`) : html`<span class="muted">No evidence recorded.</span>`}</div></div>
      ${(r.data_gaps || []).length ? html`<div class="panel"><div class="panel-head"><h2>Data gaps</h2></div><div class="panel-body"><ul class="reasons">${r.data_gaps.map((g) => html`<li>${g}</li>`)}</ul></div></div>` : ''}
      ${r.research_log ? html`<div class="panel" style="margin-top:14px"><div class="panel-head"><h2>Last research run</h2></div><div class="panel-body small">
        ${r.research_log.web ? html`<p>Read ${r.research_log.web.pages.filter((x) => x.used).length} page(s): ${r.research_log.web.pages.map((x) => x.url).join(', ')}.</p>` : ''}
        <p>${r.research_log.signals_added} new signal(s) added${(r.research_log.fields_added || []).length ? '; filled ' + r.research_log.fields_added.join(', ') : ''}.</p>
        ${(r.research_log.errors || []).map((e) => html`<p class="attn">${e}</p>`)}</div></div>` : ''}`;
  }
  window.Report = { render };
})();
