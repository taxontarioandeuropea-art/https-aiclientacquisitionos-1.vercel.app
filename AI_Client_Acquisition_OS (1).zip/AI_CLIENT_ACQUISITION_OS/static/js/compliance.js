(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, put, post, del, guard, ok, int, empty, errBox, opts, debounce, dialog, formObj, confirmDialog } = App;
  const root = $('#root');
  const STATUS_LABEL = { CLEAR: 'Clear', REVIEW_REQUIRED: 'Review required', RESTRICTED: 'Restricted', SUPPRESSED: 'Suppressed' };
  const STATUS_CLASS = { CLEAR: 'pos', REVIEW_REQUIRED: 'attn', RESTRICTED: 'neg', SUPPRESSED: 'neg' };
  const BASIS_LABEL = { legitimate_interest_b2b: 'Legitimate interest (B2B)', public_task_source: 'Public-task source', consent: 'Consent' };
  let state = { status: '', q: '' };

  async function init() {
    mount($('#page-actions'), html`<button class="btn" id="add-supp">Add to suppression list</button>`);
    $('#add-supp').addEventListener('click', addSuppression);
    mount(root, html`<div id="summary"></div>
      <div class="tabs" role="tablist"><button role="tab" aria-selected="true" data-tab="companies">Companies</button><button role="tab" aria-selected="false" data-tab="suppression">Suppression list</button></div>
      <div id="tab"></div>`);
    $$('[data-tab]', root).forEach((b) => b.addEventListener('click', () => { $$('[data-tab]', root).forEach((x) => x.setAttribute('aria-selected', x === b)); draw(b.dataset.tab); }));
    await loadSummary();
    draw('companies');
  }

  async function loadSummary() {
    let s; try { s = await get('/api/compliance/summary'); } catch (e) { mount($('#summary'), errBox(e)); return; }
    mount($('#summary'), html`<section class="statement" style="margin-bottom:20px">
      <div><div class="k">Clear</div><div class="v pos">${int(s.counts.CLEAR)}</div></div>
      <div><div class="k">Review required</div><div class="v attn">${int(s.counts.REVIEW_REQUIRED)}</div></div>
      <div><div class="k">Restricted</div><div class="v neg">${int(s.counts.RESTRICTED)}</div></div>
      <div><div class="k">Suppressed contacts</div><div class="v neg">${int(s.suppressed)}</div></div>
      <div><div class="k">Total companies</div><div class="v">${int(s.total_companies)}</div></div></section>`);
  }

  async function draw(tab) {
    if (tab === 'companies') return drawCompanies();
    return drawSuppression();
  }

  async function drawCompanies() {
    const el = $('#tab');
    mount(el, html`<form class="filters" id="f"><label class="f"><span>Search</span><input name="q" value="${state.q}" placeholder="Company name"></label>
      <label class="f"><span>Status</span><select name="status">${opts([['CLEAR', 'Clear'], ['REVIEW_REQUIRED', 'Review required'], ['RESTRICTED', 'Restricted'], ['SUPPRESSED', 'Suppressed']], state.status, 'Any status')}</select></label></form>
      <section class="panel"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Company</th><th>Status</th><th>Lawful basis</th><th>Why</th><th></th></tr></thead><tbody id="rows"></tbody></table></div></section>`);
    const onF = debounce(() => { $$('#f [name]', el).forEach((e) => { state[e.name] = e.value; }); refreshCompanies(); }, 220);
    $('#f', el).addEventListener('input', onF); $('#f', el).addEventListener('submit', (e) => e.preventDefault());
    refreshCompanies();
  }

  async function refreshCompanies() {
    let rows; try { rows = await get('/api/compliance/companies', { status: state.status, q: state.q }); } catch (e) { mount($('#rows'), html`<tr><td colspan="5">${errBox(e)}</td></tr>`); return; }
    mount($('#rows'), rows.length ? rows.map((r) => html`<tr><td><strong>${r.name}</strong>${r.country ? html`<span class="sub">${r.country}</span>` : ''}</td>
      <td><span class="${STATUS_CLASS[r.status]}">${STATUS_LABEL[r.status] || r.status}</span></td>
      <td>${r.lawful_basis ? BASIS_LABEL[r.lawful_basis] || r.lawful_basis : html`<span class="faint">None</span>`}</td>
      <td class="muted small">${r.reason}</td>
      <td class="right"><button class="btn btn-sm" data-review="${r.company_id}">Review</button></td></tr>`)
      : html`<tr><td colspan="5">${empty('No companies match', 'Adjust the filters above.')}</td></tr>`);
    $$('[data-review]', $('#rows')).forEach((b) => b.addEventListener('click', () => review(Number(b.dataset.review))));
  }

  async function review(companyId) {
    let cur; try { cur = await get(`/api/compliance/companies/${companyId}`); } catch (e) { App.fail(e); return; }
    const rec = cur.record || {};
    const r = await dialog({ title: 'Review compliance status', submit: 'Save', onSubmit: (fd) => formObj(fd), body: html`<div class="stack">
      <div class="notice${cur.status === 'CLEAR' ? ' good' : cur.status === 'SUPPRESSED' ? ' bad' : ''}">Current: <strong>${STATUS_LABEL[cur.status]}</strong> — ${cur.reason}</div>
      <label class="f"><span>Status</span><select name="status" required>${opts([['CLEAR', 'Clear — may be contacted'], ['REVIEW_REQUIRED', 'Review required'], ['RESTRICTED', 'Restricted — do not contact for now']], cur.status === 'SUPPRESSED' ? 'REVIEW_REQUIRED' : cur.status)}</select></label>
      <label class="f"><span>Lawful basis</span><select name="lawful_basis">${opts(Object.entries(BASIS_LABEL), rec.lawful_basis || '', 'None yet')}</select><div class="hint">Required to mark Clear. For B2B outreach to a published business contact, "Legitimate interest" is the usual basis — but that's your judgment call, not something this app assumes for you.</div></label>
      <label class="f"><span>Contact type</span><select name="contact_type">${opts([['professional', 'Professional (company role)'], ['personal', 'Personal']], rec.contact_type || '', 'Not set')}</select></label>
      <label class="f"><span>Notes</span><textarea name="notes">${rec.notes || ''}</textarea></label></div>` });
    if (!r) return;
    const body = Object.fromEntries(Object.entries(r).filter(([, v]) => v !== ''));
    guard(async () => { await put(`/api/compliance/companies/${companyId}`, body); ok('Compliance status saved'); loadSummary(); refreshCompanies(); });
  }

  async function drawSuppression() {
    const el = $('#tab');
    mount(el, html`<section class="panel"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Type</th><th>Value</th><th>Reason</th><th>Note</th><th>Added</th><th></th></tr></thead><tbody id="supp-rows"></tbody></table></div></section>`);
    let rows; try { rows = await get('/api/compliance/suppression'); } catch (e) { mount($('#supp-rows'), html`<tr><td colspan="6">${errBox(e)}</td></tr>`); return; }
    mount($('#supp-rows'), rows.length ? rows.map((e) => html`<tr><td>${e.match_type}</td><td>${e.value}</td><td>${e.reason.replace('_', ' ')}</td><td class="muted">${e.note || ''}</td><td class="nowrap">${App.fdate(e.created_at)}</td><td class="right"><button class="btn btn-sm btn-quiet" data-del="${e.id}">Remove</button></td></tr>`)
      : html`<tr><td colspan="6">${empty('Nothing suppressed', 'Add a company, email or domain that must never be contacted.')}</td></tr>`);
    $$('[data-del]', $('#supp-rows')).forEach((b) => b.addEventListener('click', async () => { if (await confirmDialog({ title: 'Remove from suppression list?', message: 'This entry will become contactable again once removed.', confirm: 'Remove' })) guard(async () => { await del(`/api/compliance/suppression/${b.dataset.del}`); ok('Removed'); loadSummary(); drawSuppression(); }); }));
  }

  async function addSuppression() {
    const r = await dialog({ title: 'Add to suppression list', submit: 'Add', onSubmit: (fd) => formObj(fd), body: html`<div class="stack">
      <label class="f"><span>Type</span><select name="match_type" required>${opts([['email', 'Email address'], ['domain', 'Website domain'], ['company', 'Company (by internal ID)']], 'email')}</select></label>
      <label class="f"><span>Value</span><input name="value" required placeholder="name@example.com, example.com, or a company ID"></label>
      <label class="f"><span>Reason</span><select name="reason">${opts([['opt_out', 'Opted out'], ['complaint', 'Complaint'], ['bounced', 'Bounced'], ['manual', 'Manual'], ['legal_request', 'Legal request']], 'manual')}</select></label>
      <label class="f"><span>Note</span><input name="note" maxlength="1000"></label></div>` });
    if (!r) return;
    const body = Object.fromEntries(Object.entries(r).filter(([, v]) => v));
    guard(async () => { await post('/api/compliance/suppression', body); ok('Added to suppression list'); loadSummary(); drawSuppression(); });
  }

  init();
})();
