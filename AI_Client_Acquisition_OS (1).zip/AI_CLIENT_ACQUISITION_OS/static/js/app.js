/* Shared helpers. No framework, no build step. All dynamic text goes through html`` which escapes by default. */
(function () {
  'use strict';

  // ---------------------------------------------------------------- safe templating
  class Safe { constructor(s) { this.s = s; } toString() { return this.s; } }
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const render = (v) => v instanceof Safe ? v.s : Array.isArray(v) ? v.map(render).join('') : (v === null || v === undefined || v === false) ? '' : esc(v);
  const html = (strings, ...vals) => new Safe(strings.reduce((out, s, i) => out + s + (i < vals.length ? render(vals[i]) : ''), ''));
  const raw = (s) => new Safe(String(s));
  const mount = (el, content) => { el.innerHTML = render(content); return el; };
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  // ---------------------------------------------------------------- API
  class ApiError extends Error {
    constructor(e, status) { super(e.message || 'Request failed'); this.cause_ = e.cause; this.suggestion = e.suggestion; this.operation = e.operation; this.status = status; }
  }
  const qs = (o) => { const p = new URLSearchParams(); Object.entries(o || {}).forEach(([k, v]) => { if (v !== '' && v !== null && v !== undefined) p.append(k, v); }); const s = p.toString(); return s ? '?' + s : ''; };
  async function api(method, url, body) {
    const init = { method, headers: {} };
    if (body instanceof FormData) init.body = body;
    else if (body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
    let r;
    try { r = await fetch(url, init); }
    catch (e) { throw new ApiError({ message: 'The server cannot be reached', cause: 'The application may have stopped.', suggestion: 'Start it again with python app.py, then reload this page.' }, 0); }
    const data = await r.json().catch(() => null);
    if (!r.ok) throw new ApiError((data && data.error) || { message: `Request failed (${r.status})` }, r.status);
    return data;
  }
  const get = (u, params) => api('GET', u + qs(params));
  const post = (u, b) => api('POST', u, b === undefined ? {} : b);
  const patch = (u, b) => api('PATCH', u, b);
  const put = (u, b) => api('PUT', u, b);
  const del = (u) => api('DELETE', u);

  // ---------------------------------------------------------------- toasts
  function toastHost() { let h = $('.toasts'); if (!h) { h = document.createElement('div'); h.className = 'toasts'; h.setAttribute('role', 'status'); h.setAttribute('aria-live', 'polite'); document.body.appendChild(h); } return h; }
  function toast(message, opts = {}) {
    const el = document.createElement('div');
    el.className = 'toast' + (opts.error ? ' err' : '');
    mount(el, html`<div><strong>${message}</strong></div>${opts.cause ? html`<div class="cause">${opts.cause}</div>` : ''}${opts.suggestion ? html`<div class="fix">${opts.suggestion}</div>` : ''}`);
    toastHost().appendChild(el);
    setTimeout(() => el.remove(), opts.error ? 9000 : 3800);
  }
  const ok = (m) => toast(m);
  function fail(e) {
    if (e instanceof ApiError) toast(e.message, { error: true, cause: e.cause_, suggestion: e.suggestion });
    else { console.error(e); toast('Something went wrong in the page', { error: true, cause: String(e && e.message || e) }); }
  }
  async function guard(fn) { try { return await fn(); } catch (e) { fail(e); return undefined; } }

  // ---------------------------------------------------------------- formatting
  const usd = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
  const money = (n) => (n === null || n === undefined || n === '') ? '–' : usd.format(n);
  const int = (n) => (n === null || n === undefined) ? '–' : new Intl.NumberFormat('en-US').format(n);
  const pct = (n) => (n === null || n === undefined) ? '–' : `${n}%`;
  function fdate(v) {
    if (!v) return '–';
    const d = new Date(v.length === 10 ? v + 'T00:00:00' : v);
    if (isNaN(d)) return esc(v);
    const same = d.getFullYear() === new Date().getFullYear();
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', ...(same ? {} : { year: 'numeric' }) });
  }
  function ago(v) {
    if (!v) return '';
    const d = new Date(v.length === 10 ? v + 'T00:00:00' : v); const days = Math.round((Date.now() - d) / 864e5);
    return days <= 0 ? 'today' : days === 1 ? 'yesterday' : `${days} days ago`;
  }
  function dueLabel(v) {
    if (!v) return html`<span class="faint">No date</span>`;
    const t = new Date(); t.setHours(0, 0, 0, 0); const d = new Date(v + 'T00:00:00'); const diff = Math.round((d - t) / 864e5);
    if (diff < 0) return html`<span class="neg">${Math.abs(diff)} day${Math.abs(diff) === 1 ? '' : 's'} overdue</span>`;
    if (diff === 0) return html`<span class="attn">Today</span>`;
    return html`<span>${fdate(v)}</span>`;
  }
  const todayISO = () => new Date().toISOString().slice(0, 10);

  // ---------------------------------------------------------------- domain constants (mirror core/constants.py)
  const STAGES = ['NEW', 'RESEARCHED', 'QUALIFIED', 'CONTACTED', 'REPLIED', 'CALL', 'PROPOSAL', 'NEGOTIATION', 'WON'];
  const OFFPATH = ['LOST', 'NURTURE', 'NOT_A_FIT'];
  const STAGE_LABEL = { NEW: 'New', RESEARCHED: 'Researched', QUALIFIED: 'Qualified', CONTACTED: 'Contacted', REPLIED: 'Replied', CALL: 'Call', PROPOSAL: 'Proposal', NEGOTIATION: 'Negotiation', WON: 'Won', LOST: 'Lost', NURTURE: 'Nurture', NOT_A_FIT: 'Not a fit' };
  const DISQUALIFY_REASONS = [['not_relevant', 'Not relevant'], ['wrong_industry', 'Wrong industry'], ['too_small', 'Too small'], ['too_large', 'Too large'], ['wrong_contact', 'Wrong contact'], ['no_email', 'No email found'], ['bad_data', 'Bad data'], ['other', 'Other']];
  const DIMS = [['fit', 'Fit'], ['need', 'Need'], ['signal', 'Buying signal'], ['ability_to_pay', 'Ability to pay'], ['contactability', 'Contactability']];
  const LEVEL_LABEL = { HIGH: 'High', MEDIUM: 'Medium', LOW: 'Low', UNKNOWN: 'Unknown' };

  // ---------------------------------------------------------------- small components
  const stageBadge = (s) => html`<span class="stage s-${String(s).toLowerCase()}">${STAGE_LABEL[s] || s}</span>`;
  const prio = (p) => p ? html`<span class="prio p-${p.toLowerCase()}">${LEVEL_LABEL[p] || p}</span>` : html`<span class="prio">Not scored</span>`;
  const kind = (k) => html`<span class="kind k-${String(k).toLowerCase()}" title="${{ FACT: 'Read from a recorded source', INFERENCE: 'Reasoning from facts', RECOMMENDATION: 'Suggested action' }[k] || ''}">${{ FACT: 'Fact', INFERENCE: 'Inference', RECOMMENDATION: 'Recommendation' }[k] || k}</span>`;
  const demoChip = (d) => d ? html` <span class="chip demo" title="Fictional demo record">Demo</span>` : '';
  function dims(d) {
    if (!d) return '';
    const label = DIMS.map(([k, n]) => `${n}: ${LEVEL_LABEL[(d[k] || {}).level] || 'Unknown'}`).join(', ');
    return html`<span class="dims" role="img" aria-label="${label}" title="${label}">${DIMS.map(([k]) => html`<i class="dim d-${((d[k] || {}).level || 'UNKNOWN').toLowerCase()}"></i>`)}</span>`;
  }
  const empty = (title, text, action) => html`<div class="empty"><strong>${title}</strong>${text}${action || ''}</div>`;
  const loading = (t = 'Loading…') => html`<div class="loading" aria-busy="true">${t}</div>`;
  const errBox = (e) => html`<div class="notice bad"><strong>${e.message || 'Could not load this section'}</strong>${e.cause_ ? html`<div>${e.cause_}</div>` : ''}${e.suggestion ? html`<div class="muted">${e.suggestion}</div>` : ''}</div>`;
  const companyLink = (id, name) => html`<a href="/companies/${id}">${name}</a>`;
  const opts = (list, sel, blank) => [blank === undefined ? '' : html`<option value="">${blank}</option>`, list.map((o) => { const [v, l] = Array.isArray(o) ? o : [o, o]; return html`<option value="${v}" ${String(v) === String(sel ?? '') ? raw('selected') : ''}>${l}</option>`; })];
  const debounce = (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  // ---------------------------------------------------------------- overlays
  let lastFocus = null;
  function openDrawer({ title, subtitle, body, onClose }) {
    lastFocus = document.activeElement;
    const scrim = document.createElement('div'); scrim.className = 'scrim';
    const el = document.createElement('aside'); el.className = 'drawer'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', title || 'Details');
    mount(el, html`<div class="drawer-head"><div><h2 data-title>${title}</h2><div class="muted small" data-sub>${subtitle || ''}</div></div><button class="btn btn-quiet btn-sm" data-close aria-label="Close">Close</button></div><div class="drawer-body" data-body></div>`);
    document.body.append(scrim, el);
    const api_ = {
      el, body: $('[data-body]', el),
      setTitle(t, s) { $('[data-title]', el).textContent = t; $('[data-sub]', el).innerHTML = s ? render(s) : ''; },
      close() { document.removeEventListener('keydown', onKey); scrim.remove(); el.remove(); if (lastFocus && lastFocus.focus) lastFocus.focus(); if (onClose) onClose(); },
    };
    const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('dialog[open]')) api_.close(); };
    document.addEventListener('keydown', onKey);
    scrim.addEventListener('click', api_.close); $('[data-close]', el).addEventListener('click', api_.close);
    if (body) mount(api_.body, body);
    $('[data-close]', el).focus();
    return api_;
  }
  function dialog({ title, body, submit = 'Save', cancel = 'Cancel', wide = false, danger = false, onSubmit, onOpen }) {
    return new Promise((resolve) => {
      const dlg = document.createElement('dialog'); if (wide) dlg.className = 'wide';
      mount(dlg, html`<form method="dialog"><div class="dlg-head"><h2>${title}</h2></div><div class="dlg-body" data-dlg-body>${body}</div><div class="dlg-foot"><button type="button" class="btn btn-quiet" data-cancel>${cancel}</button><button type="submit" class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-submit>${submit}</button></div></form>`);
      document.body.appendChild(dlg);
      const finish = (v) => { dlg.close(); dlg.remove(); resolve(v); };
      $('[data-cancel]', dlg).addEventListener('click', () => finish(null));
      dlg.addEventListener('cancel', (e) => { e.preventDefault(); finish(null); });
      $('form', dlg).addEventListener('submit', async (e) => {
        e.preventDefault(); const btn = $('[data-submit]', dlg); btn.disabled = true;
        try { const res = onSubmit ? await onSubmit(new FormData(e.target), dlg) : true; if (res !== false) finish(res === undefined ? true : res); else btn.disabled = false; }
        catch (err) { fail(err); btn.disabled = false; }
      });
      dlg.showModal();
      if (onOpen) onOpen(dlg);
      const first = $('input:not([type=hidden]), select, textarea', dlg); if (first) first.focus();
    });
  }
  const confirmDialog = ({ title, message, confirm = 'Confirm', danger = false }) => dialog({ title, body: html`<p>${message}</p>`, submit: confirm, danger, onSubmit: () => true }).then((v) => v === true);
  const formObj = (fd) => Object.fromEntries(Array.from(fd.entries()).map(([k, v]) => [k, typeof v === 'string' ? v.trim() : v]));

  // ---------------------------------------------------------------- sortable tables (server-side sorting)
  function bindSort(table, state, onChange) {
    const paint = () => $$('th[data-sort]', table).forEach((th) => th.setAttribute('aria-sort', th.dataset.sort === state.sort ? (state.dir === 'asc' ? 'ascending' : 'descending') : 'none'));
    table.addEventListener('click', (e) => {
      const th = e.target.closest('th[data-sort]'); if (!th) return;
      if (state.sort === th.dataset.sort) state.dir = state.dir === 'asc' ? 'desc' : 'asc'; else { state.sort = th.dataset.sort; state.dir = th.dataset.first || 'asc'; }
      paint(); onChange();
    });
    paint(); return paint;
  }
  const th = (key, label, first, cls = '') => html`<th data-sort="${key}" ${first ? raw(`data-first="${first}"`) : ''} class="${cls}" tabindex="0">${label}</th>`;
  document.addEventListener('keydown', (e) => { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('th[data-sort]')) { e.preventDefault(); e.target.click(); } });

  // ---------------------------------------------------------------- shared actions
  const demoLink = () => {
    const b = $('#remove-demo');
    if (b) b.addEventListener('click', async () => {
      if (!(await confirmDialog({ title: 'Remove all demo data?', message: 'This deletes the fictional demo companies, leads, campaigns and services, and everything attached to them. Your own records are not touched.', confirm: 'Remove demo data', danger: true }))) return;
      await guard(async () => { await post('/api/demo/remove'); ok('Demo data removed'); setTimeout(() => location.reload(), 500); });
    });
  };
  document.addEventListener('DOMContentLoaded', demoLink);


  // Summary of an import / discovery run (counts, flagged duplicates, per-row errors)
  function resultDialog(title, r) {
    const row = (l, v) => html`<dt>${l}</dt><dd>${v}</dd>`;
    return dialog({ title, submit: 'Done', cancel: 'Close', wide: true, onSubmit: () => true, body: html`<div class="stack">
      <dl class="kv">${row('New companies', r.created_companies ?? r.created ?? 0)}${r.matched_companies !== undefined ? row('Matched existing companies', r.matched_companies) : ''}${r.created_people !== undefined ? row('New contacts', r.created_people) : ''}
        ${r.created_leads !== undefined ? row('New leads', r.created_leads) : ''}${r.existing_leads ? row('Already in the campaign', r.existing_leads) : ''}${r.signals_added !== undefined ? row('Signals with evidence', r.signals_added) : ''}${row('Skipped rows', r.skipped ?? 0)}</dl>
      ${(r.flagged_duplicates || []).length ? html`<div class="notice"><strong>${r.flagged_duplicates.length} possible duplicate(s) were kept separate.</strong> Review them on the Companies page.<ul class="reasons">${r.flagged_duplicates.slice(0, 6).map((d) => html`<li>${d.new_name} looks like ${d.existing_name} (${d.reasons.join('; ')})</li>`)}</ul></div>` : ''}
      ${(r.errors || []).length ? html`<div class="notice bad"><strong>${r.errors.length} row(s) could not be imported.</strong><ul class="reasons">${r.errors.slice(0, 10).map((e) => html`<li>${e.row ? 'Row ' + e.row + ': ' : ''}${e.message}</li>`)}</ul>${r.errors.length > 10 ? html`<div class="muted small">and ${r.errors.length - 10} more.</div>` : ''}</div>` : ''}</div>` });
  }

  window.App = { html, raw, esc, mount, $, $$, api, get, post, patch, put, del, qs, ApiError, toast, ok, fail, guard, money, int, pct, fdate, ago, dueLabel, todayISO,
    STAGES, OFFPATH, STAGE_LABEL, DISQUALIFY_REASONS, DIMS, LEVEL_LABEL, stageBadge, prio, kind, demoChip, dims, empty, loading, errBox, companyLink, opts, debounce,
    openDrawer, dialog, confirmDialog, formObj, bindSort, th, resultDialog };
})();
