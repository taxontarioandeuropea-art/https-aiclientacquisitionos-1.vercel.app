(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, post, patch, del, guard, ok, toast, money, int, pct, empty, errBox, opts, dialog, confirmDialog, formObj, resultDialog } = App;
  const root = $('#root');
  const CAMPAIGN_STATUS = [['draft', 'Draft'], ['active', 'Active'], ['paused', 'Paused'], ['completed', 'Completed']];
  const RULE_DIMS = [['fit', 'Fit'], ['need', 'Need'], ['signal', 'Buying signal'], ['ability_to_pay', 'Ability to pay'], ['contactability', 'Contactability']];
  let list = [], svcs = [];

  async function load() {
    try { [list, svcs] = await Promise.all([get('/api/campaigns'), get('/api/services')]); } catch (e) { mount(root, errBox(e)); return; }
    mount($('#page-actions'), html`<button class="btn btn-primary" id="new">New campaign</button>`);
    $('#new').addEventListener('click', () => edit(null));
    if (!list.length) { mount(root, html`<div class="panel">${empty('No campaigns yet', 'A campaign defines who you are looking for, which services you offer them and how you follow up. Start with one market.')}</div>`); return; }
    mount(root, list.map(card));
    $$('[data-act]', root).forEach((b) => b.addEventListener('click', () => run(b.dataset.act, Number(b.dataset.id))));
  }
  const range = (a, b, unit) => (a || b) ? `${a ? int(a) : 'any'} to ${b ? int(b) : 'any'} ${unit}` : null;
  const card = (c) => {
    const s = c.stats, n = s.counts;
    const facts = [['Market', [c.country, c.industry, c.subindustry].filter(Boolean).join(', ')], ['Company size', range(c.target_employees_min, c.target_employees_max, 'employees')], ['Revenue', range(c.target_revenue_min, c.target_revenue_max, 'USD')],
      ['Technology', (c.target_technology || []).join(', ')], ['Ownership', c.target_ownership], ['Decision makers', (c.preferred_decision_maker || []).join(', ')],
      ['Minimum and target MRR', c.minimum_mrr || c.target_mrr ? `${money(c.minimum_mrr)} and ${money(c.target_mrr)}` : null],
      ['Follow-ups', (c.followup_sequence || []).length ? 'Days ' + c.followup_sequence.map((x) => x.day).join(', ') : 'Default rhythm from Settings']].filter(([, v]) => v);
    return html`<section class="panel"><div class="panel-head"><div class="row"><h2>${c.name}</h2><span class="chip">${c.campaign_status}</span>${c.is_demo ? html`<span class="chip demo">Demo</span>` : ''}</div>
      <div class="actions"><button class="btn btn-sm" data-act="edit" data-id="${c.id}">Edit</button><button class="btn btn-sm" data-act="qualify" data-id="${c.id}">Re-qualify all leads</button><a class="btn btn-sm" href="/data?campaign_id=${c.id}">Import leads</a><button class="btn btn-sm" data-act="discover" data-id="${c.id}">Research websites</button><a class="btn btn-sm" href="/leads?campaign_id=${c.id}">View leads</a><button class="btn btn-sm btn-quiet" data-act="delete" data-id="${c.id}">Delete</button></div></div>
      <div class="panel-body cols-eq"><div>${c.icp_description ? html`<p>${c.icp_description}</p>` : ''}<dl class="kv">${facts.map(([k, v]) => html`<dt>${k}</dt><dd>${v}</dd>`)}<dt>Services</dt><dd>${c.services.length ? c.services.map((x) => html`<span class="chip" style="margin:0 4px 4px 0">${x}</span>`) : html`<span class="attn">None selected. No service can be recommended.</span>`}</dd></dl></div>
      <div><table class="tbl"><thead><tr><th>Funnel</th><th class="num">Leads</th><th class="num">Share of previous</th></tr></thead><tbody>
        ${[['Leads', 'leads'], ['Qualified', 'qualified'], ['Contacted', 'contacted'], ['Replies', 'replies'], ['Meetings', 'calls'], ['Proposals', 'proposals'], ['Won', 'won']].map(([l, k], i, arr) => html`<tr><td>${l}</td><td class="num">${n[k]}</td><td class="num muted">${i && n[arr[i - 1][1]] ? pct(Math.round(1000 * n[k] / n[arr[i - 1][1]]) / 10) : ''}</td></tr>`)}</tbody>
        <tfoot><tr><td>MRR won</td><td class="num fig" colspan="2">${money(s.mrr)}</td></tr><tr><td>Pipeline (potential)</td><td class="num fig" colspan="2">${money(s.pipeline_value)}</td></tr></tfoot></table></div></div></section>`;
  };
  async function run(what, id) {
    const c = list.find((x) => x.id === id);
    if (what === 'edit') return edit(c);
    if (what === 'qualify') return guard(async () => { const r = await post(`/api/campaigns/${id}/qualify-all`); toast(`Re-qualified ${r.processed} lead(s)`, { cause: `${r.by_priority.HIGH || 0} high, ${r.by_priority.MEDIUM || 0} medium, ${r.by_priority.LOW || 0} low. ${r.no_service_match} without an evidence-based service match.` }); load(); });
    if (what === 'delete') { if (await confirmDialog({ title: `Delete ${c.name}?`, message: `Its ${c.stats.counts.leads} lead(s) are kept but will no longer belong to a campaign. This cannot be undone.`, confirm: 'Delete campaign', danger: true })) guard(async () => { await del(`/api/campaigns/${id}`); ok('Campaign deleted'); load(); }); return; }
    if (what === 'discover') {
      const r = await dialog({ title: 'Research company websites', submit: 'Read websites', wide: true, onSubmit: (fd) => formObj(fd), body: html`<label class="f"><span>Company websites, one per line (up to 25)</span><textarea name="urls" rows="7" required placeholder="https://example-carrier.com"></textarea><div class="hint">The app reads each company's own public pages (homepage, careers, about, contact) and respects robots.txt. It records only what is on the page, with the excerpt and address as evidence. It does not search the web for prospects.</div></label>` });
      if (!r) return; const urls = r.urls.split(/\s+/).filter(Boolean);
      toast(`Reading ${urls.length} website(s). This can take a minute.`);
      guard(async () => { const rep = await post(`/api/campaigns/${id}/discover`, { urls }); await resultDialog('Website research finished', rep); load(); });
    }
  }
  async function edit(c) {
    const has = new Set(c ? c.service_ids : []); const rules = (c && c.qualification_rules) || {}; const w = rules.weights || {};
    const r = await dialog({ title: c ? `Edit ${c.name}` : 'New campaign', wide: true, submit: c ? 'Save campaign' : 'Create campaign', onSubmit: (fd) => ({ f: formObj(fd), services: fd.getAll('service_ids').map(Number) }), body: html`<div class="stack">
      <div class="form-grid"><label class="f wide"><span>Campaign name</span><input name="name" required value="${c ? c.name : ''}" maxlength="200" placeholder="USA, Trucking, Controller support"></label>
      <label class="f"><span>Status</span><select name="campaign_status">${opts(CAMPAIGN_STATUS, c ? c.campaign_status : 'draft')}</select></label><label class="f"><span>Country</span><input name="country" value="${c ? c.country || '' : ''}" placeholder="USA"></label>
      <label class="f"><span>Industry</span><input name="industry" value="${c ? c.industry || '' : ''}"></label><label class="f"><span>Sub-industry</span><input name="subindustry" value="${c ? c.subindustry || '' : ''}"></label>
      <label class="f wide"><span>Ideal customer, in plain words</span><textarea name="icp_description">${c ? c.icp_description || '' : ''}</textarea></label>
      <label class="f"><span>Minimum employees</span><input name="target_employees_min" type="number" min="0" value="${c ? c.target_employees_min ?? '' : ''}"></label><label class="f"><span>Maximum employees</span><input name="target_employees_max" type="number" min="0" value="${c ? c.target_employees_max ?? '' : ''}"></label>
      <label class="f"><span>Minimum revenue (USD per year)</span><input name="target_revenue_min" type="number" min="0" value="${c ? c.target_revenue_min ?? '' : ''}"></label><label class="f"><span>Maximum revenue (USD per year)</span><input name="target_revenue_max" type="number" min="0" value="${c ? c.target_revenue_max ?? '' : ''}"></label>
      <label class="f"><span>Technology (comma separated)</span><input name="target_technology" value="${c ? (c.target_technology || []).join(', ') : ''}" placeholder="QuickBooks"></label><label class="f"><span>Ownership</span><input name="target_ownership" value="${c ? c.target_ownership || '' : ''}" placeholder="Foreign-owned"></label>
      <label class="f"><span>Minimum MRR worth pursuing (USD)</span><input name="minimum_mrr" type="number" min="0" value="${c ? c.minimum_mrr ?? '' : ''}"></label><label class="f"><span>Target MRR (USD)</span><input name="target_mrr" type="number" min="0" value="${c ? c.target_mrr ?? '' : ''}"></label>
      <label class="f wide"><span>Preferred decision makers (comma separated)</span><input name="preferred_decision_maker" value="${c ? (c.preferred_decision_maker || []).join(', ') : ''}" placeholder="Owner, CFO, Controller"></label>
      <label class="f"><span>Follow-up days after first message</span><input name="followup_days" value="${c ? (c.followup_sequence || []).map((x) => x.day).join(', ') : ''}" placeholder="3, 7, 14"><div class="hint">Empty uses the default in Settings.</div></label><label class="f"><span>Message language</span><input name="language" maxlength="10" value="${c ? c.language || 'en' : 'en'}"></label>
      <label class="f wide"><span>Outreach strategy</span><textarea name="outreach_strategy">${c ? c.outreach_strategy || '' : ''}</textarea></label><label class="f wide"><span>Research rules</span><textarea name="research_rules" placeholder="Where to look for evidence for this market">${c ? c.research_rules || '' : ''}</textarea></label></div>
      <fieldset class="panel" style="border:1px solid var(--rule-soft);padding:12px 14px"><legend class="muted small" style="padding:0 6px">Services this campaign can recommend</legend>${svcs.length ? html`<div class="form-grid">${svcs.map((s) => html`<label class="check"><input type="checkbox" name="service_ids" value="${s.id}" ${has.has(s.id) ? raw('checked') : ''}><span>${s.name}</span></label>`)}</div>` : html`<span class="attn">Add services first.</span>`}</fieldset>
      <details><summary class="muted" style="cursor:pointer">Qualification rules (optional)</summary><div class="form-grid" style="margin-top:10px">
        ${RULE_DIMS.map(([k, l]) => html`<label class="f"><span>Weight: ${l}</span><input name="w_${k}" type="number" min="0" max="1" step="0.05" value="${w[k] ?? ''}" placeholder="Default"></label>`)}
        <label class="f"><span>High level from score</span><input name="high_threshold" type="number" min="0" max="100" value="${rules.high_threshold ?? ''}" placeholder="65"></label><label class="f"><span>Medium level from score</span><input name="medium_threshold" type="number" min="0" max="100" value="${rules.medium_threshold ?? ''}" placeholder="35"></label>
        <div class="hint wide">Leave blank for the defaults. Weights say how much each dimension counts toward priority; scores stay separate per dimension.</div></div></details></div>` });
    if (!r) return;
    const f = r.f, body = {}; const num = ['target_employees_min', 'target_employees_max', 'target_revenue_min', 'target_revenue_max', 'minimum_mrr', 'target_mrr'];
    Object.entries(f).forEach(([k, v]) => { if (k.startsWith('w_') || k === 'followup_days' || k === 'high_threshold' || k === 'medium_threshold') return; body[k] = num.includes(k) ? (v === '' ? null : Number(v)) : (v === '' ? null : v); });
    body.name = f.name; body.language = f.language || 'en';
    body.followup_sequence = f.followup_days.split(',').map((x) => x.trim()).filter(Boolean).map((d, i) => ({ day: Number(d), type: ['bump', 'value', 'final'][i] || 'custom', channel: 'email' }));
    const qr = {}, ws = {}; RULE_DIMS.forEach(([k]) => { if (f['w_' + k] !== '') ws[k] = Number(f['w_' + k]); }); if (Object.keys(ws).length) qr.weights = ws;
    ['high_threshold', 'medium_threshold'].forEach((k) => { if (f[k] !== '') qr[k] = Number(f[k]); }); body.qualification_rules = qr; body.service_ids = r.services;
    guard(async () => { c ? await patch(`/api/campaigns/${c.id}`, body) : await post('/api/campaigns', body); ok(c ? 'Campaign saved' : 'Campaign created'); load(); });
  }
  load();
})();
