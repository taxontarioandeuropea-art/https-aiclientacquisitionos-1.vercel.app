(function () {
  'use strict';
  const { html, $, $$, mount, get, post, guard, toast, ok, fdate, empty, errBox, opts, loading, resultDialog } = App;
  const root = $('#root'); const qp = new URLSearchParams(location.search);
  async function init() {
    let companies, recent, sources, campaigns, settings;
    try { [companies, recent, sources, campaigns, settings] = await Promise.all([get('/api/companies', { limit: 1000 }), get('/api/research/recent'), get('/api/research/sources'), get('/api/campaigns'), get('/api/settings')]); } catch (e) { mount(root, errBox(e)); return; }
    const aiOn = settings.settings.ai.provider !== 'none';
    mount(root, html`<div class="cols-2"><div>
      <section class="panel"><div class="panel-head"><h2>Research a company</h2></div><div class="panel-body stack">
        <label class="f"><span>Company</span><select id="co">${opts(companies.items.map((c) => [c.id, c.name]), qp.get('company_id') || '', 'Choose a company')}</select></label>
        <label class="check"><input type="checkbox" id="web" checked><span>Read the company's public website (careers, about, contact pages)</span></label>
        <label class="check"><input type="checkbox" id="ai" ${aiOn ? '' : App.raw('disabled')}><span>Add an AI-written summary${aiOn ? '' : ' (no AI provider configured in Settings)'}</span></label>
        <div><button class="btn btn-primary" id="run">Run research</button> <a class="btn btn-quiet" id="open" href="#" style="display:none">Open company profile</a></div>
        <p class="muted small">Research records only what is on the page, with the excerpt and address as evidence. Anything it cannot find stays marked unknown.</p></div></section>
      <div id="report"></div></div>
      <div><section class="panel"><div class="panel-head"><h2>Research websites for new leads</h2></div><div class="panel-body stack">
        <label class="f"><span>Websites, one per line</span><textarea id="urls" rows="5" placeholder="https://example-carrier.com"></textarea></label>
        <label class="f"><span>Add as leads to</span><select id="camp">${opts(campaigns.map((c) => [c.id, c.name]), '', 'No campaign')}</select></label>
        <button class="btn" id="disc">Read websites</button><p class="muted small">Company names are taken from each page title and flagged for you to verify.</p></div></section>
      <section class="panel"><div class="panel-head"><h2>Recently researched</h2></div>${recent.length ? html`<table class="tbl"><tbody>${recent.map((r) => html`<tr class="clickable" data-co="${r.company_id}"><td>${r.name}<span class="sub">${fdate(r.last_researched_at)}, ${r.signals} signal(s)</span></td><td class="right muted">${r.confidence ? r.confidence.charAt(0) + r.confidence.slice(1).toLowerCase() + ' confidence' : ''}</td></tr>`)}</tbody></table>` : html`<div class="panel-body muted">Nothing researched yet.</div>`}</section>
      <section class="panel"><div class="panel-head"><h2>Lead sources</h2></div><div class="panel-body small stack">${sources.map((s) => html`<div><strong>${s.name.replace('_', ' ')}</strong><div class="muted">${s.description}</div></div>`)}<p class="muted">Search engines, job boards, public registries and CRM exports are not connected in this version. They can be added as sources without changing the rest of the app.</p></div></section></div></div>`);
    const show = async (id) => { if (!id) return; const box = $('#report'); mount(box, loading('Loading report…')); try { const d = await get(`/api/companies/${id}`); mount(box, html`<div style="margin-top:18px">${Report.render(d.report)}</div>`); const a = $('#open'); a.href = `/companies/${id}`; a.style.display = ''; } catch (e) { mount(box, errBox(e)); } };
    $('#co').addEventListener('change', (e) => show(e.target.value));
    $('#run').addEventListener('click', async () => {
      const id = $('#co').value; if (!id) { toast('Choose a company first', { error: true }); return; }
      const btn = $('#run'); btn.disabled = true; toast($('#web').checked ? 'Reading the website. This can take up to a minute.' : 'Building the report…');
      try { const rep = await post('/api/research/run', { company_id: Number(id), use_web: $('#web').checked, use_ai: $('#ai').checked }); const log = rep.research_log || {};
        toast(`Research complete: ${log.signals_added || 0} new signal(s)`, { error: (log.errors || []).length > 0, cause: (log.errors || []).slice(0, 2).join(' ') }); await show(id); }
      catch (e) { App.fail(e); } finally { btn.disabled = false; }
    });
    $$('[data-co]', root).forEach((tr) => tr.addEventListener('click', () => { $('#co').value = tr.dataset.co; show(tr.dataset.co); scrollTo({ top: 0 }); }));
    $('#disc').addEventListener('click', () => { const urls = $('#urls').value.split(/\s+/).filter(Boolean); if (!urls.length) { toast('Enter at least one website', { error: true }); return; }
      toast(`Reading ${urls.length} website(s). This can take a minute.`); guard(async () => { const rep = await post('/api/research/discover', { urls, campaign_id: $('#camp').value ? Number($('#camp').value) : null }); await resultDialog('Website research finished', rep); }); });
    if (qp.get('company_id')) show(qp.get('company_id'));
  }
  init();
})();
