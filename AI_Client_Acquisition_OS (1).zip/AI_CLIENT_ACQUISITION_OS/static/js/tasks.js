(function () {
  'use strict';
  const { html, $, $$, mount, get, post, del, guard, ok, toast, dueLabel, empty, errBox, opts, dialog, formObj } = App;
  const root = $('#root');
  const GROUPS = [['overdue', 'Overdue'], ['today', 'Due today'], ['upcoming', 'Next 7 days'], ['later', 'Later'], ['no_date', 'No date']];
  const TYPE = { research_company: 'Research', find_decision_maker: 'Find contact', send_message: 'Send message', follow_up: 'Follow up', prepare_proposal: 'Proposal', call: 'Call', update_crm: 'Update CRM', other: 'Other' };
  async function load() {
    let d; try { d = await get('/api/tasks'); } catch (e) { mount(root, errBox(e)); return; }
    mount($('#page-actions'), html`<button class="btn btn-primary" id="add">Add task</button><button class="btn" id="gen">Create tasks from pipeline stages</button>`);
    $('#add').addEventListener('click', add); $('#gen').addEventListener('click', () => guard(async () => { const r = await post('/api/tasks/generate'); toast(r.created ? `Created ${r.created} task(s)` : 'No new tasks needed', { cause: 'Tasks follow each lead\'s stage and never duplicate an existing one.' }); load(); }));
    const total = GROUPS.reduce((n, [k]) => n + d[k].length, 0);
    if (!total && !d.done.length) { mount(root, html`<div class="panel">${empty('No tasks', 'Tasks appear when leads change stage, and you can add your own.')}</div>`); return; }
    mount(root, html`${total ? '' : html`<div class="panel">${empty('Nothing open', 'You are up to date.')}</div>`}
      ${GROUPS.filter(([k]) => d[k].length).map(([k, l]) => html`<section class="panel"><div class="panel-head"><h2>${l}</h2><span class="muted">${d[k].length}</span></div><div class="tbl-wrap"><table class="tbl"><tbody>${d[k].map((t) => row(t))}</tbody></table></div></section>`)}
      ${d.done.length ? html`<details><summary class="muted" style="cursor:pointer;margin:14px 0 8px">Completed (${d.done.length})</summary><section class="panel"><table class="tbl"><tbody>${d.done.slice(0, 40).map((t) => html`<tr><td class="faint">${t.title}<span class="sub">${t.company_name || ''}</span></td></tr>`)}</tbody></table></section></details>` : ''}`);
    $$('[data-done]', root).forEach((b) => b.addEventListener('click', () => guard(async () => { await post(`/api/tasks/${b.dataset.done}/complete`); ok('Task completed'); load(); })));
    $$('[data-del]', root).forEach((b) => b.addEventListener('click', () => guard(async () => { await del(`/api/tasks/${b.dataset.del}`); ok('Task deleted'); load(); })));
    $$('[data-lead]', root).forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); Lead.open(Number(a.dataset.lead), load); }));
  }
  const row = (t) => html`<tr><td style="width:96px"><button class="btn btn-sm" data-done="${t.id}" aria-label="Mark done: ${t.title}">Mark done</button></td>
    <td>${t.title}<span class="sub">${t.lead_id ? html`<a href="#" data-lead="${t.lead_id}">${t.company_name} (${t.lead_status})</a>` : (t.company_name || '')}</span></td><td class="muted">${TYPE[t.task_type] || t.task_type}</td><td>${t.priority.charAt(0) + t.priority.slice(1).toLowerCase()}</td><td class="nowrap">${dueLabel(t.due_date)}</td><td class="right"><button class="btn btn-sm btn-quiet" data-del="${t.id}">Delete</button></td></tr>`;
  async function add() {
    const r = await dialog({ title: 'Add task', submit: 'Add task', onSubmit: (fd) => formObj(fd), body: html`<div class="stack"><label class="f"><span>Task</span><input name="title" required maxlength="300"></label><div class="form-grid"><label class="f"><span>Due date</span><input type="date" name="due_date" value="${App.todayISO()}"></label><label class="f"><span>Priority</span><select name="priority">${opts([['HIGH', 'High'], ['MEDIUM', 'Medium'], ['LOW', 'Low']], 'MEDIUM')}</select></label></div></div>` });
    if (r) guard(async () => { await post('/api/tasks', Object.fromEntries(Object.entries(r).filter(([, v]) => v))); ok('Task added'); load(); });
  }
  load();
})();
