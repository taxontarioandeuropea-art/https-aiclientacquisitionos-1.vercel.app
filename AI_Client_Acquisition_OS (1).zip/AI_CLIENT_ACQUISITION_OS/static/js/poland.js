(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, post, guard, ok, toast, int, errBox, opts, loading, empty, fdate, dialog, formObj } = App;
  const root = $('#root');
  const WOJ = ['DOLNOSLASKIE', 'KUJAWSKO-POMORSKIE', 'LUBELSKIE', 'LUBUSKIE', 'LODZKIE', 'MALOPOLSKIE', 'MAZOWIECKIE',
    'OPOLSKIE', 'PODKARPACKIE', 'PODLASKIE', 'POMORSKIE', 'SLASKIE', 'SWIETOKRZYSKIE', 'WARMINSKO-MAZURSKIE',
    'WIELKOPOLSKIE', 'ZACHODNIOPOMORSKIE'];

  async function init() {
    let srcInfo, campaigns, settings;
    try { [srcInfo, campaigns, settings] = await Promise.all([get('/api/poland/sources'), get('/api/campaigns'), get('/api/settings')]); }
    catch (e) { mount(root, errBox(e)); return; }
    const ceidg = srcInfo.sources.find((s) => s.source_id === 'ceidg');
    const krs = srcInfo.sources.find((s) => s.source_id === 'krs');
    const gus = srcInfo.sources.find((s) => s.source_id === 'gus_regon');
    const tokenOn = settings.env.ceidg_token_present;

    mount(root, html`
      <div class="notice${tokenOn ? ' good' : ''}">
        ${tokenOn ? 'A CEIDG API token is configured — searches run against the live registry.'
          : html`CEIDG needs a free token to search. Register at <a href="https://dane.biznes.gov.pl/pl/dane-po-api" target="_blank" rel="noopener noreferrer">dane.biznes.gov.pl</a>, then set <code>CEIDG_API_TOKEN</code> in <code>.env</code> and restart. KRS lookups below work without any token.`}
      </div>
      <div class="cols-2"><div>
        <section class="panel"><div class="panel-head"><h2>Search CEIDG (sole traders)</h2><span class="chip">${ceidg.discovery_capable ? 'Discovery' : 'Lookup only'}</span></div>
          <div class="panel-body stack"><form id="ceidg-f" class="form-grid">
            <label class="f"><span>Company name contains</span><input name="nazwa"></label>
            <label class="f"><span>PKD code(s), comma separated</span><input name="pkd" placeholder="6920Z"></label>
            <label class="f"><span>City</span><input name="miasto"></label>
            <label class="f"><span>Voivodeship</span><select name="wojewodztwo">${opts(WOJ.map((w) => [w, w.charAt(0) + w.slice(1).toLowerCase()]), '', 'Any')}</select></label>
            <label class="f"><span>Registered from</span><input type="date" name="dataod"></label>
            <label class="f"><span>Registered to</span><input type="date" name="datado"></label>
            <label class="f"><span>Status</span><select name="status">${opts(srcInfo.ceidg_statuses.map((s) => [s, s.replace(/_/g, ' ')]), 'AKTYWNY', 'Any')}</select></label>
            <label class="f"><span>Add results to campaign</span><select name="campaign_id">${opts(campaigns.map((c) => [c.id, c.name]), '', 'No campaign (search only)')}</select></label>
            <div class="wide"><button class="btn btn-primary" type="submit">Search CEIDG</button></div>
          </form><div id="ceidg-result"></div></div></section>

        <section class="panel"><div class="panel-head"><h2>What changed recently (CEIDG)</h2></div><div class="panel-body stack">
          <p class="muted small">Pulls entries whose registration changed in a date range — status changes, new PKD codes — and records each as an event (and, where relevant, a qualification signal). Keep the range to 5 days or less per the registry's own guidance.</p>
          <form id="changes-f" class="form-grid">
            <label class="f"><span>From date</span><input type="date" name="dataod" required></label>
            <label class="f"><span>To date</span><input type="date" name="datado"></label>
            <label class="f"><span>Add results to campaign</span><select name="campaign_id">${opts(campaigns.map((c) => [c.id, c.name]), '', 'No campaign')}</select></label>
            <div class="wide"><button class="btn btn-primary" type="submit">Check for changes</button></div>
          </form><div id="changes-result"></div></div></section></div>

      <div>
        <section class="panel"><div class="panel-head"><h2>Enrich by KRS number</h2><span class="chip">No token needed</span></div><div class="panel-body stack">
          <p class="muted small">Looks up a company you already have a KRS number for (sp. z o.o., S.A., ...) and merges official data onto the matching record by shared NIP/REGON, or creates a new one.</p>
          <form id="krs-f" class="stack">
            <label class="f"><span>KRS number(s), one per line</span><textarea name="krs_numbers" rows="3" required placeholder="0000123456"></textarea></label>
            <label class="f"><span>Add to campaign</span><select name="campaign_id">${opts(campaigns.map((c) => [c.id, c.name]), '', 'No campaign')}</select></label>
            <button class="btn btn-primary" type="submit">Look up</button>
          </form><div id="krs-result"></div></div></section>

        <section class="panel"><div class="panel-head"><h2>Sources</h2></div><div class="panel-body stack small">
          ${[ceidg, krs, gus].map((s) => html`<div><div class="row between"><strong>${s.source_name.split(' (')[0]}</strong><span class="chip ${s.configured ? '' : 'demo'}">${s.reliability_score === 0 ? 'Not connected' : (s.configured || !s.requires_env.length) ? 'Ready' : 'Needs token'}</span></div><div class="muted">${s.notes}</div></div>`)}
        </div></section>
        <section class="panel"><div class="panel-head"><h2>Recent runs</h2></div><div id="runs"></div></section>
      </div></div>`);

    $('#ceidg-f').addEventListener('submit', (e) => { e.preventDefault(); runCeidgSearch(new FormData(e.target)); });
    $('#changes-f').addEventListener('submit', (e) => { e.preventDefault(); runChanges(new FormData(e.target)); });
    $('#krs-f').addEventListener('submit', (e) => { e.preventDefault(); runKrs(new FormData(e.target)); });
    loadRuns();
  }

  function resultSummary(box, res, label) {
    mount(box, html`<div class="notice ${res.status === 'FAILED' ? 'bad' : res.status === 'SUCCESS' ? 'good' : ''}">
      <strong>${label}: ${res.status}</strong> — fetched ${res.fetched}, ${res.created_businesses} new compan${res.created_businesses === 1 ? 'y' : 'ies'}, ${res.updated_businesses} updated, ${res.events_created} event(s)${res.lead_ids.length ? `, ${res.lead_ids.length} lead(s) created` : ''}.
      ${res.errors.length ? html`<ul class="reasons">${res.errors.slice(0, 5).map((e) => html`<li class="attn">${e}</li>`)}</ul>` : ''}
      ${res.company_ids.length ? html`<div style="margin-top:6px">${res.company_ids.slice(0, 10).map((id) => html`<a class="btn btn-sm" style="margin:0 4px 4px 0" href="/companies/${id}">Open company ${id}</a>`)}</div>` : ''}
    </div>`);
  }

  async function runCeidgSearch(fd) {
    const f = App.formObj(fd);
    const body = { max_results: 50 };
    if (f.nazwa) body.nazwa = [f.nazwa];
    if (f.pkd) body.pkd = f.pkd.split(',').map((x) => x.trim()).filter(Boolean);
    if (f.miasto) body.miasto = [f.miasto];
    if (f.wojewodztwo) body.wojewodztwo = [f.wojewodztwo];
    if (f.status) body.status = [f.status];
    if (f.dataod) body.dataod = f.dataod;
    if (f.datado) body.datado = f.datado;
    if (f.campaign_id) body.campaign_id = Number(f.campaign_id);
    mount($('#ceidg-result'), loading('Searching CEIDG…'));
    await guard(async () => { const res = await post('/api/poland/ceidg/search', body); resultSummary($('#ceidg-result'), res, 'CEIDG search'); loadRuns(); })
      .catch(() => {});
    if (!$('#ceidg-result').innerHTML) mount($('#ceidg-result'), '');
  }
  async function runChanges(fd) {
    const f = App.formObj(fd);
    const body = { dataod: f.dataod, datado: f.datado || undefined, campaign_id: f.campaign_id ? Number(f.campaign_id) : undefined };
    mount($('#changes-result'), loading('Checking for changes…'));
    guard(async () => { const res = await post('/api/poland/ceidg/changes', body); resultSummary($('#changes-result'), res, 'Change check'); loadRuns(); });
  }
  async function runKrs(fd) {
    const f = App.formObj(fd);
    const krs_numbers = f.krs_numbers.split(/\s+/).map((x) => x.trim()).filter(Boolean);
    mount($('#krs-result'), loading('Looking up KRS…'));
    guard(async () => { const res = await post('/api/poland/krs/enrich', { krs_numbers, campaign_id: f.campaign_id ? Number(f.campaign_id) : undefined }); resultSummary($('#krs-result'), res, 'KRS lookup'); loadRuns(); });
  }
  async function loadRuns() {
    const box = $('#runs'); if (!box) return;
    try {
      const runs = await get('/api/poland/runs', { limit: 10 });
      mount(box, runs.length ? html`<table class="tbl"><tbody>${runs.map((r) => html`<tr><td>${r.source_id}<span class="sub">${r.operation}</span></td><td><span class="chip">${r.status}</span></td><td class="right muted small">${fdate(r.started_at)}</td></tr>`)}</tbody></table>`
        : html`<div class="panel-body muted">No runs yet.</div>`);
    } catch (e) { mount(box, errBox(e)); }
  }
  init();
})();
