(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, post, patch, del, guard, ok, toast, money, int, fdate, ago, dueLabel, stageBadge, prio, kind, dims, empty, errBox, opts, demoChip, dialog, confirmDialog, formObj } = App;
  const root = $('#root'); const id = Number(root.dataset.companyId);
  let d, tab = new URLSearchParams(location.search).get('tab') || 'overview';
  const FIELDS = [['website', 'Website'], ['country', 'Country'], ['state', 'State or region'], ['city', 'City'], ['industry', 'Industry'], ['subindustry', 'Sub-industry'], ['employees', 'Employees'], ['estimated_revenue', 'Estimated revenue (USD per year)'],
    ['estimated_scale', 'Scale (fleet, sites)'], ['ownership_type', 'Ownership'], ['accounting_software', 'Accounting software'], ['growth_status', 'Growth status'], ['email', 'General email'], ['phone', 'Phone']];

  async function load() {
    try { d = await get(`/api/companies/${id}`); } catch (e) { mount(root, errBox(e)); return; }
    draw();
  }
  const act = (fn, msg) => guard(async () => { await fn(); if (msg) ok(msg); await load(); });

  function draw() {
    const c = d.company;
    $('#company-title').innerHTML = ''; mount($('#company-title'), html`${c.name}${demoChip(c.is_demo)}`);
    $('#company-sub').textContent = [c.industry, [c.city, c.state, c.country].filter(Boolean).join(', '), c.employees ? `${int(c.employees)} employees` : ''].filter(Boolean).join('. ') || 'Add details to improve fit scoring.';
    mount($('#page-actions'), html`${c.website ? html`<button class="btn btn-primary" id="research">Research website</button>` : ''}<button class="btn" id="build">Build report from recorded data</button><button class="btn" id="requal">Re-qualify</button>
      <a class="btn" href="/api/companies/${id}/export?format=md">Export report</a><button class="btn" id="edit">Edit</button>`);
    const r = $('#research'); if (r) r.addEventListener('click', () => runResearch(true));
    $('#build').addEventListener('click', () => runResearch(false));
    $('#requal').addEventListener('click', () => act(() => post(`/api/companies/${id}/qualify`), 'Leads re-qualified'));
    $('#edit').addEventListener('click', edit);
    const tabs = [['overview', 'Overview'], ['report', 'Research report'], ['signals', `Signals (${d.signals.length})`], ['messages', `Messages (${d.messages.length})`], ['activity', 'Activity']];
    mount(root, html`${d.duplicates.length ? html`<div class="notice">Possible duplicate of <a href="/companies/${d.duplicates[0].company_id}">${d.duplicates[0].name}</a> (${d.duplicates[0].label.toLowerCase()}: ${d.duplicates[0].reasons.join('; ')}). Review it on the <a href="/companies">Companies</a> page.</div>` : ''}
      <div class="tabs" role="tablist">${tabs.map(([k, l]) => html`<button role="tab" data-tab="${k}" aria-selected="${k === tab}">${l}</button>`)}</div><div id="tab"></div>`);
    $$('[data-tab]', root).forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; draw(); }));
    ({ overview, report, signals, messages, activity })[tab]($('#tab'));
  }

  async function runResearch(web) {
    const btns = $$('#page-actions button'); btns.forEach((b) => (b.disabled = true));
    toast(web ? 'Reading the company website. This can take up to a minute.' : 'Building the report…');
    try {
      const rep = await post(`/api/companies/${id}/research?use_web=${web}`);
      const log = rep.research_log || {};
      toast(`Research complete: ${log.signals_added || 0} new signal(s)`, { error: (log.errors || []).length > 0, cause: (log.errors || []).slice(0, 2).join(' '), suggestion: (log.errors || []).length ? 'Details are in the report under Last research run.' : undefined });
      tab = 'report'; await load();
    } catch (e) { App.fail(e); btns.forEach((b) => (b.disabled = false)); }
  }

  function overview(el) {
    const c = d.company; const src = c.field_sources || {};
    mount(el, html`<div class="cols-2"><div>
      <section class="panel"><div class="panel-head"><h2>Leads</h2><button class="btn btn-sm" id="add-lead">Add to a campaign</button></div>
        ${d.leads.length ? html`<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Campaign</th><th>Stage</th><th>Priority</th><th>Five dimensions</th><th>Service</th><th class="num">Potential MRR</th></tr></thead><tbody>${d.leads.map((l) => html`<tr class="clickable" data-lead="${l.id}"><td>${l.campaign ? l.campaign.name : 'No campaign'}</td><td>${stageBadge(l.status)}</td><td>${prio(l.overall_priority)}</td><td>${dims(l.dimensions)}</td><td>${l.recommended_service || html`<span class="faint">No match</span>`}</td><td class="num fig">${l.potential_mrr ? money(l.potential_mrr) : '–'}</td></tr>`)}</tbody></table></div>`
        : empty('Not in any campaign', 'Add this company to a campaign to qualify it against that ideal customer profile.')}</section>
      <section class="panel"><div class="panel-head"><h2>Contacts</h2><button class="btn btn-sm" id="add-person">Add contact</button></div>
        ${d.people.length ? html`<table class="tbl"><tbody>${d.people.map((p) => html`<tr><td><strong>${p.full_name || 'Unnamed'}</strong><span class="sub">${p.title || 'Title unknown'}${p.decision_maker_level && p.decision_maker_level !== 'unknown' ? ', ' + p.decision_maker_level.replace('_', ' ') : ''}</span></td><td>${p.email ? html`<a href="mailto:${p.email}">${p.email}</a>` : html`<span class="attn">No email</span>`}<span class="sub">${p.linkedin_url ? html`<a href="${p.linkedin_url}" target="_blank" rel="noopener noreferrer">LinkedIn</a>` : ''}</span></td><td class="right"><button class="btn btn-sm btn-quiet" data-del-person="${p.id}">Delete</button></td></tr>`)}</tbody></table>`
        : empty('No contacts yet', 'Identify a decision maker before outreach.')}</section></div>
      <section class="panel"><div class="panel-head"><h2>Company facts</h2></div><div class="panel-body"><dl class="kv">
        ${FIELDS.map(([k, l]) => html`<dt>${l}</dt><dd>${c[k] ? (k === 'estimated_revenue' ? money(c[k]) : k === 'website' ? html`<a href="${c[k]}" target="_blank" rel="noopener noreferrer">${c[k]}</a>` : c[k]) : html`<span class="faint">Unknown</span>`}${src[k] ? html`<div class="muted small">from ${src[k].source}${src[k].date ? ', ' + fdate(src[k].date) : ''}</div>` : ''}</dd>`)}
        <dt>Technology</dt><dd>${(c.technology_stack || []).length ? c.technology_stack.join(', ') : html`<span class="faint">Unknown</span>`}</dd>
        <dt>Source</dt><dd>${c.source || 'Unknown'}</dd><dt>Added</dt><dd>${fdate(c.created_at)}</dd></dl>
        ${c.description ? html`<p style="margin-top:12px">${c.description}</p>` : ''}${c.notes ? html`<p class="muted">${c.notes}</p>` : ''}
        <div style="margin-top:14px"><button class="btn btn-danger btn-sm" id="del-co">Delete company</button></div></div></section></div>`);
    $$('[data-lead]', el).forEach((tr) => tr.addEventListener('click', () => Lead.open(Number(tr.dataset.lead), load)));
    $('#add-lead', el).addEventListener('click', addToCampaign); $('#add-person', el).addEventListener('click', addPerson);
    $$('[data-del-person]', el).forEach((b) => b.addEventListener('click', async () => { if (await confirmDialog({ title: 'Delete this contact?', message: 'Leads using this contact will have no contact until you choose another.', confirm: 'Delete contact', danger: true })) act(() => del(`/api/people/${b.dataset.delPerson}`), 'Contact deleted'); }));
    $('#del-co', el).addEventListener('click', async () => { if (await confirmDialog({ title: `Delete ${c.name}?`, message: `This deletes the company with its ${d.leads.length} lead(s), ${d.people.length} contact(s), signals and history. A snapshot is kept in the audit log.`, confirm: 'Delete company', danger: true })) guard(async () => { await del(`/api/companies/${id}`); location.href = '/companies'; }); });
  }
  const report = (el) => mount(el, Report.render(d.report));
  function signals(el) {
    mount(el, html`<div class="row between" style="margin-bottom:12px"><span class="muted">Each signal has quoted evidence and a source.</span><button class="btn btn-primary btn-sm" id="add-sig">Add signal</button></div>
      ${d.signals.length ? d.signals.map((s) => html`<div class="evidence"><div>${kind(s.kind)}<strong>${s.label}</strong></div><q>${s.evidence_text}</q><div class="meta">${s.source}${s.source_url ? html` (<a href="${s.source_url}" target="_blank" rel="noopener noreferrer">open source</a>)` : ''}, detected ${fdate(s.date_detected)}, confidence ${Math.round(s.confidence * 100)}%, ${s.verified ? 'verified against fetched text' : 'not machine-verified'} <button class="btn btn-quiet btn-sm" data-del-sig="${s.id}">Delete</button></div></div>`) : empty('No signals recorded', 'Research the website or add one you found, with its exact wording and source.')}`);
    $('#add-sig', el).addEventListener('click', () => Lead.addSignal(id, load));
    $$('[data-del-sig]', el).forEach((b) => b.addEventListener('click', async () => { if (await confirmDialog({ title: 'Delete this signal?', message: 'Qualification will be recalculated without it.', confirm: 'Delete signal', danger: true })) act(() => del(`/api/signals/${b.dataset.delSig}`), 'Signal deleted'); }));
  }
  function messages(el) {
    mount(el, d.messages.length ? html`<section class="panel"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Status</th><th>Subject</th><th>Channel</th><th>Sent</th></tr></thead><tbody>${d.messages.map((m) => html`<tr class="clickable" data-lead="${m.lead_id}"><td><span class="chip">${m.status}</span></td><td>${m.subject || m.body.slice(0, 70)}</td><td>${m.channel}</td><td>${m.sent_at ? fdate(m.sent_at) : '–'}</td></tr>`)}</tbody></table></div></section>` : html`<section class="panel">${empty('No messages yet', 'Open a lead and draft messages from its evidence.')}</section>`);
    $$('[data-lead]', el).forEach((tr) => tr.addEventListener('click', () => Lead.open(Number(tr.dataset.lead), load)));
  }
  function activity(el) {
    mount(el, html`<div class="cols-eq"><section class="panel"><div class="panel-head"><h2>Interactions</h2></div><div class="panel-body">${d.interactions.length ? html`<ul class="timeline">${d.interactions.map((i) => html`<li><span class="muted small">${fdate(i.occurred_at)}</span><div><strong>${i.type}${i.direction !== 'internal' ? ', ' + i.direction : ''}</strong>${i.subject ? ': ' + i.subject : ''}${i.body ? html`<div class="muted">${i.body}</div>` : ''}</div></li>`)}</ul>` : html`<span class="muted">Nothing logged.</span>`}</div></section>
      <section class="panel"><div class="panel-head"><h2>Tasks</h2></div>${d.tasks.length ? html`<table class="tbl"><tbody>${d.tasks.map((t) => html`<tr><td>${t.title}<span class="sub">${t.status}</span></td><td class="nowrap right">${t.status === 'open' ? dueLabel(t.due_date) : ''}</td></tr>`)}</tbody></table>` : html`<div class="panel-body muted">No tasks.</div>`}</section></div>`);
  }
  async function addToCampaign() {
    const cs = await get('/api/campaigns'); const have = new Set(d.leads.map((l) => l.campaign && l.campaign.id));
    const avail = cs.filter((c) => !have.has(c.id));
    if (!avail.length) { toast('This company is already in every campaign'); return; }
    const r = await dialog({ title: 'Add to a campaign', submit: 'Add lead', onSubmit: (fd) => formObj(fd), body: html`<label class="f"><span>Campaign</span><select name="campaign_id" required>${opts(avail.map((c) => [c.id, c.name]))}</select><div class="hint">The lead is scored against that campaign's ideal customer profile.</div></label>` });
    if (r) act(() => post('/api/leads', { company_id: id, campaign_id: Number(r.campaign_id) }), 'Lead added');
  }
  async function addPerson() {
    const r = await dialog({ title: 'Add contact', submit: 'Add contact', onSubmit: (fd) => formObj(fd), body: html`<div class="form-grid"><label class="f"><span>Full name</span><input name="full_name" required></label><label class="f"><span>Title</span><input name="title"></label><label class="f"><span>Email</span><input name="email" type="email"><div class="hint">Leave empty if unknown; never guess.</div></label><label class="f"><span>LinkedIn URL</span><input name="linkedin_url"></label></div>` });
    if (r) act(() => post(`/api/companies/${id}/people`, Object.fromEntries(Object.entries(r).filter(([, v]) => v))), 'Contact added');
  }
  async function edit() {
    const c = d.company;
    const r = await dialog({ title: 'Edit company', wide: true, submit: 'Save changes', onSubmit: (fd) => formObj(fd), body: html`<div class="form-grid"><label class="f wide"><span>Name</span><input name="name" required value="${c.name}"></label>
      ${FIELDS.map(([k, l]) => html`<label class="f"><span>${l}</span><input name="${k}" value="${c[k] ?? ''}"></label>`)}
      <label class="f wide"><span>Description</span><textarea name="description">${c.description || ''}</textarea></label><label class="f wide"><span>Notes</span><textarea name="notes">${c.notes || ''}</textarea></label></div>` });
    if (!r) return; const body = { ...r }; ['employees', 'estimated_revenue'].forEach((k) => { body[k] = body[k] === '' ? null : Number(body[k]); });
    Object.keys(body).forEach((k) => { if (body[k] === '') body[k] = null; }); if (!body.name) delete body.name;
    act(() => patch(`/api/companies/${id}`, body), 'Company updated');
  }
  load();
})();
