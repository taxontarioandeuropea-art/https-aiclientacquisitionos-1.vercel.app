(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, put, guard, ok, errBox, opts, STAGES, OFFPATH, STAGE_LABEL, formObj } = App;
  const root = $('#root'); let data, tab = new URLSearchParams(location.search).get('tab') || 'user';
  const TABS = [['user', 'Your profile'], ['markets', 'Markets'], ['pricing', 'Pricing'], ['ai', 'AI provider'], ['outreach', 'Outreach'], ['pipeline', 'Pipeline estimates'], ['analytics', 'Analytics']];
  const list = (a) => (a || []).join(', ');
  const nz = (v) => (v === '' || v === null || v === undefined ? null : Number(v));
  async function load() { try { data = await get('/api/settings'); } catch (e) { mount(root, errBox(e)); return; } draw(); }
  function draw() {
    mount(root, html`<div class="tabs" role="tablist">${TABS.map(([k, l]) => html`<button role="tab" data-tab="${k}" aria-selected="${k === tab}">${l}</button>`)}</div><div id="pane" style="max-width:860px"></div>`);
    $$('[data-tab]', root).forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; draw(); }));
    panes[tab]($('#pane'), data.settings[tab === 'analytics' ? 'analytics' : tab]);
  }
  const form = (el, title, intro, fields, submit) => {
    mount(el, html`<section class="panel"><div class="panel-head"><h2>${title}</h2></div><form class="panel-body stack" id="sf">${intro ? html`<p class="muted">${intro}</p>` : ''}${fields}<div><button class="btn btn-primary" type="submit">Save changes</button></div></form></section>`);
    $('#sf', el).addEventListener('submit', (e) => { e.preventDefault(); submit(formObj(new FormData(e.target)), new FormData(e.target)); });
  };
  const save = (section, body) => guard(async () => { data.settings[section] = await put(`/api/settings/${section}`, body); ok('Settings saved'); draw(); });
  const panes = {
    user(el, s) { form(el, 'Your profile', 'Used to sign messages and personalise drafts. A message cannot be approved while it still shows a [Your name] placeholder.', html`<div class="form-grid">
      <label class="f"><span>Name</span><input name="name" value="${s.name}" maxlength="200"></label><label class="f"><span>Company</span><input name="company" value="${s.company}"></label><label class="f"><span>Role</span><input name="role" value="${s.role}"></label>
      <label class="f"><span>Email</span><input name="email" type="email" value="${s.email}"></label><label class="f"><span>Time zone</span><input name="timezone" value="${s.timezone}"></label>
      <label class="f wide"><span>Message signature</span><textarea name="signature">${s.signature}</textarea></label></div>`, (f) => save('user', f)); },
    markets(el, s) { form(el, 'Markets', 'Defaults for the markets you sell into. Each campaign can narrow these.', html`<div class="form-grid">
      <label class="f"><span>Countries</span><input name="countries" value="${list(s.countries)}"></label><label class="f"><span>Regions</span><input name="regions" value="${list(s.regions)}"></label>
      <label class="f"><span>Industries</span><input name="industries" value="${list(s.industries)}"></label><label class="f"><span>Technology</span><input name="technology" value="${list(s.technology)}"></label><label class="f"><span>Ownership types</span><input name="ownership" value="${list(s.ownership)}"></label><span></span>
      <label class="f"><span>Minimum employees</span><input name="size_min" type="number" min="0" value="${s.company_size.min ?? ''}"></label><label class="f"><span>Maximum employees</span><input name="size_max" type="number" min="0" value="${s.company_size.max ?? ''}"></label>
      <label class="f"><span>Minimum revenue (USD per year)</span><input name="rev_min" type="number" min="0" value="${s.revenue.min ?? ''}"></label><label class="f"><span>Maximum revenue (USD per year)</span><input name="rev_max" type="number" min="0" value="${s.revenue.max ?? ''}"></label></div>`,
      (f) => save('markets', { countries: f.countries, regions: f.regions, industries: f.industries, technology: f.technology, ownership: f.ownership, company_size: { min: nz(f.size_min), max: nz(f.size_max) }, revenue: { min: nz(f.rev_min), max: nz(f.rev_max) } })); },
    pricing(el, s) { form(el, 'Pricing', 'The revenue you consider worth pursuing. Campaigns and services can set their own.', html`<div class="form-grid">
      <label class="f"><span>Minimum monthly revenue (USD)</span><input name="minimum_mrr" type="number" min="0" value="${s.minimum_mrr}"></label><label class="f"><span>Target monthly revenue (USD)</span><input name="target_mrr" type="number" min="0" value="${s.target_mrr}"></label>
      <label class="f"><span>Minimum project fee (USD)</span><input name="project_minimum" type="number" min="0" value="${s.project_minimum}"></label><label class="f wide"><span>Project pricing note</span><input name="project_pricing_note" maxlength="500" value="${s.project_pricing_note}"></label></div>`, (f) => save('pricing', f)); },
    ai(el, s) {
      const e = data.env;
      form(el, 'AI provider', 'AI is optional. Without a provider the app still scores, matches services and drafts messages from templates. With one, drafts can be polished, and any output that adds numbers or links not in the source is discarded.', html`
        <div class="notice">API keys are read only from the <code>.env</code> file on this computer. They are never stored in the database or sent to your browser. Keys found now: OpenAI ${e.openai_key_present ? 'yes' : 'no'}, Anthropic ${e.anthropic_key_present ? 'yes' : 'no'}, local model address ${e.local_llm_url_present ? 'yes' : 'no'}.</div>
        <div class="form-grid"><label class="f"><span>Provider</span><select name="provider">${opts([['none', 'None (templates only)'], ['openai', 'OpenAI'], ['anthropic', 'Anthropic'], ['local', 'Local model (OpenAI-compatible)']], s.provider)}</select></label>
        <label class="f"><span>Model name</span><input name="model" value="${s.model}" placeholder="Provider's model id"></label><label class="f"><span>Local model address</span><input name="base_url" value="${s.base_url}" placeholder="http://localhost:11434/v1"></label>
        <label class="f"><span>Creativity (0 to 1)</span><input name="temperature" type="number" min="0" max="1" step="0.05" value="${s.temperature}"></label><label class="f"><span>Maximum reply length (tokens)</span><input name="max_tokens" type="number" min="50" max="4000" value="${s.max_tokens}"></label>
        <label class="f"><span>Research depth</span><select name="research_depth">${opts([['quick', 'Quick (3 pages)'], ['standard', 'Standard (6 pages)'], ['deep', 'Deep (12 pages)']], s.research_depth)}</select></label></div>`, (f) => save('ai', f)); },
    outreach(el, s) { form(el, 'Outreach', 'The follow-up rhythm used when a campaign does not set its own. Follow-ups stop as soon as someone replies.', html`<div class="form-grid">
      <label class="f"><span>Follow-up days after the first message</span><input name="followup_intervals" value="${list(s.followup_intervals)}" placeholder="3, 7, 14"></label><label class="f"><span>Maximum follow-ups</span><input name="max_followups" type="number" min="0" max="10" value="${s.max_followups}"></label>
      <label class="f"><span>Days to wait before revisiting a nurture lead</span><input name="nurture_wait_days" type="number" min="1" max="90" value="${s.nurture_wait_days}"></label></div>
      <fieldset style="border:1px solid var(--rule-soft);border-radius:var(--r-panel);padding:10px 14px"><legend class="muted small" style="padding:0 6px">Channels to draft for</legend><div class="row">${data.channels.map((c) => html`<label class="check"><input type="checkbox" name="ch" value="${c}" ${s.default_channels.includes(c) ? raw('checked') : ''}><span>${c.replace('_', ' ')}</span></label>`)}</div></fieldset>`,
      (f, fd) => save('outreach', { followup_intervals: f.followup_intervals, max_followups: f.max_followups, nurture_wait_days: f.nurture_wait_days, default_channels: fd.getAll('ch') })); },
    pipeline(el, s) { form(el, 'Pipeline estimates', 'Your own assumption of how likely a lead at each stage is to become a client. These weight the pipeline value on the dashboard. They are estimates you set, not predictions made by the app.', html`<div class="form-grid">
      ${[...STAGES, ...OFFPATH].map((k) => html`<label class="f"><span>${STAGE_LABEL[k]} (percent)</span><input name="${k}" type="number" min="0" max="100" step="1" value="${Math.round((s.stage_estimates[k] ?? 0) * 100)}"></label>`)}</div>`,
      (f) => save('pipeline', { stage_estimates: Object.fromEntries(Object.entries(f).map(([k, v]) => [k, Number(v) / 100])) })); },
    analytics(el, s) { const h = data.settings.heuristics; form(el, 'Analytics', 'How much evidence is needed before a pattern is shown as meaningful, and the assumptions used to estimate a company\'s finance budget when revenue is unknown.', html`<div class="form-grid">
      <label class="f"><span>Minimum contacted leads per comparison</span><input name="min_sample_size" type="number" min="5" max="1000" value="${s.min_sample_size}"><div class="hint">Comparisons with fewer are marked "too few to judge".</div></label>
      <label class="f"><span>Revenue per employee (USD per year)</span><input name="revenue_per_employee" type="number" min="1000" value="${h.revenue_per_employee}"><div class="hint">Used only when revenue is missing; the result is labelled an inference.</div></label>
      <label class="f"><span>Finance spend as a percent of revenue</span><input name="finance_spend_pct" type="number" min="0.1" max="5" step="0.1" value="${+(h.finance_spend_pct * 100).toFixed(2)}"></label></div>`,
      (f) => guard(async () => { await put('/api/settings/analytics', { min_sample_size: f.min_sample_size }); await put('/api/settings/heuristics', { revenue_per_employee: f.revenue_per_employee, finance_spend_pct: Number(f.finance_spend_pct) / 100 }); ok('Settings saved'); await load(); })); },
  };
  load();
})();
