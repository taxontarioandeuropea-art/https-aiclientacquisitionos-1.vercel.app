(function () {
  'use strict';
  const { html, $, $$, mount, get, post, del, guard, ok, money, int, fdate, prio, empty, errBox, opts, debounce, demoChip, bindSort, th, dialog, confirmDialog, formObj, toast } = App;
  const root = $('#root');
  const state = { sort: 'name', dir: 'asc', q: '', country: '', industry: '' };

  async function init() {
    mount($('#page-actions'), html`<button class="btn btn-primary" id="add-co">Add company</button><a class="btn" href="/data">Import companies</a>`);
    $('#add-co').addEventListener('click', addCompany);
    mount(root, html`<div id="dups"></div>
      <form class="filters" id="f" role="search"><label class="f"><span>Search</span><input name="q" placeholder="Name, website, city or industry"></label>
        <label class="f"><span>Country</span><select name="country">${opts(['USA', 'Poland'], '', 'Any country')}</select></label><label class="f"><span>Industry</span><input name="industry"></label></form>
      <section class="panel"><div class="tbl-wrap"><table class="tbl" id="tbl"><thead><tr>${th('name', 'Company')}${th('country', 'Location')}${th('industry', 'Industry')}${th('employees', 'Employees', 'desc', 'num')}<th class="num">Signals</th><th class="num">Leads</th><th>Best priority</th><th>Research</th></tr></thead><tbody id="rows"></tbody></table></div><div class="panel-body muted" id="foot"></div></section>`);
    const onF = debounce(() => { $$('#f [name]').forEach((e) => { state[e.name] = e.value; }); refresh(); }, 220);
    $('#f').addEventListener('input', onF); $('#f').addEventListener('submit', (e) => e.preventDefault());
    bindSort($('#tbl'), state, refresh); refresh(); dups();
  }
  async function refresh() {
    let d; try { d = await get('/api/companies', { q: state.q, country: state.country, industry: state.industry, sort: state.sort, dir: state.dir, limit: 500 }); } catch (e) { mount($('#rows'), html`<tr><td colspan="8">${errBox(e)}</td></tr>`); return; }
    mount($('#rows'), d.items.length ? d.items.map((c) => html`<tr class="clickable" data-id="${c.id}" tabindex="0"><td><strong>${c.name}</strong>${demoChip(c.is_demo)}<span class="sub">${c.website || 'No website'}</span></td>
      <td>${[c.city, c.state, c.country].filter(Boolean).join(', ') || html`<span class="faint">Unknown</span>`}</td><td>${c.industry || html`<span class="faint">Unknown</span>`}</td><td class="num">${int(c.employees)}</td>
      <td class="num">${c.signals}</td><td class="num">${c.leads}</td><td>${c.best_priority ? prio(c.best_priority) : html`<span class="faint">None</span>`}</td><td class="nowrap">${c.last_researched_at ? 'Researched ' + fdate(c.last_researched_at) : html`<span class="faint">Not researched</span>`}</td></tr>`)
      : html`<tr><td colspan="8">${empty('No companies found', 'Add a company or import a list.')}</td></tr>`);
    $$('#rows tr[data-id]').forEach((tr) => { const go = () => (location.href = `/companies/${tr.dataset.id}`); tr.addEventListener('click', go); tr.addEventListener('keydown', (e) => e.key === 'Enter' && go()); });
    $('#foot').textContent = `${d.items.length} of ${d.total} companies`;
  }
  async function addCompany() {
    const r = await dialog({ title: 'Add a company', submit: 'Add company', onSubmit: (fd) => formObj(fd), body: html`<div class="form-grid"><label class="f"><span>Name</span><input name="name" required></label><label class="f"><span>Website</span><input name="website"></label>
      <label class="f"><span>Country</span><input name="country" list="cs"><datalist id="cs"><option>USA</option><option>Poland</option></datalist></label><label class="f"><span>City</span><input name="city"></label><label class="f"><span>Industry</span><input name="industry"></label><label class="f"><span>Employees</span><input name="employees" type="number" min="0"></label></div>` });
    if (!r) return;
    const body = Object.fromEntries(Object.entries(r).filter(([, v]) => v)); if (body.employees) body.employees = Number(body.employees);
    guard(async () => { const res = await post('/api/companies', body); const d = res.possible_duplicates[0]; d ? toast(`Added. Possible duplicate: ${d.name}`, { cause: d.reasons.join('; '), suggestion: 'Review it in the duplicates panel.' }) : ok('Company added'); refresh(); dups(); });
  }
  async function dups() {
    let d; try { d = await get('/api/duplicates'); } catch { return; }
    const box = $('#dups'); const n = d.companies.length + d.people.length;
    if (!n) { mount(box, ''); return; }
    mount(box, html`<section class="panel" style="margin-bottom:18px"><div class="panel-head"><h2>Possible duplicates (${n})</h2><span class="muted small">Nothing merges unless you confirm it</span></div>
      <div class="tbl-wrap"><table class="tbl"><tbody>${d.companies.map((x, i) => html`<tr><td style="width:36%"><strong>${x.a.name}</strong><span class="sub">${x.a.city || ''} ${x.a.country || ''}, ${x.a.leads} leads, ${x.a.contacts} contacts</span></td>
        <td style="width:36%"><strong>${x.b.name}</strong><span class="sub">${x.b.city || ''} ${x.b.country || ''}, ${x.b.leads} leads, ${x.b.contacts} contacts</span></td>
        <td><span class="chip">${x.label} (${Math.round(x.score * 100)}%)</span><div class="muted small">${x.reasons.join('; ')}</div></td>
        <td class="nowrap"><button class="btn btn-sm" data-merge="${i}">Review merge</button> <button class="btn btn-sm btn-quiet" data-dismiss="${i}">Not a duplicate</button></td></tr>`)}
        ${d.people.map((x) => html`<tr><td><strong>${x.a.full_name}</strong><span class="sub">${x.a.email || ''}</span></td><td><strong>${x.b.full_name}</strong><span class="sub">${x.b.email || ''}</span></td><td><span class="chip">Contact: ${x.reason}</span></td><td><button class="btn btn-sm" data-pmerge="${x.a.id}:${x.b.id}">Merge contacts</button></td></tr>`)}</tbody></table></div></section>`);
    $$('[data-dismiss]', box).forEach((b) => b.addEventListener('click', () => { const x = d.companies[b.dataset.dismiss]; guard(async () => { await post('/api/duplicates/dismiss', { id_a: x.a.id, id_b: x.b.id }); ok('Marked as not a duplicate'); dups(); }); }));
    $$('[data-pmerge]', box).forEach((b) => b.addEventListener('click', async () => { const [a, c] = b.dataset.pmerge.split(':').map(Number); if (await confirmDialog({ title: 'Merge these contacts?', message: 'The second contact is merged into the first. Empty fields on the first are filled from the second.', confirm: 'Merge contacts' })) guard(async () => { await post('/api/duplicates/merge-people', { primary_id: a, secondary_id: c }); ok('Contacts merged'); dups(); }); }));
    $$('[data-merge]', box).forEach((b) => b.addEventListener('click', () => reviewMerge(d.companies[b.dataset.merge])));
  }
  async function reviewMerge(x) {
    const r = await dialog({ title: 'Review merge', wide: true, submit: 'Merge companies', onSubmit: (fd) => formObj(fd), body: html`<div class="stack">
      <p>Choose the record to keep. The other is archived (not deleted); its contacts, leads, signals, tasks and interactions move to the record you keep. Every change is written to the audit log.</p>
      ${[x.a, x.b].map((s, i) => html`<label class="panel" style="display:block;padding:12px 14px"><span class="check"><input type="radio" name="primary" value="${s.id}" ${(x.a.leads >= x.b.leads ? i === 0 : i === 1) ? App.raw('checked') : ''}><span><strong>Keep ${s.name}</strong></span></span><div class="muted small" style="margin-left:26px">${[s.website, s.city, s.country].filter(Boolean).join(', ') || 'No details'}; ${s.leads} leads, ${s.contacts} contacts, ${s.signals} signals; source: ${s.source || 'unknown'}</div></label>`)}
      <div class="muted small">Why flagged: ${x.reasons.join('; ')}</div></div>` });
    if (!r) return; const p = Number(r.primary), s = p === x.a.id ? x.b.id : x.a.id;
    guard(async () => { const res = await post('/api/duplicates/merge', { primary_id: p, secondary_id: s }); ok(`Merged. Moved ${res.moved.leads + res.moved.merged_leads} lead(s), ${res.moved.contacts} contact(s).`); refresh(); dups(); });
  }
  init();
})();
