(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, money, int, pct, empty, errBox, opts, loading } = App;
  const root = $('#root'); const st = { tab: 'funnel', campaign_id: '', by: 'campaign', group: new Set(['campaign', 'signal', 'offer']) };
  const BY = [['campaign', 'Campaign'], ['industry', 'Industry'], ['country', 'Country'], ['service', 'Service'], ['signal', 'Signal'], ['template', 'Message template']];
  const DIMS = [['campaign', 'Campaign'], ['industry', 'Industry'], ['country', 'Country'], ['signal', 'Signal'], ['offer', 'Offer'], ['template', 'Message template'], ['channel', 'Channel']];
  const SAMPLE = { insufficient: ['Too few to judge', 'neg'], directional: ['Directional only', 'attn'], reasonable: ['Reasonable sample', 'pos'] };
  let campaigns = [];
  async function init() {
    campaigns = await get('/api/campaigns').catch(() => []);
    mount($('#page-actions'), html`<a class="btn" href="/api/export/sales_reports?format=xlsx">Export sales report</a>`);
    mount(root, html`<div class="row between" style="margin-bottom:6px"><div class="tabs" style="flex:1;margin:0" role="tablist">${[['funnel', 'Funnel'], ['mrr', 'MRR breakdown'], ['experiments', 'Experiments'], ['feedback', 'Feedback']].map(([k, l]) => html`<button role="tab" data-tab="${k}" aria-selected="${k === st.tab}">${l}</button>`)}</div>
      <label class="f" style="min-width:230px"><span>Campaign</span><select id="camp">${opts(campaigns.map((c) => [c.id, c.name]), st.campaign_id, 'All campaigns')}</select></label></div><div id="view" style="margin-top:16px"></div>`);
    $$('[data-tab]', root).forEach((b) => b.addEventListener('click', () => { st.tab = b.dataset.tab; $$('[data-tab]', root).forEach((x) => x.setAttribute('aria-selected', x === b)); draw(); }));
    $('#camp').addEventListener('change', (e) => { st.campaign_id = e.target.value; draw(); }); draw();
  }
  async function draw() { const v = $('#view'); mount(v, loading()); try { await ({ funnel, mrr, experiments, feedback })[st.tab](v); } catch (e) { mount(v, errBox(e)); } }
  async function funnel(v) {
    const d = await get('/api/analytics/funnel', { campaign_id: st.campaign_id });
    mount(v, html`<section class="statement"><div><div class="k">MRR from won clients</div><div class="v money">${money(d.mrr)}</div></div><div><div class="k">Won clients</div><div class="v">${d.counts.won}</div></div><div><div class="k">Average MRR per client</div><div class="v">${d.avg_mrr ? money(d.avg_mrr) : '–'}</div></div>
      <div><div class="k">Pipeline (potential)</div><div class="v">${money(d.pipeline_value)}</div></div><div><div class="k">Weighted pipeline</div><div class="v">${money(d.weighted_pipeline)}</div><div class="n">by your stage estimates</div></div></section>
      <div class="cols-eq"><section class="panel"><div class="panel-head"><h2>Where leads go</h2></div><div class="panel-body">${d.stages.map((s) => html`<div class="bar-row" style="grid-template-columns:130px 1fr 60px 64px"><span>${s.label}</span><div class="bar ${s.key === 'won' ? 'won' : ''}"><i style="width:${Math.max(s.pct_of_leads || 0, s.count ? 2 : 0)}%"></i></div><span class="num">${int(s.count)}</span><span class="num muted small" title="Share of the previous stage">${s.pct_of_previous !== null ? pct(s.pct_of_previous) : ''}</span></div>`)}
        <p class="muted small" style="margin-top:8px">A lead counts at every stage it reached, even if it was later lost. The right column is the share of the previous stage.</p></div></section>
      <section class="panel"><div class="panel-head"><h2>Conversion rates</h2></div><table class="tbl"><thead><tr><th>Rate</th><th class="num">Value</th><th class="num">Based on</th></tr></thead><tbody>${Object.entries(d.rates).map(([k, r]) => html`<tr><td>${k.replace(/_/g, ' ').replace(/^./, (m) => m.toUpperCase())}<span class="sub">${r.definition}</span></td><td class="num fig">${pct(r.value)}</td><td class="num muted">${r.n} of ${r.d}</td></tr>`)}</tbody></table>
        <div class="panel-body muted small">${d.estimate_note}</div></section></div>`);
  }
  async function mrr(v) {
    const rows = await get('/api/analytics/mrr', { by: st.by, campaign_id: st.campaign_id });
    mount(v, html`<div class="row" style="margin-bottom:12px"><label class="f" style="min-width:230px"><span>Break down by</span><select id="by">${opts(BY, st.by)}</select></label></div>
      <section class="panel">${rows.length ? html`<div class="tbl-wrap"><table class="tbl"><thead><tr><th>${BY.find(([k]) => k === st.by)[1]}</th><th class="num">Leads</th><th class="num">Contacted</th><th class="num">Won</th><th class="num">MRR won</th><th class="num">Pipeline MRR</th><th class="num">Average MRR</th></tr></thead><tbody>
        ${rows.map((r) => html`<tr><td>${r.key}</td><td class="num">${r.leads}</td><td class="num">${r.contacted}</td><td class="num">${r.won}</td><td class="num fig">${money(r.mrr)}</td><td class="num fig">${money(r.pipeline_mrr)}</td><td class="num fig">${r.avg_mrr ? money(r.avg_mrr) : '–'}</td></tr>`)}</tbody>
        <tfoot><tr><td>Total</td><td class="num">${rows.reduce((a, r) => a + r.leads, 0)}</td><td class="num">${rows.reduce((a, r) => a + r.contacted, 0)}</td><td class="num">${rows.reduce((a, r) => a + r.won, 0)}</td><td class="num fig">${money(rows.reduce((a, r) => a + r.mrr, 0))}</td><td class="num fig">${money(rows.reduce((a, r) => a + r.pipeline_mrr, 0))}</td><td></td></tr></tfoot></table></div>` : empty('No data yet', 'Add leads to see MRR by this breakdown.')}</section>
      ${st.by === 'template' ? html`<p class="muted small">Only leads with a recorded first message appear under message templates.</p>` : ''}`);
    $('#by').addEventListener('change', (e) => { st.by = e.target.value; draw(); });
  }
  async function experiments(v) {
    const d = await get('/api/analytics/experiments', { group_by: [...st.group].join(','), campaign_id: st.campaign_id });
    mount(v, html`<div class="notice">${d.caveat}</div>
      <fieldset style="border:1px solid var(--rule-soft);border-radius:var(--r-panel);padding:10px 14px;margin-bottom:14px"><legend class="muted small" style="padding:0 6px">Compare by</legend><div class="row">${DIMS.map(([k, l]) => html`<label class="check"><input type="checkbox" data-g="${k}" ${st.group.has(k) ? raw('checked') : ''}><span>${l}</span></label>`)}</div></fieldset>
      <section class="panel">${d.rows.length ? html`<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Combination</th><th class="num" title="Leads that were contacted">Contacted (n)</th><th class="num">Replies</th><th class="num">Reply rate (95% range)</th><th class="num">Meetings</th><th class="num">Won</th><th class="num">MRR</th><th>Sample</th><th>Reading</th></tr></thead><tbody>
        ${d.rows.map((r) => html`<tr><td>${r.label}</td><td class="num">${r.n}</td><td class="num">${r.replies}</td><td class="num">${pct(r.reply_rate)}<span class="sub">${r.reply_ci[0]}% to ${r.reply_ci[1]}%</span></td><td class="num">${r.meetings}</td><td class="num">${r.won}</td><td class="num fig">${money(r.mrr)}</td><td class="${SAMPLE[r.sample][1]}">${SAMPLE[r.sample][0]}</td><td class="muted" style="min-width:220px">${r.verdict}</td></tr>`)}</tbody>
        <tfoot><tr><td>All contacted leads</td><td class="num">${d.baseline.n}</td><td class="num">${d.baseline.replies}</td><td class="num">${pct(d.baseline.reply_rate)}<span class="sub" style="font-weight:400">${d.baseline.reply_ci[0]}% to ${d.baseline.reply_ci[1]}%</span></td><td class="num">${d.baseline.meetings}</td><td class="num">${d.baseline.won}</td><td class="num fig">${money(d.baseline.mrr)}</td><td colspan="2" class="muted small" style="font-weight:400">Minimum sample: ${d.min_sample} (Settings)</td></tr></tfoot></table></div>` : empty('No contacted leads yet', 'Experiments compare leads you have contacted. Record sent messages to see patterns.')}</section>`);
    $$('[data-g]', v).forEach((c) => c.addEventListener('change', () => { c.checked ? st.group.add(c.dataset.g) : st.group.delete(c.dataset.g); if (!st.group.size) st.group.add('campaign'); draw(); }));
  }
  async function feedback(v) {
    const [sources, industries, signals, disq] = await Promise.all([
      get('/api/feedback/sources', { campaign_id: st.campaign_id }), get('/api/feedback/industries', { campaign_id: st.campaign_id }),
      get('/api/feedback/signals', { campaign_id: st.campaign_id }), get('/api/feedback/disqualifications', { campaign_id: st.campaign_id })]);
    const table = (title, hint, rows, keyLabel) => html`<section class="panel" style="margin-bottom:16px"><div class="panel-head"><h2>${title}</h2><span class="muted small">${hint}</span></div>
      ${rows.length ? html`<div class="tbl-wrap"><table class="tbl"><thead><tr><th>${keyLabel}</th><th class="num">Leads</th><th class="num">Qualified</th><th class="num">Qualified rate</th><th class="num">Won</th><th class="num">Won rate</th><th class="num">Disqualified</th><th class="num">Avg opportunity score</th></tr></thead><tbody>
        ${rows.map((r) => html`<tr><td>${r.key}</td><td class="num">${int(r.leads)}</td><td class="num">${int(r.qualified)}</td><td class="num">${pct(r.qualified_rate)}</td><td class="num">${int(r.won)}</td><td class="num">${pct(r.won_rate)}</td><td class="num">${int(r.disqualified)}</td><td class="num fig">${r.avg_opportunity_score ?? '–'}</td></tr>`)}
      </tbody></table></div>` : empty('No data yet', 'This fills in as you qualify leads.')}</section>`;
    mount(v, html`<div class="notice">Explainable grouped counts and rates over leads you've actually qualified — never a trained or black-box model, per master prompt §27. Use this to see which sources, industries and signals are actually worth pursuing more of.</div>
      ${table('Source quality', 'Which lead sources produce leads worth pursuing', sources, 'Source')}
      ${table('Industry quality', 'Which industries convert best for your services', industries, 'Industry')}
      ${table('Signal quality', "Of leads whose strongest evidence was this signal, how many turned out to qualify or win — tests whether a signal's assumed importance actually holds for your business", signals, 'Signal')}
      <section class="panel"><div class="panel-head"><h2>Why leads get disqualified</h2><span class="muted small">Reasons recorded when marking a lead "Not a fit"</span></div>
        ${disq.length ? html`<table class="tbl"><tbody>${disq.map((r) => html`<tr><td>${r.label}</td><td class="num">${int(r.count)}</td><td class="num">${pct(r.pct)}</td></tr>`)}</tbody></table>`
        : empty('Nothing disqualified yet', 'Reasons appear here once you mark leads "Not a fit" with a reason.')}</section>`);
  }
  init();
})();
