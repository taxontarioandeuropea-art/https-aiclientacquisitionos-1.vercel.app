(function () {
  'use strict';
  const { html, raw, $, $$, mount, get, post, guard, ok, money, fdate, dueLabel, prio, dims, empty, errBox, opts, debounce, demoChip, dialog, formObj, STAGE_LABEL } = App;
  const root = $('#root'); const state = { campaign_id: '', country: '', q: '' }; let showOff = false, dragging = null;

  async function init() {
    const campaigns = await get('/api/campaigns').catch(() => []);
    mount(root, html`<form class="filters" id="f"><label class="f"><span>Search</span><input name="q" placeholder="Company"></label><label class="f"><span>Campaign</span><select name="campaign_id">${opts(campaigns.map((c) => [c.id, c.name]), '', 'All campaigns')}</select></label>
      <label class="f"><span>Country</span><select name="country">${opts(['USA', 'Poland'], '', 'Any country')}</select></label><label class="check" style="padding-bottom:8px"><input type="checkbox" id="off"><span>Show lost, nurture and not a fit</span></label></form>
      <p class="muted small" id="note"></p><div class="board" id="board" aria-label="Pipeline board"></div>`);
    const onF = debounce(() => { $$('#f [name]').forEach((e) => { state[e.name] = e.value; }); refresh(); }, 220);
    $('#f').addEventListener('input', onF); $('#f').addEventListener('submit', (e) => e.preventDefault());
    $('#off').addEventListener('change', (e) => { showOff = e.target.checked; refresh(); });
    refresh();
  }
  async function refresh() {
    let d; try { d = await get('/api/pipeline', state); } catch (e) { mount($('#board'), errBox(e)); return; }
    $('#note').textContent = d.note || '';
    const lanes = [...d.stages, ...(showOff ? d.offpath : [])];
    mount($('#board'), lanes.map((s) => html`<section class="lane" data-stage="${s.stage}" aria-label="${s.label}"><div class="lane-head"><div class="t"><span>${s.label}</span><span class="fig">${s.count}</span></div>
      <div class="s">${s.stage === 'WON' ? money(s.total_mrr) + ' won' : s.total_mrr ? money(s.total_mrr) + ' potential' : 'No value yet'}${s.weighted_mrr ? html`<br>${money(s.weighted_mrr)} at your ${Math.round(s.estimate_pct * 100)}% estimate` : ''}</div></div>
      <div class="lane-body">${s.leads.map((l) => html`<article class="kcard" draggable="true" data-id="${l.id}" data-stage="${l.status}" tabindex="0"><div class="n">${l.company}${demoChip(l.is_demo)}</div>
        <div class="m">${l.contact ? l.contact : 'No contact'}${l.service ? ' for ' + l.service : ''}</div><div class="row between" style="margin-top:6px">${prio(l.priority)}<span class="fig">${l.potential_mrr || l.actual_mrr ? money(s.stage === 'WON' ? l.actual_mrr : l.potential_mrr) : ''}</span></div>
        ${l.next_action_date ? html`<div class="m">${dueLabel(l.next_action_date)}</div>` : ''}</article>`)}${s.leads.length ? '' : html`<div class="muted small" style="padding:6px">Empty</div>`}</div></section>`));
    $$('.kcard').forEach((c) => {
      c.addEventListener('click', () => Lead.open(Number(c.dataset.id), refresh)); c.addEventListener('keydown', (e) => e.key === 'Enter' && Lead.open(Number(c.dataset.id), refresh));
      c.addEventListener('dragstart', (e) => { dragging = c; c.classList.add('dragging'); e.dataTransfer.setData('text/plain', c.dataset.id); e.dataTransfer.effectAllowed = 'move'; });
      c.addEventListener('dragend', () => { c.classList.remove('dragging'); $$('.lane').forEach((l) => l.classList.remove('over')); });
    });
    $$('.lane').forEach((l) => {
      l.addEventListener('dragover', (e) => { e.preventDefault(); l.classList.add('over'); }); l.addEventListener('dragleave', () => l.classList.remove('over'));
      l.addEventListener('drop', (e) => { e.preventDefault(); l.classList.remove('over'); if (dragging && dragging.dataset.stage !== l.dataset.stage) move(Number(dragging.dataset.id), l.dataset.stage); });
    });
  }
  async function move(id, to) {
    const payload = { stage: to };
    if (to === 'WON') { const r = await dialog({ title: 'Mark as won', submit: 'Mark as won', onSubmit: (fd) => formObj(fd), body: html`<label class="f"><span>Actual monthly recurring revenue (USD)</span><input name="actual_mrr" type="number" min="0" step="50" required><div class="hint">The agreed monthly fee. Only you can close an opportunity.</div></label>` }); if (!r) return; payload.actual_mrr = Number(r.actual_mrr); }
    else if (to === 'LOST') { const r = await dialog({ title: 'Mark as lost', submit: 'Mark as lost', danger: true, onSubmit: (fd) => formObj(fd), body: html`<label class="f"><span>Why was it lost?</span><input name="lost_reason" required maxlength="255"></label>` }); if (!r) return; payload.lost_reason = r.lost_reason; }
    else if (to === 'NOT_A_FIT') { const r = await dialog({ title: 'Mark as not a fit', submit: 'Mark as not a fit', danger: true, onSubmit: (fd) => formObj(fd), body: html`<label class="f"><span>Why isn't it a fit?</span><select name="disqualify_reason" required>${App.opts(App.DISQUALIFY_REASONS, '', 'Choose a reason')}</select></label>` }); if (!r) return; payload.disqualify_reason = r.disqualify_reason; }
    guard(async () => { await post(`/api/leads/${id}/stage`, payload); ok(`Moved to ${STAGE_LABEL[to]}`); refresh(); }).then(refresh);
  }
  init();
})();
