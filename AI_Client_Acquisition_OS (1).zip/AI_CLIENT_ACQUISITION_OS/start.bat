@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title AI Client Acquisition OS

echo ============================================
echo   AI Client Acquisition OS
echo ============================================
echo.

rem --- Find a real Python interpreter -------------------------------------
rem The "py" launcher (installed by python.org) is the most reliable way to
rem find a real Python on Windows, since a bare "python" can resolve to the
rem Microsoft Store stub instead. Fall back to "python" / "python3" if "py"
rem isn't present.
set "PYLAUNCH="
where py >nul 2>nul
if %errorlevel%==0 set "PYLAUNCH=py -3"
if not defined PYLAUNCH (
    where python >nul 2>nul
    if %errorlevel%==0 set "PYLAUNCH=python"
)
if not defined PYLAUNCH (
    where python3 >nul 2>nul
    if %errorlevel%==0 set "PYLAUNCH=python3"
)
if not defined PYLAUNCH (
    echo Could not find Python on this computer.
    echo Install it from https://python.org/downloads ^(check "Add python.exe to PATH"
    echo during setup^), then double-click this file again.
    pause
    exit /b 1
)

rem --- Create an isolated environment the first time -----------------------
rem Everything installs into .venv, inside this folder, so it never touches
rem or conflicts with any other Python project or install on this computer.
if not exist ".venv\Scripts\python.exe" (
    echo Setting up the app for the first time - this can take a minute...
    %PYLAUNCH% -m venv .venv
    if errorlevel 1 (
        echo.
        echo Could not create the virtual environment ^(see the error above^).
        pause
        exit /b 1
    )
)

set "VENV_PY=.venv\Scripts\python.exe"

echo Checking dependencies...
"%VENV_PY%" -m pip install --quiet --upgrade pip
"%VENV_PY%" -m pip install --quiet -r requirements.txt
if errorlevel 1 (
    echo.
    echo Installing dependencies failed ^(see the error above^).
    echo If you're offline, connect to the internet and try again.
    pause
    exit /b 1
)

rem --- Open the browser automatically a couple of seconds after start ------
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:8000"

echo.
echo Starting the app - this window is the server. Close it, or press Ctrl+C, to stop.
echo.
"%VENV_PY%" app.py

echo.
echo The server has stopped.
pause
