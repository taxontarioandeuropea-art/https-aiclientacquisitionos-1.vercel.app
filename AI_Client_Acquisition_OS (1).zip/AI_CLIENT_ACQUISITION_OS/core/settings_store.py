"""Persistent user settings (key/value JSON). Secrets are NOT stored here — see .env."""
from __future__ import annotations

import copy
from typing import Any, Optional

from sqlalchemy.orm import Session

from core.constants import DEFAULT_STAGE_ESTIMATES
from database.models import Setting

DEFAULT_SETTINGS: dict[str, dict[str, Any]] = {
    "user": {"name": "", "company": "", "role": "", "email": "", "signature": "", "timezone": "UTC"},
    "markets": {
        "countries": ["USA", "Poland"], "regions": [], "industries": [],
        "company_size": {"min": 5, "max": 200}, "revenue": {"min": None, "max": None},
        "technology": [], "ownership": [],
    },
    "pricing": {"minimum_mrr": 700, "target_mrr": 1000, "project_minimum": 1500,
                "project_pricing_note": "Fixed-fee, scoped after a short review of the books."},
    "ai": {"provider": "none", "model": "", "temperature": 0.4, "research_depth": "standard",
           "base_url": "", "max_tokens": 700},
    "outreach": {"followup_intervals": [3, 7, 14], "max_followups": 3, "default_channels": ["email"],
                 "nurture_wait_days": 7},
    "pipeline": {"stage_estimates": DEFAULT_STAGE_ESTIMATES},
    "analytics": {"min_sample_size": 30},
    "heuristics": {"revenue_per_employee": 150000, "finance_spend_pct": 0.007},
}

RESEARCH_DEPTH_PAGES = {"quick": 3, "standard": 6, "deep": 12}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def get_settings(db: Session, section: Optional[str] = None) -> dict[str, Any]:
    stored = {row.key: row.value for row in db.query(Setting).all()}
    merged = {k: _merge(v, stored.get(k) or {}) for k, v in DEFAULT_SETTINGS.items()}
    return merged[section] if section else merged


def save_section(db: Session, section: str, values: dict[str, Any]) -> dict[str, Any]:
    if section not in DEFAULT_SETTINGS:
        raise KeyError(section)
    current = get_settings(db, section)
    new = _merge(current, values)
    row = db.get(Setting, section)
    if row is None:
        db.add(Setting(key=section, value=new))
    else:
        row.value = new
    db.flush()
    return new
