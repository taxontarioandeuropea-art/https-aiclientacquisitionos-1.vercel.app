"""Audit trail. Callers own the transaction (this only adds the row)."""
from __future__ import annotations

from typing import Any, Optional

from sqlalchemy.orm import Session

from database.models import AuditLog


def log(db: Session, action: str, summary: str, *, entity_type: Optional[str] = None,
        entity_id: Optional[int] = None, details: Optional[dict[str, Any]] = None,
        actor: str = "user") -> AuditLog:
    entry = AuditLog(action=action, summary=summary[:500], entity_type=entity_type, entity_id=entity_id,
                     details=details, actor=actor)
    db.add(entry)
    return entry
