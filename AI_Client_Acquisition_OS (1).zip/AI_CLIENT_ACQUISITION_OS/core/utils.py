"""Pure helper functions (no database access)."""
from __future__ import annotations

import math
import re
from datetime import date, datetime, timezone
from difflib import SequenceMatcher
from typing import Any, Iterable, Optional
from urllib.parse import urlparse

from core.constants import COUNTRY_ALIASES


def utcnow() -> datetime:
    """Naive UTC timestamp (SQLite friendly, PostgreSQL compatible)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def today() -> date:
    return date.today()


# ---------------------------------------------------------------- sanitising
_TAG_RE = re.compile(r"<!--.*?-->|</?[a-zA-Z][^>]*>", re.S)
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def sanitize_text(value: Any, max_len: Optional[int] = None) -> Optional[str]:
    """Strip control characters and HTML tags. Output is additionally escaped at render time."""
    if value is None:
        return None
    if not isinstance(value, str):
        value = str(value)
    value = _CTRL_RE.sub("", value)
    value = _TAG_RE.sub("", value).strip()
    if max_len:
        value = value[:max_len]
    return value


def sanitize_url(value: Any) -> Optional[str]:
    v = sanitize_text(value, 500)
    if not v:
        return None
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", v):
        v = "https://" + v
    parsed = urlparse(v)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return None
    return v


# ------------------------------------------------------------- normalisation
_LEGAL_TOKENS = {
    "llc", "inc", "incorporated", "corp", "corporation", "co", "company", "ltd", "limited",
    "lp", "llp", "plc", "gmbh", "sa", "ag", "bv", "nv", "srl", "spa", "pllc", "lc", "pc", "the",
}
_PL_SPZOO = re.compile(r"\bsp\.?\s*z\s*o\.?\s*o\.?\b|\bspółka\b|\bspolka\b|\bsp\.?\s*k\.?\b|\bs\.?a\.?\b", re.I)


def normalize_company_name(name: Optional[str]) -> str:
    """'ABC Logistics LLC', 'ABC Logistics' and 'A.B.C. Logistics, Inc.' -> 'abc logistics'."""
    if not name:
        return ""
    n = name.lower().replace("&", " and ")
    n = _PL_SPZOO.sub(" ", n)
    n = re.sub(r"[^\w\s]", "", n, flags=re.U)          # A.B.C. -> abc
    tokens = [t for t in n.split() if t]
    while tokens and tokens[-1] in _LEGAL_TOKENS:
        tokens.pop()
    while tokens and tokens[0] == "the":
        tokens.pop(0)
    return " ".join(tokens)


def normalize_domain(url: Optional[str]) -> str:
    if not url:
        return ""
    u = url.strip().lower()
    if "@" in u and "://" not in u:          # an email address, not a URL
        u = u.split("@", 1)[1]
    if "://" not in u:
        u = "http://" + u
    host = urlparse(u).netloc.split(":")[0]
    return host[4:] if host.startswith("www.") else host


def normalize_email(email: Optional[str]) -> str:
    return (email or "").strip().lower()


def normalize_phone(phone: Optional[str]) -> str:
    digits = re.sub(r"\D", "", phone or "")
    return digits[-9:] if len(digits) >= 9 else ""


def normalize_linkedin(url: Optional[str]) -> str:
    if not url:
        return ""
    u = url.strip().lower().split("?")[0].split("#")[0].rstrip("/")
    m = re.search(r"linkedin\.com/((?:in|company)/[^/]+)", u)
    return m.group(1) if m else ""


def name_similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def norm_country(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    v = value.strip()
    return COUNTRY_ALIASES.get(v.lower(), v.title() if v.islower() else v)


def country_bucket(value: Optional[str]) -> str:
    c = norm_country(value)
    return c if c in ("USA", "Poland") else "Other"


def first_last(full_name: Optional[str]) -> tuple[str, str]:
    parts = (full_name or "").split()
    if not parts:
        return "", ""
    return parts[0], " ".join(parts[1:])


# ----------------------------------------------------------------- parsing
def parse_number(value: Any) -> Optional[float]:
    """'$1.2M' -> 1200000, '35' -> 35, '1,200' -> 1200, '' -> None."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return None if (isinstance(value, float) and math.isnan(value)) else float(value)
    s = str(value).strip().lower().replace(",", "").replace("$", "").replace("usd", "").replace("pln", "")
    if not s or s in {"n/a", "na", "-", "none", "unknown"}:
        return None
    mult = 1.0
    if s.endswith("k"):
        mult, s = 1e3, s[:-1]
    elif s.endswith("m"):
        mult, s = 1e6, s[:-1]
    elif s.endswith("b"):
        mult, s = 1e9, s[:-1]
    m = re.match(r"^-?\d+(\.\d+)?", s.strip())
    if not m:
        return None
    return float(m.group(0)) * mult


def parse_int(value: Any) -> Optional[int]:
    n = parse_number(value)
    return int(n) if n is not None else None


def split_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(v).strip() for v in value if str(v).strip()]
    return [p.strip() for p in re.split(r"[;,|\n]", str(value)) if p.strip()]


def parse_date(value: Any) -> Optional[date]:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    s = str(value).strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%d.%m.%Y", "%Y/%m/%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(s[:10], fmt).date()
        except ValueError:
            continue
    return None


# ---------------------------------------------------------------- job titles
_DM = ("owner", "founder", "co-founder", "president", "ceo", "chief executive", "cfo", "chief financial",
       "coo", "managing director", "managing partner", "general manager", "principal", "partner",
       "prezes", "właściciel", "wlasciciel", "dyrektor zarządzający", "członek zarządu", "zarząd", "cro")
_INFL = ("controller", "finance manager", "financial manager", "accounting manager", "head of finance",
         "finance director", "vp finance", "vice president", "director", "treasurer", "office manager",
         "operations manager", "kontroler", "główny księgowy", "glowny ksiegowy", "dyrektor finansowy",
         "dyrektor", "manager", "kierownik")
_USER = ("accountant", "bookkeeper", "accounts payable", "accounts receivable", "dispatcher", "księgow", "ksiegow")


def classify_title(title: Optional[str]) -> str:
    """decision_maker | influencer | user | unknown — from title keywords only."""
    t = (title or "").lower()
    if not t:
        return "unknown"
    if any(k in t for k in _DM):
        return "decision_maker"
    if any(k in t for k in _INFL):
        return "influencer"
    if any(k in t for k in _USER):
        return "user"
    return "unknown"


# -------------------------------------------------------------------- stats
def wilson_interval(successes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """95% Wilson score interval for a proportion."""
    if n <= 0:
        return (0.0, 0.0)
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def pct(part: float, whole: float) -> Optional[float]:
    return round(100.0 * part / whole, 1) if whole else None


def safe_format(template: str, **values: Any) -> str:
    """str.format that leaves unknown {placeholders} untouched."""
    class _D(dict):
        def __missing__(self, k):
            return "{" + k + "}"
    try:
        return template.format_map(_D(**values))
    except (ValueError, IndexError, KeyError):
        return template


def ensure_list(value: Any) -> list:
    return list(value) if isinstance(value, (list, tuple)) else ([] if value in (None, "") else [value])


def chunked(seq: Iterable, size: int):
    buf = []
    for item in seq:
        buf.append(item)
        if len(buf) == size:
            yield buf
            buf = []
    if buf:
        yield buf
