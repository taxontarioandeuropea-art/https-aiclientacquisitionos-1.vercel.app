"""Shared vocabulary. Nothing here is industry specific."""
from __future__ import annotations

PIPELINE_STAGES = [
    "NEW", "RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED",
    "CALL", "PROPOSAL", "NEGOTIATION", "WON",
]
OFFPATH_STAGES = ["LOST", "NURTURE", "NOT_A_FIT"]
# Master prompt §27: a structured vocabulary for WHY a lead was disqualified, required when moving
# a lead to NOT_A_FIT, so the feedback engine can learn which sources/industries/signals convert —
# instead of free text that no aggregate query can ever group reliably.
DISQUALIFY_REASONS = ["not_relevant", "wrong_industry", "too_small", "too_large", "wrong_contact", "no_email", "bad_data", "other"]
DISQUALIFY_REASON_LABELS = {"not_relevant": "Not relevant", "wrong_industry": "Wrong industry", "too_small": "Too small",
                            "too_large": "Too large", "wrong_contact": "Wrong contact", "no_email": "No email found",
                            "bad_data": "Bad data", "other": "Other"}
ALL_STAGES = PIPELINE_STAGES + OFFPATH_STAGES
# Stages where a lead is still an active opportunity (potential MRR counts toward pipeline value)
ACTIVE_STAGES = ["NEW", "RESEARCHED", "QUALIFIED", "CONTACTED", "REPLIED", "CALL", "PROPOSAL", "NEGOTIATION"]
PIPELINE_VALUE_STAGES = ["QUALIFIED", "CONTACTED", "REPLIED", "CALL", "PROPOSAL", "NEGOTIATION"]
TERMINAL_STAGES = ["WON", "LOST", "NOT_A_FIT"]

STAGE_LABELS = {
    "NEW": "New", "RESEARCHED": "Researched", "QUALIFIED": "Qualified", "CONTACTED": "Contacted",
    "REPLIED": "Replied", "CALL": "Call", "PROPOSAL": "Proposal", "NEGOTIATION": "Negotiation",
    "WON": "Won", "LOST": "Lost", "NURTURE": "Nurture", "NOT_A_FIT": "Not a fit",
}

# Internal sales estimates by stage. These are the seller's own assumptions, NOT a prediction
# model. They are editable in Settings and are always labelled as such in the UI.
DEFAULT_STAGE_ESTIMATES = {
    "NEW": 0.0, "RESEARCHED": 0.02, "QUALIFIED": 0.05, "CONTACTED": 0.08, "REPLIED": 0.15,
    "CALL": 0.25, "PROPOSAL": 0.40, "NEGOTIATION": 0.60, "WON": 1.0,
    "LOST": 0.0, "NURTURE": 0.0, "NOT_A_FIT": 0.0,
}

LEVELS = ["HIGH", "MEDIUM", "LOW"]
LEVEL_RANK = {"HIGH": 3, "MEDIUM": 2, "LOW": 1, "UNKNOWN": 0}

CHANNELS = ["email", "linkedin", "contact_form", "direct_message", "manual"]
INTERACTION_TYPES = ["email", "linkedin", "call", "meeting", "note", "form", "other"]
DIRECTIONS = ["outbound", "inbound", "internal"]
MESSAGE_STATUSES = ["draft", "approved", "sent", "replied", "rejected"]
TASK_TYPES = [
    "research_company", "find_decision_maker", "send_message", "follow_up",
    "prepare_proposal", "call", "update_crm", "other",
]
TASK_STATUSES = ["open", "done", "cancelled"]
CAMPAIGN_STATUSES = ["draft", "active", "paused", "completed"]
FACT, INFERENCE, RECOMMENDATION = "FACT", "INFERENCE", "RECOMMENDATION"
STATEMENT_KINDS = [FACT, INFERENCE, RECOMMENDATION]

COUNTRY_ALIASES = {
    "us": "USA", "usa": "USA", "u.s.": "USA", "u.s.a.": "USA", "united states": "USA",
    "united states of america": "USA", "america": "USA",
    "pl": "Poland", "poland": "Poland", "polska": "Poland",
    "uk": "United Kingdom", "gb": "United Kingdom", "united kingdom": "United Kingdom",
    "de": "Germany", "germany": "Germany", "deutschland": "Germany",
    "ca": "Canada", "canada": "Canada", "nl": "Netherlands", "netherlands": "Netherlands",
}
