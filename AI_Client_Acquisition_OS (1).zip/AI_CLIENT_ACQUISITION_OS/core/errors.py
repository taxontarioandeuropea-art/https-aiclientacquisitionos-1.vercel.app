"""Application errors. Each carries what the UI needs to explain a failure:
what failed, the likely cause and a suggested next action."""
from __future__ import annotations


class AppError(Exception):
    status_code = 400
    code = "app_error"

    def __init__(self, message: str, *, operation: str | None = None, cause: str | None = None,
                 suggestion: str | None = None, status_code: int | None = None, details: dict | None = None):
        super().__init__(message)
        self.message = message
        self.operation = operation
        self.cause = cause
        self.suggestion = suggestion
        self.details = details or {}
        if status_code:
            self.status_code = status_code

    def to_dict(self) -> dict:
        return {
            "message": self.message,
            "operation": self.operation,
            "cause": self.cause,
            "suggestion": self.suggestion,
            "code": self.code,
            "details": self.details,
        }


class NotFound(AppError):
    status_code = 404
    code = "not_found"

    def __init__(self, what: str, ident=None):
        super().__init__(
            f"{what} not found" + (f" (id {ident})" if ident is not None else ""),
            operation=f"load {what.lower()}",
            cause="The record does not exist or was merged/removed.",
            suggestion="Refresh the list and try again.",
        )


class ValidationProblem(AppError):
    status_code = 422
    code = "validation_error"


class InsufficientEvidence(AppError):
    status_code = 409
    code = "insufficient_evidence"
