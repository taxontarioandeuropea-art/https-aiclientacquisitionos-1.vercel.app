"""Concrete providers. Keys are read from environment variables only (see .env.example)."""
from __future__ import annotations

import os
from typing import Optional

import httpx

from ai.base import AIProviderError, BaseAIProvider, NullProvider
from config import config


class _HTTPProvider(BaseAIProvider):
    def __init__(self, model: str = "", base_url: str = "", client: Optional[httpx.Client] = None):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self._client = client

    def _http(self) -> httpx.Client:
        return self._client or httpx.Client(timeout=max(config.http_timeout, 30))

    def _fail(self, cause: str) -> AIProviderError:
        return AIProviderError(f"{self.name} request failed", operation=f"{self.name} generation", cause=cause,
                               suggestion="Check the key in .env, the model name in Settings → AI and your network connection.")


class OpenAICompatibleProvider(_HTTPProvider):
    """Any server exposing POST {base_url}/chat/completions (OpenAI, Ollama, LM Studio, llama.cpp ...)."""
    name = "openai-compatible"
    key_env = "OPENAI_API_KEY"
    key_required = True
    default_base = "https://api.openai.com/v1"

    def _key(self) -> str:
        return os.getenv(self.key_env, "").strip()

    def is_configured(self) -> bool:
        return bool(self.model) and bool(self.base_url or self.default_base) and (bool(self._key()) or not self.key_required)

    def generate(self, system: str, prompt: str, *, temperature: float = 0.4, max_tokens: int = 700) -> str:
        if not self.is_configured():
            raise self._fail(f"Model or {self.key_env} is missing.")
        headers = {"Content-Type": "application/json"}
        if self._key():
            headers["Authorization"] = f"Bearer {self._key()}"
        payload = {"model": self.model, "temperature": temperature, "max_tokens": max_tokens,
                   "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}]}
        try:
            r = self._http().post(f"{(self.base_url or self.default_base)}/chat/completions", json=payload, headers=headers)
            r.raise_for_status()
            return (r.json()["choices"][0]["message"]["content"] or "").strip()
        except (httpx.HTTPError, KeyError, IndexError, ValueError) as exc:
            raise self._fail(str(exc)[:200]) from exc


class OpenAIProvider(OpenAICompatibleProvider):
    name = "openai"


class LocalLLMProvider(OpenAICompatibleProvider):
    name = "local"
    key_env = "LOCAL_LLM_API_KEY"
    key_required = False
    default_base = "http://localhost:11434/v1"

    def __init__(self, model: str = "", base_url: str = "", client: Optional[httpx.Client] = None):
        super().__init__(model, base_url or os.getenv("LOCAL_LLM_BASE_URL", ""), client)


class AnthropicProvider(_HTTPProvider):
    name = "anthropic"

    def is_configured(self) -> bool:
        return bool(self.model) and bool(os.getenv("ANTHROPIC_API_KEY", "").strip())

    def generate(self, system: str, prompt: str, *, temperature: float = 0.4, max_tokens: int = 700) -> str:
        if not self.is_configured():
            raise self._fail("Model (Settings → AI) or ANTHROPIC_API_KEY (.env) is missing.")
        headers = {"x-api-key": os.getenv("ANTHROPIC_API_KEY", "").strip(), "anthropic-version": "2023-06-01",
                   "content-type": "application/json"}
        payload = {"model": self.model, "max_tokens": max_tokens, "temperature": temperature, "system": system,
                   "messages": [{"role": "user", "content": prompt}]}
        try:
            r = self._http().post(f"{self.base_url or 'https://api.anthropic.com'}/v1/messages", json=payload, headers=headers)
            r.raise_for_status()
            return "".join(b.get("text", "") for b in r.json()["content"] if b.get("type") == "text").strip()
        except (httpx.HTTPError, KeyError, ValueError) as exc:
            raise self._fail(str(exc)[:200]) from exc


PROVIDERS = {"none": NullProvider, "openai": OpenAIProvider, "anthropic": AnthropicProvider, "local": LocalLLMProvider}


def get_provider(ai_settings: dict, client: Optional[httpx.Client] = None) -> BaseAIProvider:
    name = (ai_settings or {}).get("provider", "none")
    cls = PROVIDERS.get(name, NullProvider)
    if cls is NullProvider:
        return NullProvider()
    return cls(model=ai_settings.get("model", ""), base_url=ai_settings.get("base_url", ""), client=client)
