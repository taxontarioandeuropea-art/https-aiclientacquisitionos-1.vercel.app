"""AI provider abstraction. The application is fully functional with NO provider configured
(rule-based research, scoring and message composition); a provider only adds optional polish."""
from __future__ import annotations

from abc import ABC, abstractmethod

from core.errors import AppError


class AIProviderError(AppError):
    status_code = 502
    code = "ai_provider_error"


class BaseAIProvider(ABC):
    name = "base"

    @abstractmethod
    def is_configured(self) -> bool:
        """True when credentials/model needed to call the provider are present."""

    @abstractmethod
    def generate(self, system: str, prompt: str, *, temperature: float = 0.4, max_tokens: int = 700) -> str:
        """Return plain text. Must raise AIProviderError on failure (never return partial garbage)."""

    def describe(self) -> dict:
        return {"provider": self.name, "configured": self.is_configured()}


class NullProvider(BaseAIProvider):
    """Non-AI mode."""
    name = "none"

    def is_configured(self) -> bool:
        return False

    def generate(self, system: str, prompt: str, *, temperature: float = 0.4, max_tokens: int = 700) -> str:
        raise AIProviderError("No AI provider is configured", operation="AI generation",
                              cause="Provider is set to 'none' in Settings → AI.",
                              suggestion="Choose a provider in Settings → AI and set its key in .env, or continue without AI.")
